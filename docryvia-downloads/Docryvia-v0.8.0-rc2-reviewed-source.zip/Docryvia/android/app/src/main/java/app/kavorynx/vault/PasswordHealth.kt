package app.kavorynx.vault

/**
 * All password inspection takes place in memory on the device while the vault is unlocked.
 * It does not communicate with any API, log passwords, or persist a plaintext index.
 * Heuristics do NOT estimate cryptographic entropy and do NOT certify a password as safe.
 */
data class PasswordHealthInput(val id: String, val site: String, val username: String, val password: String)

data class PasswordHealthReport(
    val total: Int,
    val weak: Int,
    val reused: Int,
    val duplicateAccounts: Int
)

object PasswordHealth {
    private val common = setOf(
        "password", "password123", "123456", "12345678", "123456789", "qwerty",
        "qwerty123", "admin", "admin123", "welcome", "letmein", "iloveyou"
    )

    fun isPotentiallyWeak(password: String): Boolean {
        if (password.length < 12) return true
        if (password.lowercase() in common) return true
        // Long random letter-only passwords can be strong; don't penalize letters alone.
        if (password.toSet().size <= 3) return true
        if (password.all { it.isDigit() }) return true
        val lower = password.lowercase()
        if (listOf("password", "qwerty", "123456", "letmein", "iloveyou", "admin123")
                .any { lower.contains(it) }) return true
        if (lower.contains("abcdefgh") || lower.contains("12345678")) return true
        return false
    }

    fun analyze(items: List<PasswordHealthInput>): PasswordHealthReport {
        val nonempty = items.filter { it.password.isNotEmpty() }
        // Count affected records, not pair combinations. Never expose the matched secret.
        val reusedGroups = nonempty.groupBy { it.password }.values.filter { it.size > 1 }
        val duplicates = items.mapNotNull { item -> VaultOrganization.identity(item.site, item.username)?.let { it to item } }
            .groupBy({ it.first }, { it.second }).values.filter { it.size > 1 }
        return PasswordHealthReport(
            total = items.size,
            weak = nonempty.count { isPotentiallyWeak(it.password) },
            reused = reusedGroups.sumOf { it.size },
            duplicateAccounts = duplicates.sumOf { it.size }
        )
    }
}
