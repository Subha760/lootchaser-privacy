package app.kavorynx.vault

import java.text.Normalizer
import java.util.Locale

/** Answers never unlock alone: the independent 256-bit rescue code is also required. */
object QuestionRecovery {
    val questions = linkedMapOf(
        "food" to "What is your favourite food?",
        "school" to "What was your first school?",
        "nickname" to "What was your childhood nickname?"
    )
    private fun normalized(answer: CharArray, modern: Boolean = false): CharArray {
        require(answer.size <= 200) { "Answer too long" }
        val source = Normalizer.normalize(String(answer), Normalizer.Form.NFKC).lowercase(Locale.ROOT)
        val value = (if (modern) source.replace(Regex("[^\\p{L}\\p{Nd}\\s]"), "") else source)
            .trim().replace(Regex("\\s+"), " ")
        require(value.length >= 2) { "Use at least two characters" }
        return value.toCharArray()
    }
    private fun domain(question: String, modern: Boolean = false): String {
        require(question in questions) { "Unknown recovery question" }
        return "docryvia:question-recovery:${if (modern) "v2" else "v1"}:$question"
    }
    fun seal(question: String, answer: CharArray, rescueCode: String, dek: ByteArray): String {
        val aad = domain(question, true)
        val token = Crypto.parseRecoveryToken(rescueCode)
        val salt = Crypto.randomBytes(16)
        val chars = normalized(answer, true)
        var key: ByteArray? = null
        try {
            // A stolen answer and salt still cannot derive this key without the rescue code.
            key = Crypto.pbkdf2(chars, salt + token)
            return "v2:" + Crypto.b64(salt + Crypto.seal(key, dek, aad))
        } finally { chars.fill('\u0000'); token.fill(0); key?.fill(0) }
    }
    fun open(question: String, answer: CharArray, rescueCode: String, envelope: String): ByteArray {
        val modern = envelope.startsWith("v2:")
        val aad = domain(question, modern)
        val packed = Crypto.unb64(if (modern) envelope.removePrefix("v2:") else envelope)
        require(packed.size == 16 + 12 + 32 + 16) { "Invalid recovery envelope" }
        val token = Crypto.parseRecoveryToken(rescueCode)
        fun decrypt(stripPunctuation: Boolean): ByteArray {
            val chars = normalized(answer, stripPunctuation)
            var key: ByteArray? = null
            try {
                key = Crypto.pbkdf2(chars, packed.copyOfRange(0, 16) + token)
                return Crypto.open(key, packed.copyOfRange(16, packed.size), aad)
            } finally { chars.fill('\u0000'); key?.fill(0) }
        }
        try {
            if (modern) return decrypt(true)
            try { return decrypt(false) }
            catch (original: javax.crypto.AEADBadTagException) {
                // Modified rc2 changed normalization but kept the v1 envelope/AAD.
                val old = normalized(answer, false); val stripped = runCatching { normalized(answer, true) }.getOrNull()
                val different = stripped != null && !old.contentEquals(stripped)
                old.fill('\u0000'); stripped?.fill('\u0000')
                if (!different) throw original
                return decrypt(true)
            }
        } finally { token.fill(0); packed.fill(0) }
    }
}
