package app.kavorynx.vault

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun OrganizationControls(entries: List<VaultItem>, category: String?, onCategory: (String?) -> Unit,
    favorites: Boolean, onFavorites: (Boolean) -> Unit, sort: VaultSort, onSort: (VaultSort) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { FilterChip(category == null, { onCategory(null) }, label = { Text(stringResource(R.string.organization_all)) }) }
            items(entries.map { VaultOrganization.categoryLabel(it) }.distinct().sorted()) { label -> FilterChip(category == label, { onCategory(label) }, label = { Text(label) }) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(favorites, onFavorites); Text(stringResource(R.string.organization_favorites)) }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(VaultSort.entries.toList()) { value -> FilterChip(sort == value, { onSort(value) }, label = {
                Text(stringResource(when (value) { VaultSort.TITLE -> R.string.sort_title; VaultSort.NEWEST -> R.string.sort_newest; VaultSort.OLDEST -> R.string.sort_oldest }))
            }) }
        }
    }
}

@Composable
fun DuplicateReviewPage(repo: VaultRepository, onNotice: (String) -> Unit, onEdit: (VaultItem) -> Unit) {
    val groups = VaultOrganization.duplicates(VaultSession.activeItems)
    val keepers = remember { mutableStateMapOf<AccountIdentity, String>() }
    var pending by remember { mutableStateOf<Pair<String, String>?>(null) }
    var working by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(stringResource(R.string.review_duplicates), style = MaterialTheme.typography.headlineSmall)
        Text(stringResource(R.string.duplicate_explanation))
        if (groups.isEmpty()) Text(stringResource(R.string.duplicate_empty))
        groups.forEach { group ->
            Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(group.identity.host, style = MaterialTheme.typography.titleMedium)
                    Text(group.identity.username)
                    if (group.conflictingPasswords) Text(stringResource(R.string.duplicate_conflict), color = MaterialTheme.colorScheme.error)
                    Text(stringResource(R.string.duplicate_metadata), style = MaterialTheme.typography.bodySmall)
                    val keeper = keepers[group.identity]?.takeIf { id -> group.items.any { it.id == id } }
                    group.items.forEach { item ->
                        HorizontalDivider()
                        Text(item.title, style = MaterialTheme.typography.titleSmall)
                        Text(stringResource(R.string.duplicate_created, java.time.Instant.ofEpochMilli(item.created).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()), style = MaterialTheme.typography.bodySmall)
                        Text(stringResource(R.string.duplicate_fields, item.customFields.size, item.history.size, item.linkedApps.size), style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(keeper == item.id, { keepers[group.identity] = item.id }, enabled = !working); Text(stringResource(R.string.duplicate_keep)) }
                        Row {
                            TextButton(enabled = !working, onClick = { onEdit(item) }) { Text(stringResource(R.string.duplicate_edit)) }
                            TextButton(enabled = !working && keeper != null && keeper != item.id, onClick = { keeper?.let { pending = item.id to it } }) { Text(stringResource(R.string.duplicate_trash)) }
                        }
                    }
                }
            }
        }
    }
    pending?.let { pair -> AlertDialog(onDismissRequest = { if (!working) pending = null },
        title = { Text(stringResource(R.string.duplicate_confirm)) }, text = { Text(stringResource(R.string.duplicate_confirm_body)) },
        confirmButton = { TextButton(enabled = !working, onClick = { working = true; scope.launch {
            try { withContext(Dispatchers.IO) { VaultSession.trashDuplicate(pair.first, pair.second, repo) }; onNotice(UiText.get(R.string.duplicate_done)) }
            catch (_: Exception) { onNotice(UiText.get(R.string.duplicate_changed)) }
            finally { pending = null; working = false }
        } }) { Text(stringResource(R.string.duplicate_trash)) } },
        dismissButton = { TextButton(enabled = !working, onClick = { pending = null }) { Text(stringResource(R.string.ui_2)) } }) }
}
