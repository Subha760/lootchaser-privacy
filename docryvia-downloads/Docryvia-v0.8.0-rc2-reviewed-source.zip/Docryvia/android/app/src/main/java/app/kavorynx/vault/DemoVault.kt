package app.kavorynx.vault

import android.content.Context

/** Compile-time demo-only entry point. R8 removes this unused class from release builds. */
internal object DemoVault {
    fun prepare(context: Context, repo: VaultRepository) {
        check(BuildConfig.DEMO_MODE)
        context.getSharedPreferences("senviya_intro", 0).edit().putBoolean("seen_v2", true).commit()
        LockPreferences.setTimeout(context, 0)
        val password = "demo-only-vault-do-not-use".toCharArray()
        try {
            val key = if (repo.exists()) repo.unlock(password) else repo.create(password).first
            val now = System.currentTimeMillis()
            repo.write(key, listOf(
                VaultItem(id = "demo-email", title = "Personal email", site = "https://mail.example.com", username = "alex@example.com", secret = "SamplePassword!2948", category = "Personal", favorite = true, totpSecret = "JBSWY3DPEHPK3PXP", created = now - 86400000L),
                VaultItem(id = "demo-work", title = "Work account", site = "https://work.example.com", username = "alex", secret = "SampleWork!529834", category = "Work", created = now - 172800000L),
                VaultItem(id = "demo-work-copy", title = "Work account — imported copy", site = "https://work.example.com/login", username = "alex", secret = "DifferentSample!3928", category = "Work", created = now - 86400000L),
                VaultItem(id = "demo-school", title = "Course certificate", type = TYPE_DOCUMENT, category = "Education", fileName = "sample-certificate.pdf", mime = "application/pdf", fileData = Crypto.b64(context.assets.open("sample-certificate.pdf").use { it.readBytes() }), notes = "Fictional sample entry", created = now),
                VaultItem(id = "demo-travel", title = "Travel documents", type = TYPE_DOCUMENT, category = "Travel", fileName = "sample-itinerary.pdf", mime = "application/pdf", fileData = Crypto.b64(context.assets.open("sample-certificate.pdf").use { it.readBytes() }), expiryDate = "2027-06-30", created = now),
                VaultItem(id = "demo-note", title = "Travel checklist", type = TYPE_NOTE, category = "Personal", notes = "Sample data: pack charger, tickets and travel adapter.", favorite = true, created = now),
                VaultItem(id = "demo-address", title = "Home address", type = TYPE_ADDRESS, username = "Alex Example", category = "Personal", notes = "Fictional sample address", created = now)))
            VaultSession.start(key, repo)
        } finally { password.fill('\u0000') }
    }
}
