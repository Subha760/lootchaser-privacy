package app.kavorynx.vault

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity

/** Plaintext exists only in owned RAM/anonymous memory files; no plaintext disk or external viewer. */
class DocumentViewerActivity : FragmentActivity() {
    private var bytes: ByteArray? = null
    private var renderer: PdfRenderer? = null
    private var bitmap: Bitmap? = null
    private var stopped by mutableStateOf(false)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.DEMO_MODE) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val id = intent.getStringExtra("item_id") ?: run { finish(); return }
        if (!VaultSession.unlocked) { finish(); return }
        val item = VaultSession.activeItems.firstOrNull { it.id == id } ?: run { finish(); return }
        var failure: String? = null
        try {
            val raw = VaultSession.documentBytes(id, VaultRepository(this)); bytes = raw
            if (item.mime == "application/pdf" || item.fileName.endsWith(".pdf", true)) {
                val descriptor = RamFile.descriptor(raw)
                try { renderer = PdfRenderer(descriptor) }
                catch (t: Throwable) { descriptor.close(); throw t }
                raw.fill(0); bytes = null
            } else if (item.mime.startsWith("image/")) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
                require(bounds.outWidth > 0 && bounds.outHeight > 0)
                var sample = 1
                while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: error("Unsupported image")
                raw.fill(0); bytes = null
            } else failure = UiText.get(R.string.ui_215)
        } catch (_: Exception) { failure = UiText.get(R.string.ui_216); cleanup() }
        setContent { SenviyaAppTheme {
            var page by remember { mutableIntStateOf(0) }
            var rendered by remember { mutableStateOf(bitmap) }
            LaunchedEffect(page) {
                if (!stopped && renderer != null) {
                    try {
                        rendered = null; bitmap?.recycle(); bitmap = null
                        renderer!!.openPage(page).use { p ->
                            val width = minOf(p.width, 1600); val height = (p.height.toLong() * width / p.width).toInt().coerceIn(1, 4096)
                            val image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            image.eraseColor(android.graphics.Color.WHITE)
                            p.render(image, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bitmap = image; rendered = image
                        }
                    } catch (_: Exception) { rendered = null }
                }
            }
            LaunchedEffect(VaultSession.unlocked) { if (!VaultSession.unlocked) { cleanup(); finish() } }
            Surface { Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
                Text(item.title, style = MaterialTheme.typography.titleLarge)
                if (failure != null) Text(failure!!)
                if (!stopped) rendered?.let { Image(it.asImageBitmap(), androidx.compose.ui.res.stringResource(R.string.document_preview), Modifier.weight(1f).fillMaxWidth()) }
                val pages = renderer?.pageCount ?: 0
                if (pages > 0) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextButton(enabled = page > 0, onClick = { LockPreferences.interaction(); page-- }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_143)) }
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_214, (page + 1), (pages)))
                    TextButton(enabled = page + 1 < pages, onClick = { LockPreferences.interaction(); page++ }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_144)) }
                }
                TextButton(onClick = { finish() }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_59)) }
            } }
        } }
    }
    override fun onUserInteraction() { super.onUserInteraction(); LockPreferences.interaction() }
    override fun onStop() { super.onStop(); stopped = true; cleanup(); finish() }
    override fun onDestroy() { cleanup(); super.onDestroy() }
    private fun cleanup() {
        bitmap?.recycle(); bitmap = null; renderer?.close(); renderer = null
        bytes?.fill(0); bytes = null
    }
}
