package app.kavorynx.vault

import java.io.ByteArrayOutputStream
import java.io.InputStream

/** Enforce the limit on the stream itself, including AtomicFile fallback reads. */
internal object BoundedInput {
    fun read(input: InputStream, maximum: Int): ByteArray {
        require(maximum >= 0)
        val out = ByteArrayOutputStream(minOf(maximum, 8192))
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), maximum.toLong() - out.size() + 1).toInt())
            if (count < 0) break
            if (count == 0) {
                val one = input.read()
                if (one < 0) break
                require(out.size() < maximum) { "File exceeds supported size" }
                out.write(one)
            } else {
                require(count <= maximum - out.size()) { "File exceeds supported size" }
                out.write(buffer, 0, count)
            }
        }
        return out.toByteArray()
    }
}
