package app.kavorynx.vault

import java.util.Locale

data class AccountIdentity(val host: String, val username: String)
data class DuplicateGroup(val identity: AccountIdentity, val items: List<VaultItem>) {
    val conflictingPasswords: Boolean get() = items.map { it.secret }.distinct().size > 1
}
enum class VaultSort { TITLE, NEWEST, OLDEST }
object VaultOrganization {
    fun identity(site: String, username: String): AccountIdentity? =
        DomainPolicy.canonicalHost(site)?.takeIf { username.isNotBlank() }?.let { AccountIdentity(it, username) }
    fun duplicates(items: List<VaultItem>): List<DuplicateGroup> = items.filter { !it.isDeleted && it.type == TYPE_PASSWORD }
        .mapNotNull { item -> identity(item.site, item.username)?.let { it to item } }
        .groupBy({ it.first }, { it.second }).filterValues { it.size > 1 }
        .map { DuplicateGroup(it.key, it.value.sortedWith(compareBy<VaultItem> { i -> i.created }.thenBy { i -> i.id })) }
        .sortedWith(compareBy<DuplicateGroup> { it.identity.host }.thenBy { it.identity.username })
    fun categoryLabel(item: VaultItem): String = item.category.trim().ifBlank { "General" }
    fun select(items: List<VaultItem>, query: String = "", category: String? = null, favorites: Boolean = false, sort: VaultSort = VaultSort.TITLE): List<VaultItem> {
        val tokens = query.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val selected = items.filter { !it.isDeleted && (!favorites || it.favorite) && (category == null || categoryLabel(it) == category) &&
            tokens.all { token -> listOf(it.title, it.site, it.username, categoryLabel(it), it.fileName).any { value -> value.contains(token, true) } } }
        val title = compareBy<VaultItem> { it.title.lowercase(Locale.ROOT) }.thenBy { it.id }
        return when (sort) { VaultSort.TITLE -> selected.sortedWith(title); VaultSort.NEWEST -> selected.sortedWith(compareByDescending<VaultItem> { it.created }.then(title)); VaultSort.OLDEST -> selected.sortedWith(compareBy<VaultItem> { it.created }.then(title)) }
    }
}
