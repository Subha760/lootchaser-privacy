package app.kavorynx.vault

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = DocryviaApp::class)
class Rc2CompatibilityUnitTest {
    @Test fun stringHistoryMigratesNewestFirstAndSurvivesModernRoundTrip() {
        val item = VaultItem.from(JSONObject().put("id", "legacy").put("history", JSONArray(listOf("newest", "middle", "oldest"))))
        assertEquals(listOf("oldest", "middle", "newest"), item.history.map { it.password })
        assertTrue(item.history.all { it.changedAt == 0L })
        assertEquals(item, VaultItem.from(item.json()))
        val next = VaultSession.preserveHistory(item.copy(secret = "current"), item.copy(secret = "replacement"))
        assertEquals(listOf("oldest", "middle", "newest", "current"), next.history.map { it.password })
    }
    @Test fun longStringHistoryKeepsFiveMostRecentAndMixedHistoryIsRejected() {
        val item = VaultItem.from(JSONObject().put("id", "legacy").put("history", JSONArray((1..8).map { "p$it" })))
        assertEquals(listOf("p5", "p4", "p3", "p2", "p1"), item.history.map { it.password })
        try { VaultItem.from(JSONObject().put("id", "bad").put("history", JSONArray().put("p").put(JSONObject().put("password", "q")))); fail("Mixed format must fail") }
        catch (_: IllegalArgumentException) { }
    }
    private fun legacyEnvelope(answer: String, code: String, dek: ByteArray): String {
        val salt = Crypto.randomBytes(16); val token = Crypto.parseRecoveryToken(code)
        val key = Crypto.pbkdf2(answer.toCharArray(), salt + token)
        return try { Crypto.b64(salt + Crypto.seal(key, dek, "docryvia:question-recovery:v1:school")) }
        finally { key.fill(0); token.fill(0) }
    }
    @Test fun bothOriginalAndModifiedUnversionedRecoveryRemainReadable() {
        val dek = Crypto.randomBytes(32); val code = Crypto.printRecoveryToken(Crypto.randomBytes(32))
        for (storedAnswer in listOf("st. mary's", "st marys")) {
            val envelope = legacyEnvelope(storedAnswer, code, dek)
            assertArrayEquals(dek, QuestionRecovery.open("school", "St. Mary's".toCharArray(), code, envelope))
        }
        dek.fill(0)
    }
    @Test fun recoveryFallbackDoesNotAcceptWrongAnswerOrRescueCode() {
        val dek = Crypto.randomBytes(32); val code = Crypto.printRecoveryToken(Crypto.randomBytes(32))
        val envelope = legacyEnvelope("st marys", code, dek)
        for ((answer, token) in listOf("Other. School" to code, "St. Mary's" to Crypto.printRecoveryToken(Crypto.randomBytes(32)))) {
            try { QuestionRecovery.open("school", answer.toCharArray(), token, envelope); fail("Must authenticate") }
            catch (_: javax.crypto.AEADBadTagException) { }
        }
        val modern = QuestionRecovery.seal("school", "St. Mary's".toCharArray(), code, dek)
        try { QuestionRecovery.open("school", "St. Mary's".toCharArray(), code, modern.removePrefix("v2:")); fail("No version downgrade") }
        catch (_: javax.crypto.AEADBadTagException) { }
        dek.fill(0)
    }
    @Test fun phraseOptionsKeepLargeWordlistAndFixedWordCount() {
        val words = RuntimeEnvironment.getApplication().assets.open("eff_wordlist.txt").bufferedReader().use { it.readLines() }
        for (separator in listOf(" ", "_", ".")) repeat(100) {
            val phrase = PasswordStudio.passphrase(words, 6, separator, true, true)
            val parts = phrase.split(separator)
            assertEquals(7, parts.size)
            assertTrue(parts.take(6).all { it.first().isUpperCase() && it.lowercase() in words })
            assertTrue(parts.last().matches(Regex("[0-9]{3}")))
        }
    }
    @Test fun emptyTrashPreservesActiveItemsAndDeletesOrphanDocuments() {
        VaultSession.lock()
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit()
        app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        val repo = VaultRepository(app); val (key, _) = repo.create("compatibility password".toCharArray())
        repo.write(key, listOf(VaultItem(id = "active", secret = "keep"), VaultItem(id = "doc", type = TYPE_DOCUMENT, fileData = Crypto.b64("secret bytes".toByteArray()))))
        VaultSession.start(key, repo); VaultSession.remove("doc", repo)
        assertEquals(1, java.io.File(app.filesDir, "encrypted_documents").listFiles()?.size)
        VaultSession.emptyTrash(repo)
        assertEquals(listOf("active"), VaultSession.items.map { it.id })
        assertEquals(0, java.io.File(app.filesDir, "encrypted_documents").listFiles()?.size)
        VaultSession.lock()
    }
}
