package app.kavorynx.vault

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.InputStream

class BoundedInputUnitTest {
    @Test fun exactLimitAndEmptyStreamRemainReadable() {
        assertArrayEquals(byteArrayOf(1, 2, 3), BoundedInput.read(ByteArrayInputStream(byteArrayOf(1, 2, 3)), 3))
        assertTrue(BoundedInput.read(ByteArrayInputStream(byteArrayOf()), 0).isEmpty())
    }
    @Test fun oversizedStreamStopsAfterAtMostOneExtraByte() {
        var consumed = 0
        val endless = object : InputStream() {
            override fun read(): Int { consumed++; return 1 }
            override fun read(b: ByteArray, off: Int, len: Int): Int { consumed += len; b.fill(1, off, off + len); return len }
        }
        try { BoundedInput.read(endless, 100); fail("Oversize accepted") } catch (_: IllegalArgumentException) { }
        assertEquals(101, consumed)
    }
    @Test fun zeroLengthReadsCannotHangOrBypassLimit() {
        val unusual = object : InputStream() {
            override fun read(): Int = 1
            override fun read(b: ByteArray, off: Int, len: Int): Int = 0
        }
        try { BoundedInput.read(unusual, 0); fail("Oversize accepted") } catch (_: IllegalArgumentException) { }
    }
}
