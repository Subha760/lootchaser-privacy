import java.util.Properties
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val signingPropertiesFile = rootProject.file("keystore.properties")
val signingProperties = Properties().apply {
    if (signingPropertiesFile.isFile) signingPropertiesFile.inputStream().use { load(it) }
}
val releaseSigningReady = signingPropertiesFile.isFile

android {
    namespace = "app.kavorynx.vault"
    compileSdk = 36
    defaultConfig {
        applicationId = "app.kavorynx.vault"
        minSdk = 28
        targetSdk = 36
        versionCode = 11
        versionName = "0.8.0-rc2"
        buildConfigField("boolean", "DEMO_MODE", "false")
    }
    signingConfigs {
        if (releaseSigningReady) {
            create("docryviaRelease") {
                storeFile = rootProject.file(signingProperties.getProperty("storeFile"))
                storePassword = signingProperties.getProperty("storePassword")
                keyAlias = signingProperties.getProperty("keyAlias")
                keyPassword = signingProperties.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        create("demo") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".demo"
            versionNameSuffix = "-demo"
            buildConfigField("boolean", "DEMO_MODE", "true")
            matchingFallbacks += listOf("debug")
        }
        release {
            if (releaseSigningReady) signingConfig = signingConfigs.getByName("docryviaRelease")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.autofill:autofill:1.1.0")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("com.squareup.leakcanary:leakcanary-android:2.14")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}

// Never silently publish an unsigned release artifact.
gradle.taskGraph.whenReady {
    val releaseArtifactRequested = allTasks.any {
        it.project == project && (it.name == "assembleRelease" || it.name == "bundleRelease")
    }
    if (releaseArtifactRequested && !releaseSigningReady) {
        throw GradleException("Missing android/keystore.properties. Run the signing setup before building release.")
    }
}

// Robolectric downloads Android test runtimes; preserve configured proxy/CA trust.
tasks.withType<Test>().configureEach {
    maxHeapSize = "1g"
    listOf("http.proxyHost", "http.proxyPort", "https.proxyHost", "https.proxyPort",
        "javax.net.ssl.trustStore").forEach { name ->
        System.getProperty(name)?.let { systemProperty(name, it) }
    }
}

// Preserve resolved versions in reviewed lock files.
dependencyLocking { lockAllConfigurations() }

tasks.register("releaseDependencyInventory") {
    group = "verification"
    description = "Generate a CycloneDX inventory with SHA-256 hashes of release dependencies"
    doLast {
        val components = configurations.getByName("releaseRuntimeClasspath").resolvedConfiguration.resolvedArtifacts.map { artifact ->
            val id = artifact.moduleVersion.id
            val digest = MessageDigest.getInstance("SHA-256")
            artifact.file.inputStream().use { input ->
                val buffer = ByteArray(8192)
                while (true) { val count = input.read(buffer); if (count < 0) break; digest.update(buffer, 0, count) }
            }
            mapOf("type" to "library", "group" to id.group, "name" to id.name,
                "version" to id.version, "purl" to "pkg:maven/${id.group}/${id.name}@${id.version}",
                "hashes" to listOf(mapOf("alg" to "SHA-256", "content" to digest.digest().joinToString("") { "%02x".format(it) })))
        }.sortedBy { it["purl"].toString() }
        val output = layout.buildDirectory.file("reports/sbom/release.cdx.json").get().asFile
        output.parentFile.mkdirs()
        output.writeText(groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(mapOf(
            "bomFormat" to "CycloneDX", "specVersion" to "1.5", "version" to 1, "components" to components))))
    }
}
