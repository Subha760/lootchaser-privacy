# Current release checklist — v0.8.0-rc2

Use docs/PRODUCTION_READINESS.md and bundled verification evidence. Older version reports are historical.

- [x] Offline encryption, recovery and vault compatibility regression coverage.
- [x] Bounded file reads and authenticated atomic writes.
- [x] Debug/release test and lint gates; signed APK/AAB artifact checks.
- [x] Locked release dependencies, CycloneDX inventory and commit-pinned CI actions.
- [x] Separate fictional screenshot demo; production capture protection.
- [x] Publisher, support email, public privacy policy and prepared Indus kit.
- [ ] Exact signed-build update/migration and backup-restore acceptance on physical phones.
- [ ] Physical biometric/PIN and browser/native-app autofill acceptance.
- [ ] Accessibility, low-memory and device/Android-version coverage.
- [ ] Independent security review and publisher-approved store declarations.
- [ ] Store internal testing/staged rollout and approval.

Do not describe unchecked device or store gates as completed. Passkeys, cloud sync and Credential Manager are separate product features; they are not claimed by this offline vault release.
