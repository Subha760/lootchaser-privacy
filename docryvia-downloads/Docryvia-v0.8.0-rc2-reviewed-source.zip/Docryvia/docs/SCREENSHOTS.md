# Reproduce listing screenshots

Build the isolated variant with `gradle -p android :app:assembleDemo`. Install app-demo.apk on a disposable emulator. The application ID is app.kavorynx.vault.demo. It creates fictional fixtures and permits screenshots only in this build. MainActivity accepts demo_page values Home, Passwords, Documents, Wallet, Settings, Generator, Authenticator, Duplicates and PDF. Never use real passwords in the demo. The release uses compile-time DEMO_MODE=false and FLAG_SECURE.
