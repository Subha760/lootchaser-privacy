# Release dependency review

OSV Maven query batch checked 74 resolved release artifacts. 0 packages have matching advisory records.

[]

No matches does not establish security certification, exploitability or complete coverage of Android/platform/native code. The inventory hashes record the artifacts used; they do not prove upstream authorship.
