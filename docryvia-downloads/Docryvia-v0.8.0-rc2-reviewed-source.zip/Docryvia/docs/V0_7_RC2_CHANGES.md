# Docryvia 0.7.0-rc2 changes

This release builds on the reviewed v0.7 implementation. Ideas from the user-uploaded modified v0.6 source were reimplemented rather than copying broken UI or private signing material.

- Reads both modern password-history objects and modified rc2 string arrays. Legacy arrays are reversed from newest-first, retain the five most recent entries, and use date-unavailable labels. Mixed-format arrays are rejected instead of silently losing entries.
- Supports original and punctuation-normalizing unversioned question-recovery envelopes. Both paths authenticate with the original AAD and independent rescue code. Modern versioned envelopes never fall back to the legacy AAD.
- Live TOTP countdown/copy on login account cards; no seed exposed.
- History passwords stay masked until explicit reveal, and restore through the existing editor confirmation.
- Passphrase options: space, underscore or dot separator; capitalization; random three-digit suffix. All word selection still uses SecureRandom and the 7,776-word EFF dictionary. Hyphen is deliberately excluded because the dictionary contains hyphenated words.
- Empty trash has a separate irreversible-delete confirmation and cleans encrypted orphan documents only after the vault update succeeds; active entries are retained.
- Recognizes additional browser variants, retaining exact HTTPS origin gates. Recognition does not prove browser compatibility on an OEM phone.

Support: help@choicematrix.in. Physical hardware checks remain outstanding because no device is connected. No store submission is performed by this upgrade.
