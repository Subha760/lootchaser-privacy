package app.kavorynx.vault

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** On API 30+ the system supports strong biometrics OR the device PIN/pattern/password.
 *  On API 28-29 only strong biometrics can unwrap the Keystore key; master password is fallback.
 *  'Weak' 2D face recognition is deliberately unsupported for vault decryption.
 */
class DeviceUnlock(private val repo: VaultRepository) {
    private var authenticating = false
    private val alias = "kavorynx_keystore_auth_v2"
    private val legacyAlias = "kavorynx_keystore_auth_v1"
    private fun flags(): Int = BiometricManager.Authenticators.BIOMETRIC_STRONG or
        (if (Build.VERSION.SDK_INT >= 30) BiometricManager.Authenticators.DEVICE_CREDENTIAL else 0)
    fun available(activity: FragmentActivity): Boolean =
        BiometricManager.from(activity).canAuthenticate(flags()) == BiometricManager.BIOMETRIC_SUCCESS

    private fun readKey(name: String): SecretKey? =
        (KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.getKey(name, null) as? SecretKey)

    fun enable(activity: FragmentActivity, onResult: (Boolean, String) -> Unit) {
        if (authenticating) return
        if (!available(activity)) { onResult(false, "Set up a strong biometric or supported device lock in Android settings"); return }
        val dek = try { VaultSession.rawKeyForBiometricSetup() }
        catch (t: Exception) { onResult(false, "Unlock the vault first"); return }
        try {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= 30) {
                spec.setUserAuthenticationParameters(10,
                    KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL)
            } else {
                spec.setUserAuthenticationValidityDurationSeconds(-1)
            }
            keyGenerator.init(spec.build()); val key = keyGenerator.generateKey()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            if (Build.VERSION.SDK_INT < 30) cipher.init(Cipher.ENCRYPT_MODE, key)
            prompt(activity, if (Build.VERSION.SDK_INT >= 30) null else cipher, "Enable quick unlock", onFailure = { reason ->
                dek.fill(0)
                onResult(false, reason)
            }) { authenticated ->
                try {
                    if (!activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) || activity.isFinishing) throw IllegalStateException("Activity stopped")
                    val ready = authenticated ?: cipher.apply { init(Cipher.ENCRYPT_MODE, key) }
                    val packed = ready.iv + ready.doFinal(dek)
                    repo.saveDeviceWrap("v2:" + Crypto.b64(packed))
                    onResult(true, "Quick unlock enabled")
                } catch (t: Exception) { onResult(false, "Could not enable unlock") }
                finally { dek.fill(0) }
            }
        } catch (t: Exception) { dek.fill(0); onResult(false, "Keystore setup failed or was cancelled") }
    }

    fun disable() {
        // Unwrap material is deleted first; deleting the Keystore alias further reduces attack surface.
        repo.removeDeviceWrap()
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        for (name in listOf(alias, legacyAlias)) if (store.containsAlias(name)) store.deleteEntry(name)
    }

    fun unlock(activity: FragmentActivity, onResult: (Boolean, String) -> Unit) {
        if (authenticating) return
        if (!repo.hasDeviceUnlock()) { onResult(false, "Enable quick unlock in Settings first"); return }
        if (!available(activity)) { onResult(false, "Biometric/device credential not available; use master password"); return }
        try {
            val stored = repo.readDeviceWrap()
            val modern = stored.startsWith("v2:")
            val timed = modern && Build.VERSION.SDK_INT >= 30
            val key = readKey(if (modern) alias else legacyAlias) ?: throw IllegalStateException("Keystore key missing")
            val packed = Crypto.unb64(if (modern) stored.removePrefix("v2:") else stored)
            require(packed.size >= 28)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            if (!timed) cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, packed.copyOfRange(0, 12)))
            prompt(activity, if (timed) null else cipher, "Unlock Docryvia", onFailure = { reason ->
                onResult(false, reason)
            }) { authenticated ->
                try {
                    val ready = authenticated ?: cipher.apply { init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, packed.copyOfRange(0, 12))) }
                    val dek = ready.doFinal(packed.copyOfRange(12, packed.size))
                    if (activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) && !activity.isFinishing) {
                        VaultSession.start(dek, repo)
                        onResult(true, "Vault unlocked")
                    } else { dek.fill(0); onResult(false, "Unlock cancelled after leaving app") }
                } catch (t: Exception) { onResult(false, "Quick unlock failed; use master password") }
            }
        } catch (t: Exception) {
            if (t is KeyPermanentlyInvalidatedException) {
                try { disable() } catch (_: Exception) { /* already invalidated */ }
            }
            onResult(false, "Device credential changed or unavailable; use master password")
        }
    }

    private fun prompt(activity: FragmentActivity, cipher: Cipher?, title: String,
        onFailure: (String) -> Unit, onSuccess: (Cipher?) -> Unit) {
        if (authenticating) { onFailure("Authentication already in progress"); return }
        authenticating = true
        var terminal = false
        var observer: LifecycleEventObserver? = null
        fun complete(): Boolean {
            if (terminal) return false
            terminal = true; authenticating = false
            observer?.let { activity.lifecycle.removeObserver(it) }
            return true
        }
        val config = BiometricPrompt.PromptInfo.Builder().setTitle(title)
            .setSubtitle("Your secrets never leave this device")
            .setAllowedAuthenticators(flags())
        if (Build.VERSION.SDK_INT < 30) config.setNegativeButtonText("Use master password")
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    if (!complete()) return
                    val confirmedCipher = result.cryptoObject?.cipher
                    if (cipher != null && confirmedCipher == null) onFailure("Authentication method unavailable; use master password")
                    else onSuccess(confirmedCipher)
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // Cancellation/error is terminal; do not leave pending key material in RAM.
                    if (complete()) onFailure("Quick unlock cancelled or unavailable; use master password")
                }
            })
        observer = LifecycleEventObserver { _, event ->
            if ((event == Lifecycle.Event.ON_DESTROY || (cipher != null && event == Lifecycle.Event.ON_STOP)) && complete()) {
                prompt.cancelAuthentication()
                onFailure("Quick unlock cancelled after leaving app")
            }
        }
        activity.lifecycle.addObserver(observer!!)
        try {
            if (cipher == null) prompt.authenticate(config.build())
            else prompt.authenticate(config.build(), BiometricPrompt.CryptoObject(cipher))
        }
        catch (t: Exception) { if (complete()) onFailure("Quick unlock unavailable") }
    }
}
