# Docryvia v0.6.0-rc2

Android password and document vault, published by **choicematrix**. Support: **help@choicematrix.in**.

[Public privacy policy](https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html) · [Review and verification](docs/V0_6_REVIEW.md) · [Device acceptance tests](docs/QA_MANUAL_TEST_PLAN.md)

This is a tested build candidate, not independent security certification or store approval. The uploaded desktop-labelled archive supplied Windows build scripts for the Android app; there is no native desktop application here.

## Changes
- Reuse an authenticated vault during brief app switches (30-second maximum background grace); screen-off and manual lock clear the session.
- Browser autofill and save confirmation reuse an already unlocked session, with explicit account selection/approval.
- Optional favourite-food, first-school or nickname recovery question plus a separate random rescue code; questions alone cannot unlock the vault.
- Successful question recovery consumes its kit. Password changes/resets disable stored device unlock. Confirm new passwords and save rescue codes offline.
- Preserve autofill record metadata and case-sensitive import identities; additional temporary key/plaintext buffer cleanup and prompt guards.
- Add publisher/support information and the public privacy-policy link to Settings.

The existing v0.5 vault format, package ID and cryptographic identifiers are retained. Keep encrypted backups before installing updates; uninstalling clears local data.

## Build
Use JDK 17, Android SDK Platform 36, Build Tools 35.0.0, the supplied Gradle 8.13 wrapper and Kotlin 2.0.21.

```sh
cd android
chmod +x gradlew
./gradlew --no-daemon :app:lintDebug :app:testDebugUnitTest :app:assembleDebug
```

For signed builds, privately restore the original signing key and create `android/keystore.properties` using the supplied example. Do not publish this configuration or your key. Maintain the same signing identity for updates to existing installations.

```sh
./gradlew --no-daemon :app:assembleRelease :app:bundleRelease
```

On Windows, `Build-Signed-App.cmd` runs the provided PowerShell build helper after JDK/SDK/private signing setup.

The shareable source intentionally contains no private signing keys, signing passwords, build caches or old binaries. Supplied release APK/AAB downloads are separate. See the review for test evidence and remaining device, browser, biometric, independent security and legal/store checks.
