# Docryvia v0.8.0-rc1

Offline Android password, document and authenticator vault by choicematrix. Support: help@choicematrix.in.

[Privacy policy](https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html) · [Upgrade and verification](docs/V0_7_UPGRADE.md)

## Features
- AES-256-GCM local vault, master password, Android device unlock and independent recovery key.
- Optional question plus separate random rescue code; old recovery kits remain readable.
- Passwords, wallet records, notes, favourites, expiry dates and encrypted custom fields.
- TOTP authenticator with SHA1/SHA256/SHA512, six to eight digits, configured periods and offline QR scanning.
- Five-entry encrypted password history, encrypted 30-day Trash with restore and permanent deletion.
- RAM/shared-memory PDF and image preview; separate authenticated encrypted document files; portable encrypted backups.
- SecureRandom character options and EFF 7,776-word passphrase generator.
- Foreground inactivity locking, 30-second background grace, immediate screen-off/manual lock and Quick Settings tile.
- Exact-HTTPS browser autofill, keyboard inline suggestions with dropdown fallback, and manually associated native apps pinned to their signing identity.
- Google, 1Password and KeePass CSV and unencrypted Bitwarden JSON imports with preview and skipped-record details.
- System dark mode and externalized interface strings.

## Compatibility and setup
Android 9+ (API 28). Version code 8 uses the existing app ID and release signing certificate. Install the APK over the previous version; do not uninstall to upgrade. Existing schema-v1 vaults and backups remain readable; new writes use schema v2. Downgrading to old app versions after migration is not supported.

Unlock with your master password, then open Settings to enable Device unlock and select Docryvia as Android's autofill service. If Device unlock was already enabled, disable and enable it again to create the improved authentication wrapper. Autofill appears when you focus a supported login field; opening a web page alone does not trigger it. Camera access is requested only when scanning an authenticator QR code. For native autofill, explicitly associate a trusted installed app with the login.

## Build and verification
Use JDK 17, Gradle 8.13, AGP 8.13.2 and Android SDK 36. Configure your own SDK in `android/local.properties` and signing in `android/keystore.properties`; private signing files are excluded from the source download. The Windows helper uses those local settings. Release builds refuse to run without signing configuration.

From `android`, run `gradle :app:testDebugUnitTest :app:testReleaseUnitTest :app:lintDebug :app:lintRelease :app:assembleRelease :app:bundleRelease`. Run `python tests/source_contract.py` from the project root. Automated and simulated-device evidence is in `docs/verification`. Tests do not replace OEM fingerprint, camera, keyboard, real-browser or physical-device acceptance testing.

## Publishing
The Indus deployment kit contains the signed APK and pinned manual workflow requested by the user. Its marketplace action upgrades an existing registered app; complete the initial Indus listing and configure `INDUS_APP_STORE_API_TOKEN` securely in your chosen GitHub repository before running it. No Indus submission is performed by building this project.

## v0.8 organization upgrade

Category and favorite filters, stable sorting, metadata search, and confirmed duplicate review preserve conflicting account data. See docs/V0_8_UPGRADE.md and docs/SCREENSHOTS.md for validation and isolated screenshot capture.
