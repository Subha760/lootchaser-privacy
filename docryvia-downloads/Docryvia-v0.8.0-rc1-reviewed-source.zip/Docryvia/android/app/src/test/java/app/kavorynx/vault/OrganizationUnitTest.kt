package app.kavorynx.vault

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = DocryviaApp::class)
class OrganizationUnitTest {
    @Test fun duplicateGroupsRespectExactUsernameAndSubdomains() {
        val base = VaultItem(id = "a", site = "https://example.com", username = "Alex", secret = "first")
        val rows = listOf(base, base.copy(id = "b", site = "https://EXAMPLE.com/login", secret = "second"), base.copy(id = "c", username = "alex"), base.copy(id = "d", username = " Alex"), base.copy(id = "e", site = "https://www.example.com"), base.copy(id = "f", site = "http://example.com"), base.copy(id = "g", isDeleted = true))
        val group = VaultOrganization.duplicates(rows).single()
        assertEquals(setOf("a", "b"), group.items.map { it.id }.toSet())
        assertTrue(group.conflictingPasswords)
        assertEquals(2, PasswordHealth.analyze(rows.filterNot { it.isDeleted }.map { PasswordHealthInput(it.id, it.site, it.username, it.secret) }).duplicateAccounts)
    }
    @Test fun filteringUsesMetadataOnlyAndDoesNotSearchSecretsOrTrash() {
        val base = VaultItem(id = "a", title = "Work Email", username = "Alex", category = "Work", favorite = true, secret = "HiddenNeedle", notes = "PrivateNeedle")
        val rows = listOf(base, base.copy(id = "b", favorite = false), base.copy(id = "c", isDeleted = true))
        assertEquals(listOf("a"), VaultOrganization.select(rows, "email Alex", "Work", true).map { it.id })
        assertTrue(VaultOrganization.select(rows, "HiddenNeedle").isEmpty())
        assertTrue(VaultOrganization.select(rows, "PrivateNeedle").isEmpty())
        assertTrue(VaultOrganization.select(rows, "", "Personal").isEmpty())
        assertEquals(listOf(base.copy(category = " Work ")), VaultOrganization.select(listOf(base.copy(category = " Work ")), category = "Work"))
        assertEquals("General", VaultOrganization.categoryLabel(base.copy(category = "  ")))
    }
    @Test fun sortOrdersAreStableForTies() {
        val rows = listOf(VaultItem(id = "b", title = "Zulu", created = 1), VaultItem(id = "a", title = "Alpha", created = 2), VaultItem(id = "c", title = "Alpha", created = 2))
        assertEquals(listOf("a", "c", "b"), VaultOrganization.select(rows).map { it.id })
        assertEquals(listOf("a", "c", "b"), VaultOrganization.select(rows, sort = VaultSort.NEWEST).map { it.id })
        assertEquals(listOf("b", "a", "c"), VaultOrganization.select(rows, sort = VaultSort.OLDEST).map { it.id })
    }
    @Test fun duplicateRemovalPreservesKeeperAndConflictingDataAndIsRestorable() {
        VaultSession.lock(); val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit(); app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        val repo = VaultRepository(app); val (key, _) = repo.create("organization password".toCharArray())
        val keep = VaultItem(id = "keep", site = "https://example.com", username = "Alex", secret = "original", notes = "Keep note", history = listOf(PasswordHistoryEntry("past", 1)))
        val copy = keep.copy(id = "copy", secret = "different", notes = "Copy note", totpSecret = "JBSWY3DPEHPK3PXP")
        repo.write(key, listOf(keep, copy)); VaultSession.start(key, repo)
        VaultSession.trashDuplicate("copy", "keep", repo)
        assertEquals(keep, VaultSession.activeItems.single())
        assertEquals(copy, VaultSession.items.single { it.id == "copy" }.copy(isDeleted = false, deletedAt = 0L))
        VaultSession.restore("copy", repo); assertEquals(copy, VaultSession.items.single { it.id == "copy" })
        VaultSession.lock()
    }
    @Test fun staleOrUnrelatedDuplicateSelectionDoesNotMutateVault() {
        VaultSession.lock(); val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit(); app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        val repo = VaultRepository(app); val (key, _) = repo.create("organization password".toCharArray())
        val a = VaultItem(id = "a", site = "https://example.com", username = "Alex")
        val b = a.copy(id = "b", username = "alex")
        repo.write(key, listOf(a, b)); VaultSession.start(key, repo)
        for (pair in listOf("a" to "a", "a" to "b", "missing" to "b")) {
            try { VaultSession.trashDuplicate(pair.first, pair.second, repo); fail("Invalid selection") } catch (_: IllegalArgumentException) { }
            assertEquals(listOf(a, b), VaultSession.items)
        }
        VaultSession.lock()
    }
    @Test fun releaseAndDebugCannotEnableDemoDataOrNavigation() {
        assertFalse(BuildConfig.DEMO_MODE)
        try { DemoVault.prepare(RuntimeEnvironment.getApplication(), VaultRepository(RuntimeEnvironment.getApplication())); fail("Demo disabled") }
        catch (_: IllegalStateException) { }
    }
    @Test fun importsRetainDifferentMetadataAndAvoidOverwritingCollidingIds() {
        VaultSession.lock(); val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit(); app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        val repo = VaultRepository(app); val (key, _) = repo.create("organization import password".toCharArray())
        val original = VaultItem(id = "same", site = "https://example.com", username = "Alex", secret = "password", notes = "Original")
        repo.write(key, listOf(original)); VaultSession.start(key, repo)
        val incoming = original.copy(notes = "Imported", totpSecret = "JBSWY3DPEHPK3PXP")
        VaultSession.import(repo, listOf(incoming, incoming.copy(id = "random", created = 12)))
        assertEquals(2, VaultSession.items.size)
        assertEquals(original, VaultSession.items.single { it.id == "same" })
        val retained = VaultSession.items.single { it.id != "same" }
        assertEquals(incoming.copy(id = retained.id), retained)
        VaultSession.import(repo, listOf(incoming.copy(id = "another", created = 99)))
        assertEquals(2, VaultSession.items.size)
        VaultSession.lock()
    }

}
