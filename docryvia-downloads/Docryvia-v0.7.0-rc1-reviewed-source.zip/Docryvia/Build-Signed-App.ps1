$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$studioJava = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
if (Test-Path (Join-Path $studioJava 'bin\java.exe')) { $env:JAVA_HOME = $studioJava }
if (-not $env:JAVA_HOME -or -not (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    throw 'Install Android Studio or JDK 17, then run this file again.'
}
$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk) { $sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path (Join-Path $sdk 'platforms\android-36\android.jar'))) {
    throw 'In Android Studio > SDK Manager, install Android SDK Platform 36 and Build Tools 35.0.0. Then run again.'
}
if (-not (Test-Path (Join-Path $root 'android\keystore.properties'))) {
    throw 'The private signing configuration is missing. Restore it from your signing backup; do not generate a new key for an existing installation.'
}
$tools = Join-Path $root 'tools'
New-Item -ItemType Directory -Force -Path $tools | Out-Null
$gradle = Join-Path $tools 'gradle-8.13\bin\gradle.bat'
if (-not (Test-Path $gradle)) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $archive = Join-Path $tools 'gradle-8.13-bin.zip'
    Write-Host 'Downloading and verifying Gradle 8.13...'
    Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile $archive
    $expected = (Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.13-bin.zip.sha256').Content.Trim()
    if ((Get-FileHash -Algorithm SHA256 $archive).Hash.ToLowerInvariant() -ne $expected.ToLowerInvariant()) {
        Remove-Item $archive
        throw 'Gradle download checksum failed.'
    }
    Expand-Archive -Path $archive -DestinationPath $tools -Force
}
# Forward slashes are valid in Windows Java properties and avoid escaped backslashes.
('sdk.dir=' + ($sdk -replace '\\','/')) | Set-Content -Encoding ASCII (Join-Path $root 'android\local.properties')
$env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH
Push-Location (Join-Path $root 'android')
try {
    & $gradle --no-daemon --console=plain :app:lintDebug :app:testDebugUnitTest :app:assembleRelease :app:bundleRelease
    if ($LASTEXITCODE -ne 0) { throw 'Android build failed. Review the errors above; no success is claimed.' }
} finally { Pop-Location }
$out = Join-Path $root 'deliverables'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$apk = Join-Path $root 'android\app\build\outputs\apk\release\app-release.apk'
$aab = Join-Path $root 'android\app\build\outputs\bundle\release\app-release.aab'
$signer = Join-Path $sdk 'build-tools\35.0.0\apksigner.bat'
if (-not (Test-Path $signer)) { throw 'Build Tools 35.0.0/apksigner missing. Install it through Android Studio.' }
& $signer verify --verbose --print-certs $apk
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
Copy-Item $apk (Join-Path $out 'Docryvia-v0.7.0-rc1-signed.apk') -Force
Copy-Item $aab (Join-Path $out 'Docryvia-v0.7.0-rc1-signed.aab') -Force
Write-Host 'Signed APK and AAB are ready in the deliverables folder.'
Start-Process explorer.exe $out
