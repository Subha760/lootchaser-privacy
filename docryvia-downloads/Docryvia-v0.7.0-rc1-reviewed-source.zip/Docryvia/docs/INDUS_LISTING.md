# Indus listing copy

Publisher: choicematrix
Support: help@choicematrix.in
Privacy policy: https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html
Package: app.kavorynx.vault

## Short description
Offline encrypted vault for passwords, documents and 2FA codes, with autofill.

## Description
Docryvia keeps your passwords, private documents, wallet records and authenticator accounts in an encrypted vault on your Android device.

• Store passwords, notes, addresses, identity records and custom fields.
• Generate passwords with selectable character groups or random EFF-wordlist passphrases.
• Generate time-based two-factor authentication codes offline. Add accounts by scanning a setup QR code or entering a seed.
• Preview supported PDFs and images inside the protected app.
• Restore accidentally deleted entries from encrypted Trash and review previous passwords.
• Fill supported HTTPS login forms using Android autofill. Compatible keyboards can show inline suggestions.
• Explicitly associate trusted installed apps with a login; app-signing identity changes block filling.
• Import supported Google, 1Password and KeePass CSV or unencrypted Bitwarden JSON exports with a confirmation preview.
• Make portable password-encrypted backups and restore compatible older vault backups.
• Choose inactivity locking, lock from Quick Settings, and follow your system dark-mode setting.

Docryvia's release build has no internet permission, ads, analytics or developer-managed cloud account. Android controls optional fingerprint/device-lock authentication. Camera permission is requested only for QR scanning. Browser, keyboard and biometric support depends on your device and system setup.

You control the master password and recovery material. Optional question recovery also requires a separate random rescue code. Keep encrypted backups and recovery codes offline; the publisher cannot recover a vault without the required keys.

Support: help@choicematrix.in
