# Docryvia — Draft Terms of Use
**Release-candidate draft dated 10 October 2026. Requires legal review before production publication.**

Publisher: choicematrix. Support: help@choicematrix.in.
Privacy policy: https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html

This pre-release project is provided to evaluate design and implementation. **Do not rely on it as your only password backup or use real credentials until a completed build, device testing, and independent security review.**

The app is designed for lawful personal password management, notes, identity details and documents. You are responsible for choosing and remembering a strong master password, safely recording the recovery key, maintaining encrypted backups, protecting your device, and checking website origins before sharing or autofilling.

There is no developer-managed account recovery or sync server. If the master password, main recovery key, and either part of any optional question rescue kit are lost, encrypted content may be permanently inaccessible. Security answers alone cannot recover your data. Changes to device credentials or biometrics may invalidate biometric quick unlock.

Never use Docryvia to store payment-card security codes (CVV/CVC), to bypass another app's authorization, or to disclose other people's private information without their consent.

Before production publication the app operator should add proper legal identity, contact information, governing law, warranty and liability terms appropriate to applicable law and platform rules. This text is a draft for review, not a substitute for legal advice.
