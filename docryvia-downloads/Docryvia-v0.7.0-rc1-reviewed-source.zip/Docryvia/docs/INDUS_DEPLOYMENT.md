# Docryvia Indus deployment kit

Prepared for publisher choicematrix. Support: help@choicematrix.in.

This kit contains the verified signed Docryvia v0.7.0-rc1 APK and a manual GitHub workflow using the exact action requested by the user: https://github.com/marketplace/actions/indus-appstore-release.

## Setup
1. Put the kit's `.github/workflows/indus-release.yml` and `release/Docryvia-v0.7.0-rc1-signed.apk` in your chosen GitHub repository, preserving these paths.
2. In repository Settings → Secrets and variables → Actions, add `INDUS_APP_STORE_API_TOKEN` using the API token from your Indus Developer account. Never paste the token into a chat, commit, release note or public file.
3. Confirm that app.kavorynx.vault has an existing eligible Indus app entry. This action calls `/devtools/apk/upgrade/app.kavorynx.vault`; it does not register a first listing. Complete developer verification and any first-listing requirements in the Indus console.
4. Open Actions → Release Docryvia to Indus Appstore → Run workflow. An upload can be executed after credentials/app entry are available; publication remains subject to Indus processing/review.

The workflow checks the exact APK SHA-256 before uploading, is manual-only, and pins the third-party action to its inspected v1 commit. Because this APK is already signed, keystore_source is none: the private signing key is not needed by the uploader. The package/version/certificate match the reviewed release candidate. There is no fake successful deployment or placeholder API token.

Public privacy policy: https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html

The action accepts APK, AAB and APKS, but its AAB path can upload signing material; this kit deliberately uses the existing signed APK. Keep release notes fixed: the upstream uploader builds its curl command with shell eval. For future versions, replace the APK, SHA-256 and notes together after validation. The current candidate still needs real-device/browser/biometric testing and independent security review; uploading does not certify those checks.
