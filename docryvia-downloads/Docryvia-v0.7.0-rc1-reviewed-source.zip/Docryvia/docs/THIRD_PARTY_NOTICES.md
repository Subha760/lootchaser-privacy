# Third-party notices

Docryvia uses AndroidX/Jetpack libraries (Apache License 2.0), Kotlin/Kotlin coroutines (Apache License 2.0), ZXing and JourneyApps ZXing Android Embedded (Apache License 2.0). Dependency versions are listed in android/app/build.gradle.kts. Original license metadata is retained where the libraries provide it; upstream source and notices remain available from their respective projects.

Passphrases use the EFF long wordlist (7,776 words). See WORDLIST_LICENSE.md for attribution, source and CC BY 3.0 US license details. Docryvia branding and supplied artwork came from the user's project.
