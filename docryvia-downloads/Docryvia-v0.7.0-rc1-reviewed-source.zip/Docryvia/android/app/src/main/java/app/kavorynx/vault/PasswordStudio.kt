package app.kavorynx.vault

import java.security.SecureRandom

data class PasswordOptions(val length: Int = 24, val upper: Boolean = true, val lower: Boolean = true,
    val numbers: Boolean = true, val symbols: Boolean = true, val excludeAmbiguous: Boolean = true)
object PasswordStudio {
    private val random = SecureRandom()
    fun password(o: PasswordOptions): String {
        require(o.length in 8..128)
        val groups = listOfNotNull(if (o.upper) "ABCDEFGHIJKLMNOPQRSTUVWXYZ" else null,
            if (o.lower) "abcdefghijklmnopqrstuvwxyz" else null, if (o.numbers) "0123456789" else null,
            if (o.symbols) "!@#\$%^&*()-_=+[]{}:,.?" else null).map { g -> if (o.excludeAmbiguous) g.filterNot { it in "0O1lI" } else g }
        require(groups.isNotEmpty()) { "Select at least one character group" }
        val alphabet = groups.joinToString("")
        val result = CharArray(o.length)
        // Rejection sampling gives uniform draws among strings containing every selected group.
        do { result.indices.forEach { result[it] = alphabet[random.nextInt(alphabet.length)] } }
        while (groups.any { g -> result.none { it in g } })
        return String(result).also { result.fill('\u0000') }
    }
    fun passphrase(words: List<String>, count: Int = 6, separator: String = " "): String {
        require(words.size >= 2000 && words.distinct().size == words.size && count in 4..10)
        require(separator.isNotEmpty() && words.none { it.contains(separator) }) { "Separator must not occur inside a word" }
        return (0 until count).joinToString(separator) { words[random.nextInt(words.size)] }
    }
}
