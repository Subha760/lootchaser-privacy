package app.kavorynx.vault

import android.os.Bundle
import android.view.WindowManager
import com.journeyapps.barcodescanner.CaptureActivity

class SecureCaptureActivity : CaptureActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        super.onCreate(savedInstanceState)
        if (!VaultSession.unlocked) finish()
    }
    override fun onUserInteraction() { super.onUserInteraction(); LockPreferences.interaction() }
    override fun onResume() { super.onResume(); if (!VaultSession.unlocked) finish() }
}
