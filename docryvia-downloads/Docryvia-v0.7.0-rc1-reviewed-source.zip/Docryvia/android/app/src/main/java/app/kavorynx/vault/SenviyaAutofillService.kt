package app.kavorynx.vault

import android.app.PendingIntent
import android.content.Intent
import android.os.CancellationSignal
import android.service.autofill.AutofillService
import android.service.autofill.FillCallback
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.SaveCallback
import android.service.autofill.SaveInfo
import android.service.autofill.SaveRequest
import android.app.assist.AssistStructure
import android.view.View
import android.view.autofill.AutofillId
import android.widget.RemoteViews
import java.util.Locale

/**
 * Conservative Android AutofillService: Chrome-class supported browsers + verified HTTPS host
 * only. We never return plaintext datasets until the user explicitly authenticates. Android
 * renders the initial dropdown and save confirmation: an app cannot safely replace that UI.
 */
class SenviyaAutofillService : AutofillService() {
    override fun onFillRequest(request: FillRequest, cancellationSignal: CancellationSignal, callback: FillCallback) {
        try {
            if (cancellationSignal.isCanceled) { callback.onSuccess(null); return }
            val structure = request.fillContexts.lastOrNull()?.structure ?: run { callback.onSuccess(null); return }
            val fields = FieldScanner.scan(structure)
            val caller = structure.activityComponent?.packageName ?: ""
            val browser = caller in FieldScanner.browsers
            val native = !browser && !fields.hasWebContent && AppIdentity.signature(this, caller) != null
            if (fields.password == null || (!native && (!browser || fields.webHost == null))) {
                callback.onSuccess(null); return
            }
            val origin = if (native) caller else fields.webHost!!
            val response = FillResponse.Builder()
            if (browser) {
                val saveBuilder = SaveInfo.Builder(SaveInfo.SAVE_DATA_TYPE_PASSWORD, arrayOf(fields.password))
                    .setDescription("Save a login for $origin to Docryvia")
                fields.username?.let { saveBuilder.setOptionalIds(arrayOf(it)) }
                response.setSaveInfo(saveBuilder.build())
            }
            if (VaultRepository(this).exists()) {
                val ids = listOfNotNull(fields.username, fields.password).toTypedArray()
                val matching = if (VaultSession.unlocked) {
                    if (native) VaultSession.accountsForApp(this, caller) else VaultSession.accountsForHost(origin)
                } else emptyList()
                val inlineRequest = if (android.os.Build.VERSION.SDK_INT >= 30) request.inlineSuggestionsRequest else null
                val specs = if (android.os.Build.VERSION.SDK_INT >= 30) inlineRequest?.inlinePresentationSpecs.orEmpty() else emptyList()
                val inlineReady = android.os.Build.VERSION.SDK_INT >= 30 && (inlineRequest?.maxSuggestionCount ?: 0) > 0 && specs.firstOrNull()?.let {
                    androidx.autofill.inline.UiVersions.getVersions(it.style).contains(androidx.autofill.inline.UiVersions.INLINE_UI_VERSION_1)
                } == true
                val choices: List<VaultItem?> = if (android.os.Build.VERSION.SDK_INT >= 30 && inlineReady && matching.isNotEmpty()) matching.take(inlineRequest!!.maxSuggestionCount) else listOf(null)
                for ((index, item) in choices.withIndex()) {
                    val intent = Intent(this, AutofillUnlockActivity::class.java).apply {
                        putExtra("verified_browser", caller); putExtra("requested_domain", origin)
                        putExtra("native_app", native)
                        putExtra("field_user", fields.username); putExtra("field_password", fields.password)
                        putExtra("dataset_auth", inlineReady); item?.let { putExtra("selected_item", it.id) }
                    }
                    val pi = PendingIntent.getActivity(this, java.security.SecureRandom().nextInt(), intent,
                        PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_MUTABLE)
                    val label = if (item != null) "Docryvia • ${item.username.ifBlank { item.title }}" else "Docryvia • Unlock"
                    val presentation = RemoteViews(packageName, android.R.layout.simple_list_item_1).apply { setTextViewText(android.R.id.text1, label) }
                    if (inlineReady && android.os.Build.VERSION.SDK_INT >= 30) {
                        val spec = specs[minOf(index, specs.lastIndex)]
                        val content = androidx.autofill.inline.v1.InlineSuggestionUi.newContentBuilder(pi).setTitle(label).build()
                        val inline = android.service.autofill.InlinePresentation((content as androidx.autofill.inline.UiVersions.Content).slice, spec, false)
                        val dataset = android.service.autofill.Dataset.Builder(presentation).setAuthentication(pi.intentSender)
                            .setInlinePresentation(inline).setId("docryvia:$index")
                        ids.forEach { dataset.setValue(it, null) }
                        response.addDataset(dataset.build())
                    } else response.setAuthentication(ids, pi.intentSender, presentation)
                }
            }
            callback.onSuccess(response.build())
        } catch (_: Exception) { callback.onSuccess(null) }
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        try {
            val structure = request.fillContexts.lastOrNull()?.structure ?: error("Missing form")
            val caller = structure.activityComponent?.packageName ?: ""
            val fields = FieldScanner.scan(structure)
            val host = fields.webHost ?: error("No verified HTTPS host")
            val details = FieldScanner.extractInput(structure, fields)
            if (caller !in FieldScanner.browsers || details.second.isBlank() ||
                DomainPolicy.canonicalHost("https://$host") != host || !VaultRepository(this).exists()) {
                callback.onFailure("Form could not be verified"); return
            }
            val intent = Intent(this, SaveCredentialActivity::class.java).apply {
                putExtra("site_domain", host)
                putExtra("site_user", details.first)
                putExtra("site_pass", details.second)
            }
            val pi = PendingIntent.getActivity(this, java.security.SecureRandom().nextInt(), intent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_MUTABLE)
            // The OS opens our authentication/confirmation screen only AFTER the user agreed to save.
            callback.onSuccess(pi.intentSender)
        } catch (_: Exception) { callback.onFailure("Unable to securely save this login") }
    }
}

internal data class FoundFields(val username: AutofillId?, val password: AutofillId?, val webHost: String?, val hasWebContent: Boolean = false)
internal object FieldScanner {
    // Do not add unverified native app packages here: Digital Asset Links checks are required.
    val browsers = setOf("com.android.chrome", "com.chrome.beta", "com.chrome.dev", "org.mozilla.firefox", "org.mozilla.firefox_beta",
        "com.sec.android.app.sbrowser", "com.brave.browser", "com.microsoft.emmx",
        "com.opera.browser", "com.vivaldi.browser")

    fun scan(structure: AssistStructure): FoundFields {
        var username: AutofillId? = null
        var password: AutofillId? = null
        val domains = mutableSetOf<String>()
        fun walk(n: AssistStructure.ViewNode) {
            n.webDomain?.let { raw ->
                // API 28+ reports webScheme separately. Never assume an HTTP page uses HTTPS.
                // Unknown scheme or mixed schemes => abort instead of taking a phishing risk.
                val originScheme = n.webScheme?.lowercase(Locale.ROOT)
                val host = if (originScheme == "https")
                    DomainPolicy.canonicalHost("https://$raw") else null
                if (host != null) domains.add(host)
                else domains.add("invalid-or-insecure-origin")
            }
            val hints = n.autofillHints?.map { it.lowercase(Locale.ROOT) } ?: emptyList()
            val html = n.htmlInfo?.attributes?.associate { it.first.lowercase(Locale.ROOT) to it.second.lowercase(Locale.ROOT) } ?: emptyMap()
            val fieldType = html["autocomplete"] ?: ""
            val id = n.autofillId
            val isPassword = hints.any { it == "password" || it == "current-password" || it == "new-password" } ||
                html["type"] == "password" || fieldType.contains("password") || (n.inputType and 0x00000080) != 0 && n.className?.contains("EditText") == true
            val isUsername = hints.any { it == "username" || it == "emailaddress" || it == "email" } ||
                html["type"] == "email" || fieldType.contains("username") || fieldType.contains("email")
            if (isPassword && id != null) password = id
            else if (isUsername && id != null) username = id
            for (i in 0 until n.childCount) walk(n.getChildAt(i))
        }
        for (i in 0 until structure.windowNodeCount) walk(structure.getWindowNodeAt(i).rootViewNode)
        return FoundFields(username, password, domains.singleOrNull()?.takeIf { it != "invalid-or-insecure-origin" }, domains.isNotEmpty())
    }

    fun extractInput(structure: AssistStructure, fields: FoundFields): Pair<String, String> {
        var user = ""
        var pass = ""
        fun walk(n: AssistStructure.ViewNode) {
            val value = n.autofillValue
            if (value?.isText == true) {
                if (fields.username != null && n.autofillId == fields.username) user = value.textValue?.toString() ?: ""
                if (n.autofillId == fields.password) pass = value.textValue?.toString() ?: ""
            }
            for (i in 0 until n.childCount) walk(n.getChildAt(i))
        }
        for (i in 0 until structure.windowNodeCount) walk(structure.getWindowNodeAt(i).rootViewNode)
        return user.take(256) to pass.take(4096)
    }
}
