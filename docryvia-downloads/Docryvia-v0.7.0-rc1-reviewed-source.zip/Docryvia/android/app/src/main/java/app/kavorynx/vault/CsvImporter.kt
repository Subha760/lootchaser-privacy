package app.kavorynx.vault

/** A bounded, local-only RFC4180-style CSV reader for exporting from Google Password Manager.
 *  No plaintext temporary files are created. Strings may remain in managed memory until collected.
 */
object CsvImporter {
    fun parse(text: String, requireGoogleColumns: Boolean = true): List<Map<String, String>> {
        require(text.length <= 5_000_000) { "CSV exceeds 5 MB" }
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        var field = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                quoted && ch == '"' && i + 1 < text.length && text[i + 1] == '"' -> { field.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                !quoted && ch == ',' -> { row.add(field.toString()); field = StringBuilder() }
                !quoted && (ch == '\n' || ch == '\r') -> {
                    row.add(field.toString()); field = StringBuilder()
                    if (row.any { it.isNotEmpty() }) rows.add(row)
                    require(rows.size <= 2001) { "Limit 2,000 rows" }
                    row = ArrayList()
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                }
                else -> field.append(ch)
            }
            i++
        }
        require(!quoted) { "Unclosed quoted field" }
        row.add(field.toString())
        if (row.any { it.isNotEmpty() }) rows.add(row)
        require(rows.size <= 2001) { "Limit 2,000 rows" }
        require(rows.isNotEmpty()) { "Empty CSV" }
        val header = rows.first().map { it.trim().trimStart('\uFEFF').lowercase() }
        require(header.distinct().size == header.size &&
            (!requireGoogleColumns || header.containsAll(listOf("url", "username", "password")))) { "Missing url/username/password columns" }
        return rows.drop(1).map { cells ->
            require(cells.size == header.size) { "Incorrect number of CSV columns" }
            header.zip(cells).toMap()
        }
    }
}
