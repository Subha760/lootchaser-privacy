package app.kavorynx.vault

import android.net.Uri
import java.nio.ByteBuffer
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class TotpConfig(val secret: String, val algorithm: String = "SHA1", val digits: Int = 6, val period: Int = 30)

object TotpGenerator {
    fun parse(input: String): TotpConfig {
        if (!input.startsWith("otpauth://", ignoreCase = true)) return TotpConfig(input).also { decode(it.secret).fill(0) }
        val uri = Uri.parse(input)
        require(uri.scheme == "otpauth" && uri.host == "totp") { "Only time-based TOTP codes are supported" }
        val config = TotpConfig(uri.getQueryParameter("secret") ?: error("Missing seed"),
            (uri.getQueryParameter("algorithm") ?: "SHA1").uppercase(Locale.ROOT),
            uri.getQueryParameter("digits")?.toInt() ?: 6, uri.getQueryParameter("period")?.toInt() ?: 30)
        validate(config); decode(config.secret).fill(0); return config
    }
    private fun validate(c: TotpConfig) {
        require(c.algorithm in setOf("SHA1", "SHA256", "SHA512") && c.digits in 6..8 && c.period in 15..120)
    }
    fun decode(input: String): ByteArray {
        val s = input.uppercase(Locale.ROOT).filterNot { it.isWhitespace() }.trimEnd('=')
        require(s.length in 16..1024 && s.all { it in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567" }) { "Invalid Base32 seed" }
        var acc = 0; var bits = 0; val out = java.io.ByteArrayOutputStream()
        s.forEach { acc = (acc shl 5) or "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567".indexOf(it); bits += 5
            if (bits >= 8) { bits -= 8; out.write((acc ushr bits) and 255) } }
        require(bits == 0 || (acc and ((1 shl bits) - 1)) == 0) { "Invalid Base32 padding" }
        return out.toByteArray()
    }
    fun code(config: TotpConfig, timeMillis: Long = System.currentTimeMillis()): String {
        validate(config); require(timeMillis >= 0)
        val seed = decode(config.secret)
        val counter = ByteBuffer.allocate(8).putLong(timeMillis / 1000 / config.period).array()
        var hash: ByteArray? = null
        try {
            val mac = Mac.getInstance("Hmac${config.algorithm}"); mac.init(SecretKeySpec(seed, mac.algorithm))
            val h = mac.doFinal(counter); hash = h
            val offset = h.last().toInt() and 15
            val binary = ((h[offset].toInt() and 127) shl 24) or ((h[offset + 1].toInt() and 255) shl 16) or
                ((h[offset + 2].toInt() and 255) shl 8) or (h[offset + 3].toInt() and 255)
            val modulus = if (config.digits == 6) 1_000_000 else if (config.digits == 7) 10_000_000 else 100_000_000
            return (binary % modulus).toString().padStart(config.digits, '0')
        } finally { seed.fill(0); counter.fill(0); hash?.fill(0) }
    }
}
