package app.kavorynx.vault

import android.app.Application
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.Build
import android.content.pm.ApplicationInfo
import android.os.StrictMode

/** StrictMode is active only for debug builds; no user content is logged intentionally. */
class DocryviaApp : Application() {
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = SessionTimeout()
    private var startedActivities = 0
    private val lockTask = Runnable { VaultSession.lock() }
    private val inactivityTask = object : Runnable {
        override fun run() {
            if (startedActivities > 0 && VaultSession.unlocked && LockPreferences.shouldLock(this@DocryviaApp)) VaultSession.lock()
            handler.postDelayed(this, 5_000L)
        }
    }
    override fun onCreate() {
        super.onCreate()
        UiText.resources = resources
        handler.postDelayed(inactivityTask, 5_000L)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                if (startedActivities++ == 0) {
                    handler.removeCallbacks(lockTask)
                    LockPreferences.interaction()
                    if (timeout.foreground(SystemClock.elapsedRealtime())) VaultSession.lock()
                }
            }
            override fun onActivityStopped(activity: Activity) {
                startedActivities = (startedActivities - 1).coerceAtLeast(0)
                if (startedActivities == 0) {
                    timeout.background(SystemClock.elapsedRealtime())
                    handler.removeCallbacks(lockTask)
                    handler.postDelayed(lockTask, 30_000L)
                }
            }
            override fun onActivityCreated(activity: Activity, state: Bundle?) = Unit
            override fun onActivityResumed(activity: Activity) = Unit
            override fun onActivityPaused(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, state: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
        val screenOffReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF) VaultSession.lock()
            }
        }
        val screenOffFilter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenOffReceiver, screenOffFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            // SCREEN_OFF is a protected system broadcast; third-party apps cannot send it.
            registerReceiver(screenOffReceiver, screenOffFilter)
        }
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
            StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder()
                .detectAll().penaltyLog().build())
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder()
                .detectAll().penaltyLog().build())
        }
    }
}
