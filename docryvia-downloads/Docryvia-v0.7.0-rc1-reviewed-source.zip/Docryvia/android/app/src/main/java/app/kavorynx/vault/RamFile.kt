package app.kavorynx.vault

import android.os.ParcelFileDescriptor
import androidx.annotation.Keep

/** Seekable anonymous Linux RAM inode. Never opens a disk path or exports a descriptor. */
@Keep
object RamFile {
    init { System.loadLibrary("docryvia_ramfile") }
    @JvmStatic external fun createFd(): Int
    fun descriptor(bytes: ByteArray): ParcelFileDescriptor {
        val fd = createFd()
        check(fd >= 0) { "Seekable RAM files are unavailable on this device" }
        val descriptor = ParcelFileDescriptor.adoptFd(fd)
        try {
            ParcelFileDescriptor.AutoCloseOutputStream(ParcelFileDescriptor.dup(descriptor.fileDescriptor)).use { it.write(bytes) }
            check(descriptor.statSize == bytes.size.toLong())
            return descriptor
        } catch (t: Throwable) { descriptor.close(); throw t }
    }
}
