package app.kavorynx.vault

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import java.security.MessageDigest

data class InstalledApp(val packageName: String, val label: String, val signature: String)
object AppIdentity {
    @Suppress("DEPRECATION")
    fun signature(context: Context, pkg: String): String? = runCatching {
        val info = context.packageManager.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
        val certificates = info.signingInfo?.apkContentsSigners ?: return null
        certificates.map { certificate -> MessageDigest.getInstance("SHA-256").digest(certificate.toByteArray())
            .joinToString("") { "%02x".format(it.toInt() and 255) } }.sorted().joinToString(":")
    }.getOrNull()
    @Suppress("DEPRECATION")
    fun installed(context: Context): List<InstalledApp> = context.packageManager
        .queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .mapNotNull { r -> val pkg = r.activityInfo.packageName
            if (pkg == context.packageName || pkg in FieldScanner.browsers) null
            else signature(context, pkg)?.let { InstalledApp(pkg, r.loadLabel(context.packageManager).toString(), it) }
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
}
