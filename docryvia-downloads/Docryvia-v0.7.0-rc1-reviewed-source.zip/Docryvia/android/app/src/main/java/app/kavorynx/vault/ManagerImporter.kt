package app.kavorynx.vault

import org.json.JSONObject
import java.util.Locale

data class ImportPreview(val items: List<VaultItem>, val skipped: List<String>, val format: String) {
    val total: Int get() = items.size + skipped.size
}
object ManagerImporter {
    fun parse(source: String): ImportPreview {
        require(source.length <= 5_000_000) { "Import exceeds 5 MB" }
        val ready = mutableListOf<VaultItem>(); val skipped = mutableListOf<String>()
        var format: String
        fun login(row: Int, title: String, site: String, username: String, password: String, notes: String, totp: String = "") {
            if (DomainPolicy.canonicalHost(site) == null || password.isEmpty()) { skipped += "Record $row: missing password or valid HTTPS website"; return }
            val seed = if (totp.isBlank()) "" else runCatching { TotpGenerator.parse(totp); totp }.getOrElse {
                skipped += "Record $row: unsupported authenticator seed"; return
            }
            ready += VaultItem(title = title.ifBlank { DomainPolicy.canonicalHost(site) ?: "Login" },
                site = site, username = username, secret = password, notes = notes, totpSecret = seed)
        }
        if (source.trimStart().startsWith("{")) {
            format = "Bitwarden JSON"
            val root = JSONObject(source); val array = root.getJSONArray("items"); require(array.length() <= 2000)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                if (item.optBoolean("deleted") || !item.isNull("deletedDate") && item.has("deletedDate")) { skipped += "Record ${i + 1}: deleted entry"; continue }
                when (item.optInt("type")) {
                    1 -> {
                        val l = item.optJSONObject("login")
                        val uris = l?.optJSONArray("uris")
                        val site = uris?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("uri") }
                            .firstOrNull { DomainPolicy.canonicalHost(it) != null } } ?: ""
                        login(i + 1, item.optString("name"), site, l?.optString("username") ?: "", l?.optString("password") ?: "", item.optString("notes"), l?.optString("totp") ?: "")
                    }
                    2 -> ready += VaultItem(type = TYPE_NOTE, title = item.optString("name", "Note"), notes = item.optString("notes"))
                    else -> { skipped += "Record ${i + 1}: unsupported item type"; continue }
                }
                if (ready.isNotEmpty()) {
                    val fields = item.optJSONArray("fields")
                    val custom = fields?.let { a -> require(a.length() <= 100); (0 until a.length()).map { val f = a.getJSONObject(it); CustomField(label = f.optString("name"), value = f.optString("value"), isSecured = f.optInt("type") == 1) } } ?: emptyList()
                    // Only attach fields if this record was accepted.
                    if (skipped.lastOrNull()?.startsWith("Record ${i + 1}:") != true) ready[ready.lastIndex] = ready.last().copy(favorite = item.optBoolean("favorite"), customFields = custom)
                }
            }
        } else {
            val rows = CsvImporter.parse(source, false)
            val names = rows.firstOrNull()?.keys.orEmpty()
            format = when {
                names.any { it in setOf("account", "login name", "group", "web site") } -> "KeePass CSV"
                names.any { it.contains("login ") || it in setOf("otp auth", "otpauth", "website") } -> "1Password CSV"
                else -> "Password CSV"
            }
            rows.forEachIndexed { index, raw ->
                val r = raw.mapKeys { it.key.lowercase(Locale.ROOT).trim() }
                fun field(vararg keys: String) = keys.firstNotNullOfOrNull { r[it] } ?: ""
                login(index + 1, field("name", "title", "account"), field("url", "website", "web site", "login website"),
                    field("username", "login username", "login name", "user name"), field("password", "login password"),
                    field("note", "notes", "comments"), field("otp auth", "otpauth", "totp"))
            }
        }
        return ImportPreview(ready, skipped, format)
    }
}
