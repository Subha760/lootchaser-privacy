package app.kavorynx.vault

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

const val TYPE_PASSWORD = "Password"
const val TYPE_AUTHENTICATOR = "Authenticator"
const val TYPE_ADDRESS = "Address"
const val TYPE_TRAVEL = "Travel"
const val TYPE_NOTE = "Note"
const val TYPE_DOCUMENT = "Document"
const val TYPE_IDENTITY = "Identity"
const val TYPE_TICKET = "Ticket"
const val TYPE_MEMBERSHIP = "Membership"
const val TYPE_FINANCE = "Finance"
const val TYPE_HEALTH = "Health"
const val TYPE_VEHICLE = "Vehicle"


data class PasswordHistoryEntry(val password: String, val changedAt: Long)
data class CustomField(val id: String = UUID.randomUUID().toString(), val label: String = "", val value: String = "", val isSecured: Boolean = false)

/** Secrets (including metadata such as titles and URLs) live only inside the encrypted blob. */
data class VaultItem(
    val id: String = UUID.randomUUID().toString(),
    val type: String = TYPE_PASSWORD,
    val title: String = "",
    val site: String = "",
    val username: String = "",
    val secret: String = "",
    val notes: String = "",
    val fileName: String = "",
    val mime: String = "",
    val fileData: String = "",
    val created: Long = System.currentTimeMillis(),
    val category: String = "General",
    val favorite: Boolean = false,
    val expiryDate: String = "", // ISO 8601 yyyy-MM-dd, encrypted with the vault
    val fileRef: String = "",
    val totpSecret: String = "",
    val history: List<PasswordHistoryEntry> = emptyList(),
    val customFields: List<CustomField> = emptyList(),
    val isDeleted: Boolean = false,
    val deletedAt: Long = 0L,
    val linkedApps: List<String> = emptyList(),
    val appSignatures: Map<String, String> = emptyMap()
) {
    fun json(): JSONObject = JSONObject().put("id", id).put("type", type)
        .put("title", title).put("site", site).put("username", username)
        .put("secret", secret).put("notes", notes).put("fileName", fileName)
        .put("mime", mime).put("fileData", fileData).put("created", created).put("category", category)
        .put("favorite", favorite).put("expiryDate", expiryDate)
        .put("fileRef", fileRef).put("totpSecret", totpSecret)
        .put("history", JSONArray().apply { history.takeLast(5).forEach { put(JSONObject().put("password", it.password).put("changedAt", it.changedAt)) } })
        .put("customFields", JSONArray().apply { customFields.forEach { put(JSONObject().put("id", it.id).put("label", it.label).put("value", it.value).put("isSecured", it.isSecured)) } })
        .put("isDeleted", isDeleted).put("deletedAt", deletedAt)
        .put("linkedApps", JSONArray(linkedApps)).put("appSignatures", JSONObject(appSignatures))
    companion object {
        fun from(o: JSONObject): VaultItem = VaultItem(
            o.getString("id"), o.optString("type", TYPE_PASSWORD), o.optString("title"),
            o.optString("site"), o.optString("username"), o.optString("secret"),
            o.optString("notes"), o.optString("fileName"), o.optString("mime"),
            o.optString("fileData"), o.optLong("created", System.currentTimeMillis()),
            o.optString("category", "General"), o.optBoolean("favorite", false),
            o.optString("expiryDate", ""), o.optString("fileRef"), o.optString("totpSecret"),
            o.optJSONArray("history")?.let { a -> (0 until a.length()).map { val h = a.getJSONObject(it); PasswordHistoryEntry(h.getString("password"), h.optLong("changedAt")) }.takeLast(5) } ?: emptyList(),
            o.optJSONArray("customFields")?.let { a -> require(a.length() <= 100); (0 until a.length()).map { val c = a.getJSONObject(it); CustomField(c.optString("id", UUID.randomUUID().toString()), c.optString("label"), c.optString("value"), c.optBoolean("isSecured")) } } ?: emptyList(),
            o.optBoolean("isDeleted"), o.optLong("deletedAt"),
            o.optJSONArray("linkedApps")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList(),
            o.optJSONObject("appSignatures")?.let { a -> a.keys().asSequence().associateWith { a.getString(it) } } ?: emptyMap()
        )
    }
}

class VaultRepository(context: Context) {
    private val documentDir = File(context.filesDir, "encrypted_documents")
    private val prefs = context.getSharedPreferences("kavorynx_config", Context.MODE_PRIVATE)
    private val data = AtomicFile(File(context.filesDir, "secure_vault.dat"))
    fun exists(): Boolean = prefs.contains("master")
    fun hasDeviceUnlock(): Boolean = prefs.contains("device_wrap")
    fun readDeviceWrap(): String = prefs.getString("device_wrap", "") ?: ""
    fun saveDeviceWrap(value: String) { check(prefs.edit().putString("device_wrap", value).commit()) }
    fun removeDeviceWrap() { check(prefs.edit().remove("device_wrap").commit()) }

    @Synchronized fun create(password: CharArray): Pair<ByteArray, String> {
        check(!exists()) { "Vault already exists" }
        require(password.size >= 12) { "Use at least 12 characters" }
        val dek = Crypto.randomBytes(32)
        val recovery = Crypto.randomBytes(32)
        val wrapKey = Crypto.recoveryKey(recovery)
        try {
            val masterWrap = Crypto.wrapByPassword(password, dek)
            val recoverWrap = Crypto.b64(Crypto.seal(wrapKey, dek, "kavorynx:recovery-wrap:v1"))
            write(dek, emptyList())
            check(prefs.edit().putString("master", masterWrap).putString("recover", recoverWrap).commit())
            return dek to Crypto.printRecoveryToken(recovery)
        } catch (t: Throwable) { dek.fill(0); throw t }
        finally { recovery.fill(0); wrapKey.fill(0) }
    }
    fun unlock(password: CharArray): ByteArray {
        val dek = Crypto.unwrapByPassword(password, prefs.getString("master", null) ?: error("Not initialized"))
        try { require(dek.size == 32); read(dek); return dek }
        catch (t: Throwable) { dek.fill(0); throw t }
    }
    fun recoveryQuestion(): String? = prefs.getString("question_id", null)
        ?.takeIf { it in QuestionRecovery.questions && prefs.contains("question_wrap") }
    @Synchronized fun setupQuestionRecovery(dek: ByteArray, question: String, answer: CharArray): String {
        read(dek)
        val token = Crypto.randomBytes(32)
        try {
            val code = Crypto.printRecoveryToken(token)
            val envelope = QuestionRecovery.seal(question, answer, code, dek)
            check(prefs.edit().putString("question_id", question).putString("question_wrap", envelope).commit())
            return code
        } finally { token.fill(0) }
    }
    @Synchronized fun removeQuestionRecovery() {
        check(prefs.edit().remove("question_id").remove("question_wrap").commit())
    }
    @Synchronized fun resetWithQuestion(answer: CharArray, rescueCode: String, newPassword: CharArray): ByteArray {
        require(newPassword.size >= 12)
        val question = recoveryQuestion() ?: error("Question recovery is not enabled")
        val dek = QuestionRecovery.open(question, answer, rescueCode, prefs.getString("question_wrap", "")!!)
        try {
            read(dek)
            // Commit new password, consume rescue kit and revoke quick unlock together.
            check(prefs.edit().putString("master", Crypto.wrapByPassword(newPassword, dek))
                .remove("question_id").remove("question_wrap").remove("device_wrap").commit())
            return dek
        } catch (t: Throwable) { dek.fill(0); throw t }
    }
    @Synchronized fun resetPassword(token: String, newPassword: CharArray): ByteArray {
        require(newPassword.size >= 12)
        val recovery = Crypto.parseRecoveryToken(token)
        val key = Crypto.recoveryKey(recovery)
        recovery.fill(0)
        val dek = try { Crypto.open(key, Crypto.unb64(prefs.getString("recover", "")!!), "kavorynx:recovery-wrap:v1") }
            finally { key.fill(0) }
        try {
            read(dek) // Invalid/corrupt vault must not be silently overwritten.
            check(prefs.edit().putString("master", Crypto.wrapByPassword(newPassword, dek))
                .remove("device_wrap").remove("question_id").remove("question_wrap").commit())
            return dek
        } catch (t: Throwable) { dek.fill(0); throw t }
    }
    @Synchronized fun rotateRecovery(dek: ByteArray): String {
        read(dek)
        val token = Crypto.randomBytes(32)
        val wrapKey = Crypto.recoveryKey(token)
        try {
            val wrapped = Crypto.b64(Crypto.seal(wrapKey, dek, "kavorynx:recovery-wrap:v1"))
            check(prefs.edit().putString("recover", wrapped).commit())
            return Crypto.printRecoveryToken(token)
        } finally { token.fill(0); wrapKey.fill(0) }
    }
    @Synchronized fun changePassword(dek: ByteArray, newPassword: CharArray) {
        require(newPassword.size >= 12); read(dek)
        check(prefs.edit().putString("master", Crypto.wrapByPassword(newPassword, dek)).remove("device_wrap").commit())
    }
    @Synchronized fun read(dek: ByteArray): List<VaultItem> {
        val payload = data.openRead().use { it.readBytes() }
        val plaintext = Crypto.open(dek, payload, "kavorynx:vault:v1")
        val json = try { JSONObject(String(plaintext, Charsets.UTF_8)) }
            finally { plaintext.fill(0) }
        require(json.getInt("version") in 1..2)
        val items = json.getJSONArray("items")
        return (0 until items.length()).map { VaultItem.from(items.getJSONObject(it)) }
    }
    @Synchronized fun write(dek: ByteArray, entries: List<VaultItem>) {
        val persisted = entries.map { item ->
            if (item.fileData.isNotEmpty() && item.type == TYPE_DOCUMENT) {
                val bytes = Crypto.unb64(item.fileData)
                try { item.copy(fileData = "", fileRef = storeDocument(dek, bytes)) } finally { bytes.fill(0) }
            } else item
        }
        val arr = JSONArray(); persisted.forEach { arr.put(it.json()) }
        val plaintext = JSONObject().put("version", 2).put("items", arr).toString().toByteArray(Charsets.UTF_8)
        val encrypted = try { Crypto.seal(dek, plaintext, "kavorynx:vault:v1") }
            finally { plaintext.fill(0) }
        val stream = data.startWrite()
        try { stream.write(encrypted); data.finishWrite(stream) }
        catch (t: Throwable) { data.failWrite(stream); throw t }
    }

    private fun documentFile(ref: String): File {
        require(ref.matches(Regex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"))) { "Invalid document reference" }
        return File(documentDir, "$ref.enc")
    }
    private fun storeDocument(dek: ByteArray, bytes: ByteArray): String {
        require(bytes.size <= 8 * 1024 * 1024)
        check(documentDir.isDirectory || documentDir.mkdirs())
        val ref = UUID.randomUUID().toString()
        val encrypted = Crypto.seal(dek, bytes, "docryvia:document:v1:$ref")
        val file = AtomicFile(documentFile(ref)); val stream = file.startWrite()
        try { stream.write(encrypted); file.finishWrite(stream) }
        catch (t: Throwable) { file.failWrite(stream); throw t }
        return ref
    }
    fun documentBytes(dek: ByteArray, item: VaultItem): ByteArray {
        if (item.fileRef.isEmpty()) return Crypto.unb64(item.fileData).also { require(it.size <= 8 * 1024 * 1024) }
        val file = documentFile(item.fileRef)
        require(file.length() <= 8 * 1024 * 1024 + 28)
        return Crypto.open(dek, AtomicFile(file).openRead().use { it.readBytes() }, "docryvia:document:v1:${item.fileRef}")
    }
    @Synchronized fun cleanOrphanDocuments(entries: List<VaultItem>) {
        val referenced = entries.map { it.fileRef + ".enc" }.toSet()
        documentDir.listFiles()?.filter { it.name.endsWith(".enc") && it.name !in referenced }?.forEach { it.delete() }
    }

    /** Backup includes only encrypted data and a version label; user selects destination via Storage Access Framework. */
    fun makeEncryptedZip(dek: ByteArray, passphrase: CharArray): ByteArray {
        require(passphrase.size >= 12) { "Backup passphrase must have 12+ characters" }
        val items = read(dek)
        val estimated = items.sumOf { item ->
            item.json().toString().toByteArray(Charsets.UTF_8).size.toLong() +
                if (item.fileRef.isNotEmpty()) ((documentFile(item.fileRef).length() - 28).coerceAtLeast(0) + 2) / 3 * 4 else 0L
        }
        require(estimated <= 45L * 1024 * 1024) { "Backup exceeds the portable size limit" }
        val arr = JSONArray(); items.forEach { item ->
            if (item.fileRef.isNotEmpty()) {
                val bytes = documentBytes(dek, item)
                try { arr.put(item.copy(fileRef = "", fileData = Crypto.b64(bytes)).json()) } finally { bytes.fill(0) }
            } else arr.put(item.json())
        }
        val plaintext = JSONObject().put("version", 2).put("items", arr).toString().toByteArray()
        val cipherBytes = try { Crypto.exportPayload(passphrase, plaintext) }
            finally { plaintext.fill(0) }
        return ByteArrayOutputStream().also { out ->
            ZipOutputStream(out).use { zip ->
                zip.putNextEntry(ZipEntry("encrypted-vault.kvx"))
                zip.write(cipherBytes); zip.closeEntry()
                zip.putNextEntry(ZipEntry("README.txt"))
                zip.write("Docryvia encrypted backup v2 (self-contained documents). Never share your backup passphrase.".toByteArray())
                zip.closeEntry()
            }
        }.toByteArray()
    }
    fun readEncryptedZip(zipBytes: ByteArray, passphrase: CharArray): List<VaultItem> {
        require(zipBytes.size <= 100 * 1024 * 1024) { "Backup is too large" }
        var encrypted: ByteArray? = null
        val seen = mutableSetOf<String>()
        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zip ->
            var count = 0
            var entry = zip.nextEntry
            while (entry != null) {
                count++
                require(count <= 2 && entry.name in setOf("encrypted-vault.kvx", "README.txt") && seen.add(entry.name)) {
                    "Unexpected or duplicate backup entry"
                }
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                val limit = if (entry.name == "encrypted-vault.kvx") 80 * 1024 * 1024 else 2048
                while (true) {
                    val n = zip.read(buffer)
                    if (n < 0) break
                    require(out.size() + n <= limit) { "Backup entry too large" }
                    out.write(buffer, 0, n)
                }
                if (entry.name == "encrypted-vault.kvx") {
                    require(encrypted == null) { "Duplicate backup payload" }
                    encrypted = out.toByteArray()
                }
                zip.closeEntry(); entry = zip.nextEntry
            }
        }
        val plaintext = Crypto.importPayload(passphrase, encrypted ?: error("Not a Docryvia-compatible backup"))
        val root = try { JSONObject(String(plaintext, Charsets.UTF_8)) }
            finally { plaintext.fill(0) }
        require(root.getInt("version") in 1..2)
        val arr = root.getJSONArray("items")
        require(arr.length() <= 20_000)
        return (0 until arr.length()).map { VaultItem.from(arr.getJSONObject(it)).also { item ->
            require(item.fileRef.isEmpty()) { "Backup contains unresolved document reference" }
        } }
    }
}
