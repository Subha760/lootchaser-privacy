package app.kavorynx.vault

import android.content.res.Resources

/** Application resources only; never retains an Activity or any vault content. */
object UiText {
    lateinit var resources: Resources
    fun question(id: String): String = get(when (id) {
        "food" -> R.string.question_food
        "school" -> R.string.question_school
        else -> R.string.question_nickname
    })
    fun get(id: Int, vararg args: Any): String = if (args.isEmpty()) resources.getString(id) else resources.getString(id, *args)
}
