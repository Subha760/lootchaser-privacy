package app.kavorynx.vault

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class VaultTileService : TileService() {
    override fun onStartListening() { super.onStartListening(); update() }
    override fun onClick() { super.onClick(); VaultSession.lock(); update() }
    private fun update() { qsTile?.apply {
        label = getString(R.string.lock_vault)
        state = if (VaultSession.unlocked) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        updateTile()
    } }
}
