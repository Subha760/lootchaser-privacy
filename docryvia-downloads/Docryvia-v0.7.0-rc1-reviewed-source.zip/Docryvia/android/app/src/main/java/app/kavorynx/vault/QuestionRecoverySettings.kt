package app.kavorynx.vault

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun QuestionRecoverySettings(enabled: Boolean, busy: Boolean,
    onSetup: (String, String) -> Unit, onDisable: () -> Unit) {
    var question by remember { mutableStateOf("food") }
    var answer by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var warningAccepted by remember { mutableStateOf(false) }
    var confirmDisable by remember { mutableStateOf(false) }
    Text(androidx.compose.ui.res.stringResource(R.string.ui_145), style = MaterialTheme.typography.titleMedium)
    Text(if (enabled) UiText.get(R.string.ui_310)
        else UiText.get(R.string.ui_311))
    Text(androidx.compose.ui.res.stringResource(R.string.ui_146),
        style = MaterialTheme.typography.bodySmall)
    QuestionRecovery.questions.forEach { (id, label) ->
        FilterChip(selected = question == id, enabled = !busy, onClick = { question = id }, label = { Text(UiText.question(id)) })
    }
    OutlinedTextField(answer, { answer = it.take(200) }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_147)) },
        singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
    OutlinedTextField(confirm, { confirm = it.take(200) }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_148)) },
        singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
    Row {
        Checkbox(warningAccepted, { warningAccepted = it })
        Text(androidx.compose.ui.res.stringResource(R.string.ui_149), modifier = Modifier.padding(top = 12.dp))
    }
    OutlinedButton(enabled = !busy && warningAccepted && answer.trim().length >= 2 && answer == confirm,
        onClick = { onSetup(question, answer); answer = ""; confirm = ""; warningAccepted = false }) {
        Text(if (enabled) UiText.get(R.string.ui_312) else UiText.get(R.string.ui_313))
    }
    if (enabled) TextButton(enabled = !busy, onClick = { confirmDisable = true }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_150)) }
    if (confirmDisable) AlertDialog(onDismissRequest = { confirmDisable = false },
        title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_151)) },
        text = { Text(androidx.compose.ui.res.stringResource(R.string.ui_152)) },
        confirmButton = { TextButton(onClick = { confirmDisable = false; onDisable() }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_153)) } },
        dismissButton = { TextButton(onClick = { confirmDisable = false }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_2)) } })
}
