package app.kavorynx.vault

import android.content.Context
import android.os.SystemClock

object LockPreferences {
    @Volatile private var lastInteraction = SystemClock.elapsedRealtime()
    private fun prefs(context: Context) = context.getSharedPreferences("docryvia_lock", Context.MODE_PRIVATE)
    fun timeout(context: Context): Long = prefs(context).getLong("foreground_ms", 120_000L)
    fun setTimeout(context: Context, millis: Long) {
        require(millis in listOf(0L, 60_000L, 120_000L, 300_000L))
        check(prefs(context).edit().putLong("foreground_ms", millis).commit()); interaction()
    }
    fun interaction() { lastInteraction = SystemClock.elapsedRealtime() }
    fun shouldLock(context: Context, now: Long = SystemClock.elapsedRealtime()): Boolean {
        val duration = timeout(context)
        return duration > 0 && now - lastInteraction >= duration
    }
}
