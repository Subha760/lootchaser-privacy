package app.kavorynx.vault

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun TotpCard(seed: String, context: Context) {
    val config = remember(seed) { runCatching { TotpGenerator.parse(seed) }.getOrNull() }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(seed) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    if (config != null) {
        val code = remember(seed, now / (config.period * 1000)) { runCatching { TotpGenerator.code(config, now) }.getOrDefault("Unavailable") }
        val remaining = config.period - (now / 1000 % config.period).toInt()
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(progress = { remaining.toFloat() / config.period }, modifier = Modifier.size(32.dp))
            Column(Modifier.weight(1f)) { Text(code, style = MaterialTheme.typography.headlineSmall); Text(androidx.compose.ui.res.stringResource(R.string.ui_206, (remaining)), style = MaterialTheme.typography.labelSmall) }
            TextButton(onClick = { SensitiveClipboard.copy(context, code) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_128)) }
        }
    }
}

@Composable
fun AdvancedPasswordStudio(context: Context) {
    var upper by remember { mutableStateOf(true) }; var lower by remember { mutableStateOf(true) }
    var numbers by remember { mutableStateOf(true) }; var symbols by remember { mutableStateOf(true) }
    var ambiguous by remember { mutableStateOf(true) }; var phrase by remember { mutableStateOf(false) }
    var length by remember { mutableFloatStateOf(24f) }; var count by remember { mutableFloatStateOf(6f) }
    var result by remember { mutableStateOf(PasswordStudio.password(PasswordOptions())) }
    var error by remember { mutableStateOf("") }
    val words = remember { context.assets.open("eff_wordlist.txt").bufferedReader().use { it.readLines() } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(androidx.compose.ui.res.stringResource(R.string.ui_129), style = MaterialTheme.typography.headlineSmall)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(phrase, { phrase = it }); Text(androidx.compose.ui.res.stringResource(R.string.ui_130)) }
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) { Text(result, Modifier.fillMaxWidth().padding(16.dp), style = MaterialTheme.typography.titleMedium) }
        if (phrase) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_207, (count.toInt()), ((count.toInt() * 12.925).toInt())))
            Slider(count, { count = it }, valueRange = 4f..10f, steps = 5)
            Text(androidx.compose.ui.res.stringResource(R.string.ui_131))
        } else {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_208, (length.toInt()))); Slider(length, { length = it }, valueRange = 8f..64f, steps = 55)
            listOf(Triple(UiText.get(R.string.ui_322), upper, { v: Boolean -> upper = v }), Triple(UiText.get(R.string.ui_323), lower, { v: Boolean -> lower = v }),
                Triple(UiText.get(R.string.ui_324), numbers, { v: Boolean -> numbers = v }), Triple(UiText.get(R.string.ui_325), symbols, { v: Boolean -> symbols = v }),
                Triple(UiText.get(R.string.ui_326), ambiguous, { v: Boolean -> ambiguous = v })).forEach { (label, checked, change) ->
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked, change); Text(label) }
            }
        }
        Button(onClick = { try {
            result = if (phrase) PasswordStudio.passphrase(words, count.toInt()) else PasswordStudio.password(PasswordOptions(length.toInt(), upper, lower, numbers, symbols, ambiguous)); error = ""
        } catch (_: Exception) { error = UiText.get(R.string.ui_210) } }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_132)) }
        TextButton(onClick = { SensitiveClipboard.copy(context, result) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_133)) }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        Text(androidx.compose.ui.res.stringResource(R.string.ui_134))
    }
}

@Composable
fun UpgradeSettings(context: Context, repo: VaultRepository, onNotice: (String) -> Unit) {
    var timeout by remember { mutableLongStateOf(LockPreferences.timeout(context)) }
    var showTrash by remember { mutableStateOf(false) }; var purgeId by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Text(androidx.compose.ui.res.stringResource(R.string.ui_135), style = MaterialTheme.typography.titleMedium)
    listOf(60_000L to UiText.get(R.string.ui_327), 120_000L to UiText.get(R.string.ui_328), 300_000L to UiText.get(R.string.ui_329), 0L to UiText.get(R.string.ui_330)).forEach { (value, label) ->
        Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(timeout == value, { timeout = value; LockPreferences.setTimeout(context, value) }); Text(label) }
    }
    Text(androidx.compose.ui.res.stringResource(R.string.ui_136), style = MaterialTheme.typography.bodySmall)
    OutlinedButton(onClick = { showTrash = true }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_209, (VaultSession.items.count { it.isDeleted }))) }
    if (showTrash) AlertDialog(onDismissRequest = { if (!working) showTrash = false }, title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_137)) },
        text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
            val trash = VaultSession.items.filter { it.isDeleted }
            if (trash.isEmpty()) Text(androidx.compose.ui.res.stringResource(R.string.ui_138))
            trash.forEach { item ->
                Text(item.title, style = MaterialTheme.typography.titleMedium)
                Row {
                    TextButton(enabled = !working, onClick = { working = true; scope.launch {
                        try { withContext(Dispatchers.IO) { VaultSession.restore(item.id, repo) }; onNotice(UiText.get(R.string.ui_211)) }
                        catch (_: Exception) { onNotice(UiText.get(R.string.ui_212)) } finally { working = false }
                    } }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_18)) }
                    TextButton(enabled = !working, onClick = { purgeId = item.id }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_139)) }
                }
            }
            Text(androidx.compose.ui.res.stringResource(R.string.ui_140))
        } }, confirmButton = { TextButton(enabled = !working, onClick = { showTrash = false }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_59)) } })
    if (purgeId != null) AlertDialog(onDismissRequest = { purgeId = null }, title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_141)) },
        text = { Text(androidx.compose.ui.res.stringResource(R.string.ui_142)) },
        confirmButton = { TextButton(enabled = !working, onClick = { val id = purgeId!!; working = true; scope.launch {
            try { withContext(Dispatchers.IO) { VaultSession.purge(id, repo) }; onNotice(UiText.get(R.string.ui_213)) }
            catch (_: Exception) { onNotice(UiText.get(R.string.ui_188)) } finally { purgeId = null; working = false }
        } }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_139)) } }, dismissButton = { TextButton(onClick = { purgeId = null }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_2)) } })
}

@Composable
fun AuthenticatorPage(context: Context, onAdd: () -> Unit, onEdit: (VaultItem) -> Unit) {
    val entries = VaultSession.activeItems.filter { it.totpSecret.isNotBlank() }.sortedBy { it.title.lowercase() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(androidx.compose.ui.res.stringResource(R.string.authenticator), style = MaterialTheme.typography.headlineSmall)
        Button(onClick = onAdd) { Text(androidx.compose.ui.res.stringResource(R.string.add_authenticator)) }
        if (entries.isEmpty()) Text(androidx.compose.ui.res.stringResource(R.string.authenticator_empty))
        entries.forEach { item ->
            Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(item.title, style = MaterialTheme.typography.titleMedium)
                    TotpCard(item.totpSecret, context)
                    TextButton(onClick = { onEdit(item) }) { Text(androidx.compose.ui.res.stringResource(R.string.edit_account)) }
                }
            }
        }
    }
}
