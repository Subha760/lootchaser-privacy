package app.kavorynx.vault

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle

/** Explicit-copy only. Android 10+ disallows reading the clipboard in background. */
internal object SensitiveClipboard {
    private val handler = Handler(Looper.getMainLooper())
    private var pendingClear: Runnable? = null

    fun copy(context: Context, text: String) {
        val manager = context.getSystemService(ClipboardManager::class.java)
        val label = "Sensitive vault value:${java.util.UUID.randomUUID()}"
        val clip = ClipData.newPlainText(label, text)
        if (Build.VERSION.SDK_INT >= 33) {
            clip.description.extras = PersistableBundle().apply {
                putBoolean("android.content.extra.IS_SENSITIVE", true)
            }
        }
        manager.setPrimaryClip(clip)
        pendingClear?.let(handler::removeCallbacks)
        val clear = Runnable {
            try { if (manager.primaryClipDescription?.label?.toString() == label) manager.clearPrimaryClip() } catch (_: RuntimeException) { /* OS may deny access */ }
            pendingClear = null
        }
        pendingClear = clear
        handler.postDelayed(clear, 30_000L)
    }
}
