package app.kavorynx.vault

import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.json.JSONObject
import java.io.File
import java.util.Locale

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = DocryviaApp::class)
class UpgradeUnitTest {
    private fun fresh(): VaultRepository {
        VaultSession.lock()
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit()
        app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        return VaultRepository(app)
    }
    private fun fails(block: () -> Unit) { try { block(); fail("Expected failure") } catch (_: IllegalArgumentException) {} catch (_: javax.crypto.AEADBadTagException) {} }
    @Test fun legacyItemDefaultsAndCompleteNewFieldsRoundTrip() {
        val old = VaultItem.from(JSONObject("{\"id\":\"legacy\",\"secret\":\"old password\"}"))
        assertTrue(old.history.isEmpty()); assertFalse(old.isDeleted); assertEquals("", old.totpSecret)
        val enhanced = old.copy(totpSecret = "JBSWY3DPEHPK3PXP", history = listOf(PasswordHistoryEntry("previous", 3)),
            customFields = listOf(CustomField("id", "PIN", "1234", true)), isDeleted = true, deletedAt = 4,
            linkedApps = listOf("com.example"), appSignatures = mapOf("com.example" to "cert"))
        assertEquals(enhanced, VaultItem.from(enhanced.json()))
    }
    @Test fun migrationKeepsOriginalCipherDomainAndReadsSchemaOne() {
        val repo = fresh(); val (key, _) = repo.create("migration password".toCharArray())
        val bytes = "{\"version\":1,\"items\":[{\"id\":\"old\",\"secret\":\"unchanged\"}]}".toByteArray()
        File(RuntimeEnvironment.getApplication().filesDir, "secure_vault.dat").writeBytes(Crypto.seal(key, bytes, "kavorynx:vault:v1"))
        val loaded = repo.read(key); assertEquals("unchanged", loaded.single().secret)
        repo.write(key, loaded); assertEquals(loaded, repo.read(key)); key.fill(0)
    }
    @Test fun encryptedDocumentsAreSeparateAuthenticatedAndBackupIsPortable() {
        val repo = fresh(); val (key, _) = repo.create("document password".toCharArray())
        val content = "private document content".toByteArray()
        repo.write(key, listOf(VaultItem(id = "doc", type = TYPE_DOCUMENT, fileData = Crypto.b64(content))))
        val item = repo.read(key).single(); assertEquals("", item.fileData); assertTrue(item.fileRef.isNotEmpty())
        assertArrayEquals(content, repo.documentBytes(key, item))
        val file = File(RuntimeEnvironment.getApplication().filesDir, "encrypted_documents/${item.fileRef}.enc")
        assertFalse(file.readBytes().toString(Charsets.UTF_8).contains("private document content"))
        val backup = repo.makeEncryptedZip(key, "backup password".toCharArray())
        val restored = repo.readEncryptedZip(backup, "backup password".toCharArray()).single()
        assertEquals("", restored.fileRef); assertArrayEquals(content, Crypto.unb64(restored.fileData))
        repo.write(key, listOf(restored)); assertArrayEquals(content, repo.documentBytes(key, repo.read(key).single()))
        fails { repo.documentBytes(key, item.copy(fileRef = "../../outside")) }
        val sealed = file.readBytes(); sealed[sealed.lastIndex] = (sealed.last().toInt() xor 1).toByte(); file.writeBytes(sealed)
        fails { repo.documentBytes(key, item) }; key.fill(0)
    }
    @Test fun historyTrashAndRestoreCoverEditorAndAutofillChanges() {
        val repo = fresh(); val (key, _) = repo.create("session password".toCharArray()); VaultSession.start(key, repo)
        val item = VaultItem(title = "Login", site = "https://example.com", username = "User", secret = "one")
        VaultSession.save(item, repo)
        VaultSession.save(item.copy(secret = "two"), repo)
        assertEquals("one", VaultSession.items.single().history.single().password)
        VaultSession.confirmAndSaveLogin(repo, charArrayOf(), "example.com", "User", "three")
        assertEquals(listOf("one", "two"), VaultSession.items.single().history.map { it.password })
        VaultSession.remove(item.id, repo); assertTrue(VaultSession.activeItems.isEmpty()); assertTrue(VaultSession.accountsForHost("example.com").isEmpty())
        VaultSession.restore(item.id, repo); assertEquals("three", VaultSession.activeItems.single().secret)
        VaultSession.remove(item.id, repo); VaultSession.purge(item.id, repo); assertTrue(VaultSession.items.isEmpty()); VaultSession.lock()
    }
    @Test fun unlockPurgesExpiredTrashButRetainsFreshTrash() {
        val repo = fresh(); val (key, _) = repo.create("trash password".toCharArray())
        val now = System.currentTimeMillis()
        repo.write(key, listOf(VaultItem(id = "old", isDeleted = true, deletedAt = now - 31L * 86400000), VaultItem(id = "new", isDeleted = true, deletedAt = now)))
        VaultSession.start(key, repo); assertEquals("new", VaultSession.items.single().id); VaultSession.lock()
    }
    @Test fun historyIsBoundedAndUnchangedSaveDoesNotAddEntry() {
        val original = VaultItem(secret = "old", history = (1..5).map { PasswordHistoryEntry("h$it", it.toLong()) })
        val changed = VaultSession.preserveHistory(original, original.copy(secret = "new"))
        assertEquals(5, changed.history.size); assertEquals("old", changed.history.last().password)
        assertEquals(original.history, VaultSession.preserveHistory(original, original.copy(notes = "edit")).history)
    }
    @Test fun legacyQuestionKitsKeepPunctuationAndNewKitsNormalizeIt() {
        val key = Crypto.randomBytes(32); val token = Crypto.randomBytes(32); val code = Crypto.printRecoveryToken(token)
        val salt = Crypto.randomBytes(16); val answer = "st. mary's".toCharArray()
        val derived = Crypto.pbkdf2(answer, salt + token)
        val legacy = Crypto.b64(salt + Crypto.seal(derived, key, "docryvia:question-recovery:v1:school"))
        assertArrayEquals(key, QuestionRecovery.open("school", "St. Mary's".toCharArray(), code, legacy))
        fails { QuestionRecovery.open("school", "St Marys".toCharArray(), code, legacy) }
        val modern = QuestionRecovery.seal("school", "St. Mary's".toCharArray(), code, key)
        assertArrayEquals(key, QuestionRecovery.open("school", "St Marys".toCharArray(), code, modern))
        key.fill(0); token.fill(0); derived.fill(0)
    }
    @Test fun importsSupportThreeManagersAndReportSkippedRows() {
        val one = ManagerImporter.parse("Title,Website,Username,Password,Notes\nTest,https://example.com,User,password,note\nBad,http://example.com,u,p,n")
        assertEquals(1, one.items.size); assertEquals(1, one.skipped.size)
        val keepass = ManagerImporter.parse("Account,Login Name,Password,Web Site,Comments\nTest,user,pass,https://example.com,hello")
        assertEquals("KeePass CSV", keepass.format); assertEquals("user", keepass.items.single().username)
        val bw = ManagerImporter.parse("""{"items":[{"type":1,"name":"Test","login":{"username":"User","password":"secret","uris":[{"uri":"https://example.com"}]},"fields":[{"name":"PIN","value":"1234","type":1}]},{"type":2,"name":"Note","notes":"private"},{"type":3,"name":"Unsupported"}]}""")
        assertEquals(2, bw.items.size); assertEquals(1, bw.skipped.size); assertTrue(bw.items.first().customFields.single().isSecured)
    }
    @Test fun parserRejectsUnclosedCsvAndExcessiveSeeds() {
        fails { ManagerImporter.parse("url,username,password\n\"broken") }
        fails { TotpGenerator.parse("otpauth://hotp/x?secret=JBSWY3DPEHPK3PXP") }
        fails { TotpGenerator.parse("otpauth://totp/x?secret=JBSWY3DPEHPK3PXP&digits=9") }
    }
    @Test fun totpParsesAlgorithmPeriodAndRfc6238Vectors() {
        val secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
        val vectors = listOf(59L to "94287082", 1111111109L to "07081804", 1111111111L to "14050471", 1234567890L to "89005924", 2000000000L to "69279037", 20000000000L to "65353130")
        vectors.forEach { (time, code) -> assertEquals(code, TotpGenerator.code(TotpConfig(secret, digits = 8), time * 1000)) }
        val config = TotpGenerator.parse("otpauth://totp/Account?secret=$secret&algorithm=SHA256&digits=8&period=60")
        assertEquals("SHA256", config.algorithm); assertEquals(60, config.period)
    }
    @Test fun passwordOptionsGuaranteeGroupsAndRejectEmptySelection() {
        repeat(100) {
            val p = PasswordStudio.password(PasswordOptions(length = 12))
            assertEquals(12, p.length); assertTrue(p.any { it.isUpperCase() }); assertTrue(p.any { it.isLowerCase() }); assertTrue(p.any { it.isDigit() }); assertTrue(p.any { !it.isLetterOrDigit() }); assertFalse(p.any { it in "0O1lI" })
        }
        fails { PasswordStudio.password(PasswordOptions(upper = false, lower = false, numbers = false, symbols = false)) }
        val p = PasswordStudio.password(PasswordOptions(upper = false, lower = true, numbers = false, symbols = false))
        assertTrue(p.all { it.isLowerCase() })
    }
    @Test fun passphrasesUseBundledUniqueWordlist() {
        val words = RuntimeEnvironment.getApplication().assets.open("eff_wordlist.txt").bufferedReader().use { it.readLines() }
        assertEquals(7776, words.size); assertEquals(7776, words.distinct().size)
        assertTrue(words.any { '-' in it })
        fails { PasswordStudio.passphrase(words, separator = "-") }
        repeat(100) { val p = PasswordStudio.passphrase(words); assertEquals(6, p.split(' ').size); assertTrue(p.split(' ').all { it in words }) }
    }
    @Test fun inactivityPreferencesValidateAndNeverOptionBypassesTimeout() {
        val context = RuntimeEnvironment.getApplication()
        LockPreferences.setTimeout(context, 60_000); assertTrue(LockPreferences.shouldLock(context, Long.MAX_VALUE))
        LockPreferences.setTimeout(context, 0); assertFalse(LockPreferences.shouldLock(context, Long.MAX_VALUE))
        fails { LockPreferences.setTimeout(context, 1) }; LockPreferences.setTimeout(context, 120_000)
    }
    @Test fun rfc6238Sha256AndSha512Vectors() {
        val times = listOf(59L, 1111111109L, 1111111111L, 1234567890L, 2000000000L, 20000000000L)
        val sha256 = listOf("46119246", "68084774", "67062674", "91819424", "90698825", "77737706")
        val sha512 = listOf("90693936", "25091201", "99943326", "93441116", "38618901", "47863826")
        times.forEachIndexed { index, time ->
            assertEquals(sha256[index], TotpGenerator.code(TotpConfig("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZA", "SHA256", 8), time * 1000))
            assertEquals(sha512[index], TotpGenerator.code(TotpConfig("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNA", "SHA512", 8), time * 1000))
        }
    }
    @Test fun missingNativeAppAndUnlinkedAppsCannotReceiveCredentials() {
        val repo = fresh(); val (key, _) = repo.create("native password".toCharArray()); VaultSession.start(key, repo)
        VaultSession.save(VaultItem(site = "https://example.com", secret = "secret", linkedApps = listOf("missing.app"), appSignatures = mapOf("missing.app" to "fake")), repo)
        assertTrue(VaultSession.accountsForApp(RuntimeEnvironment.getApplication(), "missing.app").isEmpty()); VaultSession.lock()
    }
    @Test fun tamperedRecoveryVersionCannotSwitchDerivationRules() {
        val key = Crypto.randomBytes(32); val code = Crypto.printRecoveryToken(Crypto.randomBytes(32))
        val modern = QuestionRecovery.seal("food", "rice".toCharArray(), code, key)
        fails { QuestionRecovery.open("food", "rice".toCharArray(), code, modern.removePrefix("v2:")) }; key.fill(0)
    }
}
