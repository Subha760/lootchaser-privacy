package app.kavorynx.vault

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Looper
import java.time.Duration
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28])
@LooperMode(LooperMode.Mode.PAUSED)
class SensitiveClipboardUnitTest {
    @Test fun cleanupPreservesLaterUnrelatedCopy() {
        val context = RuntimeEnvironment.getApplication()
        val clipboard = context.getSystemService(ClipboardManager::class.java)
        SensitiveClipboard.copy(context, "secret")
        clipboard.setPrimaryClip(ClipData.newPlainText("other", "keep me"))
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(31))
        assertEquals("keep me", clipboard.primaryClip!!.getItemAt(0).text.toString())
    }
    @Test fun secondVaultCopyReceivesItsOwnFullLifetime() {
        val context = RuntimeEnvironment.getApplication()
        val clipboard = context.getSystemService(ClipboardManager::class.java)
        SensitiveClipboard.copy(context, "first")
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(20))
        SensitiveClipboard.copy(context, "second")
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(11))
        assertEquals("second", clipboard.primaryClip!!.getItemAt(0).text.toString())
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(20))
        assertFalse(clipboard.hasPrimaryClip())
    }
}
