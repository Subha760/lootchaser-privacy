package app.kavorynx.vault

import org.junit.Assert.*
import org.junit.Test

class RecoveryCryptoUnitTest {
    private fun rejected(block: () -> Unit) {
        try { block(); fail("Expected rejection") } catch (_: IllegalArgumentException) {}
        catch (_: javax.crypto.AEADBadTagException) {}
    }
    @Test fun questionRoundTripNormalizesAnswerAndRequiresBothFactors() {
        val key = Crypto.randomBytes(32)
        val code = Crypto.printRecoveryToken(Crypto.randomBytes(32))
        val envelope = QuestionRecovery.seal("food", "  Rice   Curry  ".toCharArray(), code, key)
        assertArrayEquals(key, QuestionRecovery.open("food", "rice curry".toCharArray(), code, envelope))
        rejected { QuestionRecovery.open("food", "wrong".toCharArray(), code, envelope) }
        rejected { QuestionRecovery.open("food", "rice curry".toCharArray(),
            Crypto.printRecoveryToken(Crypto.randomBytes(32)), envelope) }
        rejected { QuestionRecovery.open("school", "rice curry".toCharArray(), code, envelope) }
    }
    @Test fun rejectMalformedAndTamperedRecoveryEnvelope() {
        val code = Crypto.printRecoveryToken(Crypto.randomBytes(32))
        val envelope = QuestionRecovery.seal("nickname", "sunshine".toCharArray(), code, Crypto.randomBytes(32))
        val packed = Crypto.unb64(envelope.removePrefix("v2:")); packed[packed.lastIndex] = (packed.last().toInt() xor 1).toByte()
        rejected { QuestionRecovery.open("nickname", "sunshine".toCharArray(), code, "v2:" + Crypto.b64(packed)) }
        rejected { QuestionRecovery.open("nickname", "sunshine".toCharArray(), "invalid", envelope) }
        rejected { QuestionRecovery.seal("unknown", "sunshine".toCharArray(), code, Crypto.randomBytes(32)) }
        rejected { QuestionRecovery.seal("food", " ".toCharArray(), code, Crypto.randomBytes(32)) }
    }
    @Test fun legacyMasterAndBackupRoundTripsRemainCompatible() {
        val key = Crypto.randomBytes(32)
        val pw = "long master password".toCharArray()
        assertArrayEquals(key, Crypto.unwrapByPassword(pw, Crypto.wrapByPassword(pw, key)))
        val payload = "test vault payload".toByteArray()
        val exported = Crypto.exportPayload(pw, payload)
        assertArrayEquals(payload, Crypto.importPayload(pw, exported))
        rejected { Crypto.importPayload("incorrect password".toCharArray(), exported) }
    }
}
