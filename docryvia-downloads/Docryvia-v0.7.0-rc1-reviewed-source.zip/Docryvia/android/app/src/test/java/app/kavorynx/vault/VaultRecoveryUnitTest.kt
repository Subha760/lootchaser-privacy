package app.kavorynx.vault

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = android.app.Application::class)
class VaultRecoveryUnitTest {
    private lateinit var repo: VaultRepository
    private val oldPassword = "original long password".toCharArray()
    private val newPassword = "replacement long password".toCharArray()
    @Before fun clean() {
        VaultSession.lock()
        val context = RuntimeEnvironment.getApplication()
        context.getSharedPreferences("kavorynx_config", 0).edit().clear().commit()
        context.filesDir.listFiles()?.forEach { it.delete() }
        repo = VaultRepository(context)
    }
    private fun rejects(block: () -> Unit) {
        val error = runCatching(block).exceptionOrNull()
        assertNotNull("Expected rejection", error)
    }
    @Test fun questionResetPreservesDataConsumesKitAndRevokesDeviceUnlock() {
        val (key, mainCode) = repo.create(oldPassword)
        val item = VaultItem(title = "Preserved", secret = "private data")
        repo.write(key, listOf(item)); repo.saveDeviceWrap("test-wrap")
        val code = repo.setupQuestionRecovery(key, "school", "First school".toCharArray())
        val recovered = repo.resetWithQuestion("first school".toCharArray(), code, newPassword)
        assertEquals(listOf(item), repo.read(recovered))
        assertFalse(repo.hasDeviceUnlock()); assertNull(repo.recoveryQuestion())
        rejects { repo.unlock(oldPassword) }
        repo.unlock(newPassword).fill(0)
        rejects { repo.resetWithQuestion("first school".toCharArray(), code, oldPassword) }
        repo.resetPassword(mainCode, oldPassword).fill(0)
        key.fill(0); recovered.fill(0)
    }
    @Test fun failedRecoveryLeavesPasswordAndKitUnchanged() {
        val (key, _) = repo.create(oldPassword)
        val code = repo.setupQuestionRecovery(key, "food", "Noodles".toCharArray())
        rejects { repo.resetWithQuestion("incorrect".toCharArray(), code, newPassword) }
        rejects { repo.resetWithQuestion("Noodles".toCharArray(), code, "short".toCharArray()) }
        assertEquals("food", repo.recoveryQuestion()); repo.unlock(oldPassword).fill(0)
        key.fill(0)
    }
    @Test fun replacingAndDisablingKitInvalidatesOldCode() {
        val (key, _) = repo.create(oldPassword)
        val old = repo.setupQuestionRecovery(key, "nickname", "Star".toCharArray())
        val code = repo.setupQuestionRecovery(key, "nickname", "Star".toCharArray())
        rejects { repo.resetWithQuestion("Star".toCharArray(), old, newPassword) }
        repo.removeQuestionRecovery()
        rejects { repo.resetWithQuestion("Star".toCharArray(), code, newPassword) }
        repo.unlock(oldPassword).fill(0); key.fill(0)
    }
    @Test fun masterResetInvalidatesQuestionKitAndQuickUnlock() {
        val (key, code) = repo.create(oldPassword)
        repo.setupQuestionRecovery(key, "food", "Rice".toCharArray()); repo.saveDeviceWrap("wrap")
        repo.resetPassword(code, newPassword).fill(0)
        assertNull(repo.recoveryQuestion()); assertFalse(repo.hasDeviceUnlock()); key.fill(0)
    }
    @Test fun autofillReplacementKeepsMetadataAndUpdatesActiveSession() {
        val (key, _) = repo.create(oldPassword)
        val item = VaultItem(title = "Account", site = "https://example.com", username = "U",
            secret = "old", notes = "keep", favorite = true, expiryDate = "2030-01-01", category = "Work")
        repo.write(key, listOf(item)); VaultSession.start(key, repo)
        VaultSession.confirmAndSaveLogin(repo, charArrayOf(), "example.com", "U", "new")
        assertEquals(listOf(item.copy(secret = "new")), VaultSession.items.map { it.copy(history = emptyList()) })
        assertEquals(listOf("old"), VaultSession.items.single().history.map { it.password })
        VaultSession.lock()
        val unlocked = repo.unlock(oldPassword)
        assertEquals(listOf(item.copy(secret = "new")), repo.read(unlocked).map { it.copy(history = emptyList()) }); assertEquals("old", repo.read(unlocked).single().history.single().password); unlocked.fill(0)
    }
    @Test fun changingPasswordRevokesQuickUnlock() {
        val (key, _) = repo.create(oldPassword); repo.saveDeviceWrap("wrap")
        repo.changePassword(key, newPassword)
        assertFalse(repo.hasDeviceUnlock()); repo.unlock(newPassword).fill(0); key.fill(0)
    }
    @Test fun importKeepsCaseSensitiveUsernamesAndAvoidsDelimiterCollisions() {
        val (key, _) = repo.create(oldPassword); VaultSession.start(key, repo)
        val first = VaultItem(site = "https://example.com", username = "User", secret = "same")
        val second = VaultItem(site = "https://example.com", username = "user", secret = "same")
        val third = VaultItem(site = "https://example.com", username = "a|b", secret = "c")
        val fourth = VaultItem(site = "https://example.com", username = "a", secret = "b|c")
        VaultSession.import(repo, listOf(first, second, third, fourth))
        assertEquals(4, VaultSession.items.size)
        VaultSession.import(repo, listOf(first.copy(id = "duplicate")))
        assertEquals(4, VaultSession.items.size); VaultSession.lock()
    }

}
