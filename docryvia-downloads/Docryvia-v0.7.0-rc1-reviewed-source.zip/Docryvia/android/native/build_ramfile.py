"""Rebuild bundled RAM-file bridges using LLVM/Android NDK Clang and LLD.
Set CLANG to the compiler path. These small bridges need no NDK headers or libc.
"""
from pathlib import Path
import os, subprocess
root = Path(__file__).resolve().parents[1]
compiler = os.environ.get('CLANG', 'clang')
linker = os.environ.get('DOC_LD_LLD', 'lld')
for abi, target in [('arm64-v8a','aarch64-linux-android28'), ('armeabi-v7a','armv7a-linux-androideabi28'), ('x86','i686-linux-android28'), ('x86_64','x86_64-linux-android28')]:
    out = root/'app/src/main/jniLibs'/abi/'libdocryvia_ramfile.so'
    out.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([compiler, '--target='+target, '-O2', '-fPIC', '-fomit-frame-pointer', '-fno-stack-protector',
        '-shared', '-nostdlib', '-fuse-ld='+linker, '-Wl,-soname,libdocryvia_ramfile.so',
        '-Wl,-z,relro,-z,now,-z,noexecstack,-z,max-page-size=16384',
        str(root/'native/ramfile.c'), '-o', str(out)], check=True)
    print(abi, out.stat().st_size)
