/* Docryvia's seekable RAM-file bridge. No filesystem paths, libc dependency,
 * data parser, secret input or persistent output. Linux memfd_create is available
 * on Android 9 kernels; the Java owner always closes the returned descriptor.
 * JNI signature: static int RamFile.createFd(). */
__attribute__((visibility("default")))
int Java_app_kavorynx_vault_RamFile_createFd(void *environment, void *owner) {
    (void)environment; (void)owner;
    static const char name[] = "Docryvia private PDF";
    long result;
#if defined(__aarch64__)
    register long x0 __asm__("x0") = (long)name;
    register long x1 __asm__("x1") = 1; /* MFD_CLOEXEC */
    register long x8 __asm__("x8") = 279;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x1), "r"(x8) : "memory");
    result = x0;
#elif defined(__arm__)
    register long r0 __asm__("r0") = (long)name;
    register long r1 __asm__("r1") = 1;
    register long r7 __asm__("r7") = 385;
    __asm__ volatile("svc #0" : "+r"(r0) : "r"(r1), "r"(r7) : "memory");
    result = r0;
#elif defined(__x86_64__)
    register long number __asm__("rax") = 319;
    register long arg0 __asm__("rdi") = (long)name;
    register long arg1 __asm__("rsi") = 1;
    __asm__ volatile("syscall" : "+r"(number) : "r"(arg0), "r"(arg1) : "rcx", "r11", "memory");
    result = number;
#elif defined(__i386__)
    register long number __asm__("eax") = 356;
    register long arg0 __asm__("ebx") = (long)name;
    register long arg1 __asm__("ecx") = 1;
    __asm__ volatile("int $0x80" : "+r"(number) : "r"(arg0), "r"(arg1) : "memory");
    result = number;
#else
#error Unsupported Android ABI
#endif
    return result < 0 ? -1 : (int)result;
}
