from pathlib import Path
from lxml import etree
import re, zipfile
root=Path(__file__).resolve().parents[1]
main=root/'android/app/src/main'
manifest=(main/'AndroidManifest.xml').read_text()
service=(main/'java/app/kavorynx/vault/SenviyaAutofillService.kt').read_text()
ui=(main/'java/app/kavorynx/vault/SenviyaScreens.kt').read_text()
repo=(main/'java/app/kavorynx/vault/VaultRepository.kt').read_text()
crypto=(main/'java/app/kavorynx/vault/Crypto.kt').read_text()
assert not (root/'extension').exists(), 'Unexpected browser extension directory'
assert '<uses-permission android:name="android.permission.INTERNET"' not in manifest
for prohibited in ['ACCESS_FINE_LOCATION','READ_SMS','QUERY_ALL_PACKAGES','SYSTEM_ALERT_WINDOW','BIND_ACCESSIBILITY_SERVICE']:
 assert prohibited not in manifest, prohibited
assert 'android:allowBackup="false"' in manifest
assert 'android:usesCleartextTraffic="false"' in manifest
assert 'SaveCredentialActivity' in manifest
assert 'SenviyaAutofillService' in manifest
assert 'onSaveRequest' in service and 'SaveInfo.Builder' in service and 'callback.onSuccess(pi.intentSender)' in service
assert 'n.webScheme' in service and 'originScheme == "https"' in service
assert 'accountsForHost(host)' in (main/'java/app/kavorynx/vault/AutofillUnlockActivity.kt').read_text()
assert 'DomainPolicy.matches' in (main/'java/app/kavorynx/vault/VaultSession.kt').read_text()
assert 'AES/GCM/NoPadding' in crypto and 'PBKDF2WithHmacSHA256' in crypto
assert 'category' in repo and 'encrypted-vault.kvx' in repo
assert all(x in ui for x in ['SenviyaIntro','SenviyaHome','SenviyaDocuments','SenviyaWallet','SenviyaPasswords','SenviyaBottomBar'])
assert 'Private Documents &amp; Passwords' in (main/'res/values/strings.xml').read_text() and 'Docryvia' in (main/'res/values/strings.xml').read_text()
assert not any('Extension' in p.name for p in root.rglob('*'))
xml_files=list(main.rglob('*.xml'))
for p in xml_files:
 etree.parse(str(p))
print('PASS: Android-only project: no extension files')
print('PASS: restrictive Android manifest permissions, backup disabled, HTTPS cleartext disabled')
print('PASS: system autofill save + authenticated fill + HTTPS scheme gate in source')
print('PASS: crypto, categories, wallet, onboarding, bottom nav source contracts')
print('PASS: XML parse:',len(xml_files),'resources/manifest')
print('NOTE: source checks do not prove Android compiles or runs')

# Current Play Store requirement, static source check only.
gradle=(root/'android/app/build.gradle.kts').read_text()
assert 'targetSdk = 36' in gradle and 'compileSdk = 36' in gradle
assert (main/'java/app/kavorynx/vault/PasswordHealth.kt').exists()
print('PASS: API 36 configuration and local-only password-health module present')

# v0.5 regression contracts: these inspect wiring only; they are NOT runtime tests.
entry=(main/'java/app/kavorynx/vault/MainActivity.kt').read_text()
assert 'stagedEncryptedBackup' in entry and 'noBackupFilesDir' in entry
assert 'Encrypted backup saved and verified' in entry + (main/'res/values/strings.xml').read_text()
assert 'repo.readEncryptedZip(bytes, chars)' in entry
assert 'withContext(Dispatchers.IO) { VaultSession.save(updated, repo) }' in entry
assert 'withContext(Dispatchers.IO) { VaultSession.remove(editing.id, repo) }' in entry
assert 'else ({ item ->' in entry and 'else ({' in entry
assert 'ExpiryPolicy.validate' in entry and 'favorite = favorite' in entry
assert 'PasswordHealth.analyze' in entry
assert 'val favorite: Boolean = false' in repo and 'val expiryDate: String = ""' in repo
assert (main/'java/app/kavorynx/vault/ExpiryPolicy.kt').exists()
assert 'onShareAddress' in entry and 'Share address outside Docryvia?' in (main/'res/values/strings.xml').read_text()
print('PASS: v0.5 backup staging, IO saves, favorites/expiry, share confirmation wiring')

assert 'CAMERA' in manifest and 'SecureCaptureActivity' in manifest and 'DocumentViewerActivity' in manifest
assert 'VaultTileService' in manifest and 'BIND_QUICK_SETTINGS_TILE' in manifest
assert 'supportsInlineSuggestions="true"' in (main/'res/xml/autofill_service.xml').read_text()
assert 'appSignatures' in repo and 'fileRef' in repo and 'totpSecret' in repo
assert '1..2' in repo and 'docryvia:document:v1:' in repo
print('PASS: v0.7 scanner, secure viewer, tile, schema evolution and inline-autofill wiring')

assert 'authenticatorScanner' in entry and 'scanningDraft = null' in entry
assert 'rememberLauncherForActivityResult' not in entry[entry.index('@Composable private fun ItemEditor'):entry.index('@Composable private fun GeneratorPage')]
assert 'RamFile.descriptor(raw)' in (main/'java/app/kavorynx/vault/DocumentViewerActivity.kt').read_text()
print('PASS: root-owned QR result lifecycle and seekable memory-only PDF descriptor wiring')
