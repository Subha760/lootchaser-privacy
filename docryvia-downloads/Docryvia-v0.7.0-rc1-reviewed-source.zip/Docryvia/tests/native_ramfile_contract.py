"""Verify native RAM descriptor behavior on the Linux build host, not Android hardware."""
from pathlib import Path
import ctypes, os, fcntl, struct, platform
root = Path(__file__).resolve().parents[1]
libs = root/'android/app/src/main/jniLibs'
for abi, machine in [('arm64-v8a',183),('armeabi-v7a',40),('x86',3),('x86_64',62)]:
    b=(libs/abi/'libdocryvia_ramfile.so').read_bytes()
    assert b[:4]==b'\x7fELF' and b[5]==1
    assert struct.unpack_from('<H',b,18)[0]==machine
    is64=b[4]==2
    phoff=struct.unpack_from('<Q' if is64 else '<I',b,32 if is64 else 28)[0]
    size,num=struct.unpack_from('<HH',b,54 if is64 else 42)
    for i in range(num):
        offset=phoff+i*size;kind=struct.unpack_from('<I',b,offset)[0]
        if kind==1:
            align=struct.unpack_from('<Q' if is64 else '<I',b,offset+(48 if is64 else 28))[0]
            assert align>=16384
        if kind==0x6474e551:
            flags=struct.unpack_from('<I',b,offset+(4 if is64 else 24))[0]
            assert not flags&1, 'Executable native stack'
print('PASS: four ABI bridge ELF identities, 16 KB LOAD alignment and non-executable stack.')
abi={'x86_64':'x86_64','aarch64':'arm64-v8a'}.get(platform.machine())
assert abi, 'Run native behavioral contract on Linux x86_64 or aarch64'
lib=ctypes.CDLL(str(libs/abi/'libdocryvia_ramfile.so'))
f=lib.Java_app_kavorynx_vault_RamFile_createFd;f.argtypes=[ctypes.c_void_p,ctypes.c_void_p];f.restype=ctypes.c_int
for i in range(100):
    fd=f(None,None); assert fd>=0
    try:
        assert fcntl.fcntl(fd,fcntl.F_GETFD)&fcntl.FD_CLOEXEC
        assert 'memfd:' in os.readlink('/proc/self/fd/'+str(fd))
        payload=b'private PDF fixture contents';os.write(fd,payload)
        assert os.fstat(fd).st_size==len(payload) and os.fstat(fd).st_nlink==0
        os.lseek(fd,0,os.SEEK_SET);assert os.read(fd,100)==payload
    finally:os.close(fd)
print('PASS: 100 anonymous seekable RAM-file read/write/close round trips, correct size and CLOEXEC.')
