package app.kavorynx.vault

import android.text.InputType
import androidx.biometric.BiometricManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 35], application = DocryviaApp::class)
class SetupAndAutofillUnitTest {
    private fun emptyRepo(): VaultRepository {
        VaultSession.lock()
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit()
        app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        return VaultRepository(app)
    }
    @Test fun requiredQuestionIsConfiguredWithSeparateWorkingRecoveryPaths() {
        val repo = emptyRepo()
        val created = repo.createWithQuestion("setup master password".toCharArray(), "school", "St. Marys".toCharArray())
        assertEquals("school", repo.recoveryQuestion())
        assertNotEquals(created.recoveryKey, created.questionCode)
        assertArrayEquals(created.key, repo.unlock("setup master password".toCharArray()))
        val reset = repo.resetWithQuestion("st marys".toCharArray(), created.questionCode, "new master password".toCharArray())
        assertArrayEquals(created.key, reset)
        assertNull(repo.recoveryQuestion())
        assertArrayEquals(created.key, repo.resetPassword(created.recoveryKey, "last master password".toCharArray()))
        created.key.fill(0); reset.fill(0)
    }
    @Test fun invalidRequiredAnswersNeverInitializeOrWriteVault() {
        for (answer in listOf("", "!?!", "x", "a".repeat(201))) {
            val repo = emptyRepo()
            try { repo.createWithQuestion("setup master password".toCharArray(), "school", answer.toCharArray()); fail("Invalid answer") }
            catch (_: IllegalArgumentException) { }
            assertFalse(repo.exists())
            assertFalse(java.io.File(RuntimeEnvironment.getApplication().filesDir, "secure_vault.dat").exists())
        }
        val repo = emptyRepo()
        try { repo.createWithQuestion("setup master password".toCharArray(), "unknown", "answer".toCharArray()); fail("Invalid question") }
        catch (_: IllegalArgumentException) { }
        assertFalse(repo.exists())
    }
    @Test fun questionSetupDoesNotPersistPlaintextAnswerOrRescueCode() {
        val repo = emptyRepo(); val answer = "private unique school answer"
        val created = repo.createWithQuestion("setup master password".toCharArray(), "school", answer.toCharArray())
        val prefs = RuntimeEnvironment.getApplication().getSharedPreferences("kavorynx_config", 0).all.toString()
        assertFalse(prefs.contains(answer)); assertFalse(prefs.contains(created.questionCode)); assertFalse(prefs.contains(created.recoveryKey))
        created.key.fill(0)
    }
    @Test fun epfoUanAndPasswordAreRecognizedWithoutAutocompleteHints() {
        assertEquals(LoginFieldRole.USERNAME, LoginFieldPolicy.classify(emptyList(), mapOf("type" to "text", "id" to "userName", "name" to "userName", "autocomplete" to "off"), null, 0))
        assertEquals(LoginFieldRole.USERNAME, LoginFieldPolicy.classify(emptyList(), mapOf("id" to "uan"), null, 0))
        assertEquals(LoginFieldRole.PASSWORD, LoginFieldPolicy.classify(emptyList(), mapOf("type" to "password", "autocomplete" to "off"), null, 0))
        assertEquals(LoginFieldRole.NONE, LoginFieldPolicy.classify(emptyList(), mapOf("type" to "text", "id" to "captchaFA"), null, 0))
        assertEquals(LoginFieldRole.NONE, LoginFieldPolicy.classify(emptyList(), mapOf("type" to "hidden", "id" to "hidPassword"), null, 0))
    }
    @Test fun oneTimeCodesAndNonLoginFieldsCannotBeMistakenForLoginCredentials() {
        for (attributes in listOf(mapOf("autocomplete" to "one-time-code", "type" to "password"), mapOf("id" to "otp"), mapOf("type" to "search", "id" to "username"), mapOf("id" to "firstName")))
            assertEquals(LoginFieldRole.NONE, LoginFieldPolicy.classify(emptyList(), attributes, null, 0))
        assertEquals(LoginFieldRole.PASSWORD, LoginFieldPolicy.classify(emptyList(), emptyMap(), null, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))
        assertEquals(LoginFieldRole.USERNAME, LoginFieldPolicy.classify(emptyList(), mapOf("autocomplete" to "section-login username"), null, 0))
    }
    @Test fun providerStatusRejectsGoogleAndDifferentServicesInSamePackage() {
        assertEquals(true, AutofillReadiness.matchesComponent("app.kavorynx.vault/.SenviyaAutofillService", "app.kavorynx.vault"))
        assertEquals(false, AutofillReadiness.matchesComponent("com.google.android.gms/.autofill.Service", "app.kavorynx.vault"))
        assertEquals(false, AutofillReadiness.matchesComponent("app.kavorynx.vault/.OtherService", "app.kavorynx.vault"))
        assertNull(AutofillReadiness.matchesComponent(null, "app.kavorynx.vault"))
        val app = RuntimeEnvironment.getApplication()
        android.provider.Settings.Secure.putString(app.contentResolver, "autofill_service", "app.kavorynx.vault/.SenviyaAutofillService")
        assertTrue(AutofillReadiness.selected(app))
        android.provider.Settings.Secure.putString(app.contentResolver, "autofill_service", "com.google.android.gms/.autofill.Service")
        assertFalse(AutofillReadiness.selected(app))
        android.provider.Settings.Secure.putString(app.contentResolver, "autofill_service", null)
    }
    @Test fun explicitAuthenticationMethodsNeverEnableWeakFace() {
        val unlock = DeviceUnlock(emptyRepo())
        assertEquals(BiometricManager.Authenticators.BIOMETRIC_STRONG, unlock.flags(UnlockMethod.BIOMETRIC))
        assertEquals(if (android.os.Build.VERSION.SDK_INT >= 30) BiometricManager.Authenticators.DEVICE_CREDENTIAL else 0, unlock.flags(UnlockMethod.SCREEN_LOCK))
    }
    @Test fun recoveryClipboardUsesSensitiveFlagAndClearsItsOwnCopy() {
        emptyRepo()
        val app = RuntimeEnvironment.getApplication()
        val key = Crypto.printRecoveryToken(ByteArray(32) { 7 })
        SensitiveClipboard.copy(app, key)
        val clipboard = app.getSystemService(android.content.ClipboardManager::class.java)
        assertEquals(key, clipboard.primaryClip!!.getItemAt(0).text.toString())
        if (android.os.Build.VERSION.SDK_INT >= 33) assertTrue(clipboard.primaryClipDescription!!.extras!!.getBoolean("android.content.extra.IS_SENSITIVE"))
        org.robolectric.Shadows.shadowOf(android.os.Looper.getMainLooper()).idleFor(java.time.Duration.ofSeconds(31))
        assertFalse(clipboard.hasPrimaryClip())
    }

}
