package app.kavorynx.vault

import android.app.Activity
import android.app.assist.AssistStructure
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.Signature
import android.content.pm.SigningInfo
import android.os.Looper
import android.util.Pair
import android.view.View
import android.view.ViewStructure
import android.view.WindowManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.util.ReflectionHelpers
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28, 35], application = DocryviaApp::class)
@LooperMode(LooperMode.Mode.PAUSED)
class AndroidIntegrationUnitTest {
    private val context get() = RuntimeEnvironment.getApplication()
    private fun vault(): VaultRepository {
        VaultSession.lock(); context.getSharedPreferences("kavorynx_config", 0).edit().clear().commit()
        context.filesDir.listFiles()?.forEach { it.deleteRecursively() }
        val repo = VaultRepository(context); val (key, _) = repo.create("integration password".toCharArray()); VaultSession.start(key, repo)
        return repo
    }
    private fun node(host: String? = null, scheme: String? = null, type: String? = null): AssistStructure.ViewNode {
        val node = ReflectionHelpers.callConstructor(AssistStructure.ViewNode::class.java)
        ReflectionHelpers.setField(node, "mWebDomain", host); ReflectionHelpers.setField(node, "mWebScheme", scheme)
        ReflectionHelpers.setField(node, "mAutofillId", View(context).autofillId)
        if (type != null) ReflectionHelpers.setField(node, "mHtmlInfo", object : ViewStructure.HtmlInfo() {
            override fun getTag() = "input"
            override fun getAttributes() = listOf(Pair("type", type))
        })
        return node
    }
    private fun structure(root: AssistStructure.ViewNode, vararg children: AssistStructure.ViewNode): AssistStructure {
        ReflectionHelpers.setField(root, "mChildren", children)
        val window = ReflectionHelpers.newInstance(AssistStructure.WindowNode::class.java)
        ReflectionHelpers.setField(window, "mRoot", root)
        return AssistStructure().also { ReflectionHelpers.setField(it, "mWindowNodes", arrayListOf(window)) }
    }
    @Test fun htmlFieldsWithoutAutocompleteHintsAreDetected() {
        val password = node(type = "password"); val email = node(type = "email")
        val result = FieldScanner.scan(structure(node("example.com", "https"), password, email))
        assertEquals("example.com", result.webHost); assertTrue(result.hasWebContent)
        assertEquals(password.autofillId, result.password); assertEquals(email.autofillId, result.username)
    }
    @Test fun insecureMixedAndUnknownOriginsAreRejected() {
        assertNull(FieldScanner.scan(structure(node("example.com", "http"), node(type = "password"))).webHost)
        assertNull(FieldScanner.scan(structure(node("example.com", null), node(type = "password"))).webHost)
        assertNull(FieldScanner.scan(structure(node("example.com", "https"), node("attacker.com", "https", "password"))).webHost)
    }
    @Test fun nativeFieldsAreDistinguishedFromWebContent() {
        val native = FieldScanner.scan(structure(node(), node(type = "password")))
        assertFalse(native.hasWebContent); assertNotNull(native.password)
        val embedded = FieldScanner.scan(structure(node("example.com", "http"), node(type = "password")))
        assertTrue(embedded.hasWebContent); assertNull(embedded.webHost)
    }
    @Test fun appSignatureChangesInvalidateCredentialAssociation() {
        val repo = vault(); val pkg = "com.example.trusted"
        val signing = SigningInfo(); shadowOf(signing).setSignatures(arrayOf(Signature("aabb")))
        val info = PackageInfo().apply { packageName = pkg; signingInfo = signing }
        shadowOf(context.packageManager).installPackage(info)
        val identity = AppIdentity.signature(context, pkg)!!
        VaultSession.save(VaultItem(title = "Login", secret = "secret", linkedApps = listOf(pkg), appSignatures = mapOf(pkg to identity)), repo)
        assertEquals(1, VaultSession.accountsForApp(context, pkg).size)
        shadowOf(signing).setSignatures(arrayOf(Signature("ccdd")))
        shadowOf(context.packageManager).installPackage(info)
        assertTrue(VaultSession.accountsForApp(context, pkg).isEmpty()); VaultSession.lock()
    }
    @Test fun secureViewerWipesOwnedBytesOnStop() {
        val repo = vault(); val bytes = "private document".toByteArray()
        val item = VaultItem(type = TYPE_DOCUMENT, title = "Private", mime = "text/plain", fileData = Crypto.b64(bytes))
        VaultSession.save(item, repo)
        val controller = Robolectric.buildActivity(DocumentViewerActivity::class.java,
            Intent(context, DocumentViewerActivity::class.java).putExtra("item_id", item.id)).create().start().resume()
        val activity = controller.get()
        assertTrue(activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
        val owned = ReflectionHelpers.getField<ByteArray>(activity, "bytes")
        assertArrayEquals(bytes, owned)
        controller.pause().stop()
        assertTrue(activity.isFinishing); assertTrue(owned.all { it == 0.toByte() })
        assertNull(ReflectionHelpers.getField<ByteArray?>(activity, "bytes")); controller.destroy(); VaultSession.lock()
    }
    @Test fun lockedViewerCannotOpenVaultDocument() {
        VaultSession.lock()
        val controller = Robolectric.buildActivity(DocumentViewerActivity::class.java,
            Intent(context, DocumentViewerActivity::class.java).putExtra("item_id", "any")).create()
        assertTrue(controller.get().isFinishing); assertNull(ReflectionHelpers.getField<ByteArray?>(controller.get(), "bytes")); controller.destroy()
    }
    @Test fun foregroundTimerLocksUnattendedVaultAndNeverOptionPreservesIt() {
        val controller = Robolectric.buildActivity(Activity::class.java).create().start().resume()
        vault(); LockPreferences.setTimeout(context, 60_000)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(65)); assertFalse(VaultSession.unlocked)
        vault(); LockPreferences.setTimeout(context, 0)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMinutes(6)); assertTrue(VaultSession.unlocked)
        VaultSession.lock(); controller.pause().stop().destroy()
    }
    @Test fun quickSettingsTileLocksSharedVaultSession() {
        vault(); val service = VaultTileService()
        ReflectionHelpers.callInstanceMethod<Unit>(service, "attachBaseContext", ReflectionHelpers.ClassParameter.from(android.content.Context::class.java, context))
        service.onClick(); assertFalse(VaultSession.unlocked); assertTrue(VaultSession.items.isEmpty())
        assertEquals(android.service.quicksettings.Tile.STATE_INACTIVE, service.qsTile.state)
    }
    @Test fun epfoFormWithoutHintsDetectsUanButExcludesCaptchaAndHiddenPassword() {
        fun input(attributes: Map<String, String>): AssistStructure.ViewNode = node().also { n ->
            ReflectionHelpers.setField(n, "mHtmlInfo", object : ViewStructure.HtmlInfo() {
                override fun getTag() = "input"
                override fun getAttributes() = attributes.map { Pair(it.key, it.value) }
            })
        }
        val uan = input(mapOf("type" to "text", "name" to "userName", "autocomplete" to "off"))
        val password = input(mapOf("type" to "password", "name" to "password", "autocomplete" to "off"))
        val captcha = input(mapOf("type" to "text", "name" to "captchaFA"))
        val hidden = input(mapOf("type" to "hidden", "name" to "hidPassword"))
        val result = FieldScanner.scan(structure(node("unifiedportal-mem.epfindia.gov.in", "https"), uan, password, captcha, hidden))
        assertEquals(uan.autofillId, result.username); assertEquals(password.autofillId, result.password)
        assertEquals("unifiedportal-mem.epfindia.gov.in", result.webHost)
    }
    @Test fun vaultEntryWindowIsSecureAndExcludedFromOtherAutofillProviders() {
        VaultSession.lock()
        val controller = Robolectric.buildActivity(MainActivity::class.java).create()
        assertEquals(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS, controller.get().window.decorView.importantForAutofill)
        assertTrue(controller.get().window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)
        controller.destroy()
    }

    @Test fun initialAutofillResponseAuthenticatesAndNeverReturnsPlaintextPassword() {
        val repo = vault()
        VaultSession.save(VaultItem(title = "EPFO", site = "https://unifiedportal-mem.epfindia.gov.in", username = "123456789012", secret = "NeverReturnBeforeAuthentication"), repo)
        val form = structure(node("unifiedportal-mem.epfindia.gov.in", "https"), node(type = "password"), node(type = "email"))
        ReflectionHelpers.setField(form, "mActivityComponent", android.content.ComponentName("com.android.chrome", "Chrome"))
        val fillContext = ReflectionHelpers.newInstance(android.service.autofill.FillContext::class.java)
        ReflectionHelpers.setField(fillContext, "mStructure", form)
        val request = ReflectionHelpers.newInstance(android.service.autofill.FillRequest::class.java)
        ReflectionHelpers.setField(request, if (android.os.Build.VERSION.SDK_INT >= 30) "mFillContexts" else "mContexts", arrayListOf(fillContext))
        ReflectionHelpers.setField(request, "mFlags", if (android.os.Build.VERSION.SDK_INT >= 33) android.service.autofill.FillRequest.FLAG_SUPPORTS_FILL_DIALOG else 0)
        var response: android.service.autofill.FillResponse? = null
        val iface = Class.forName("android.service.autofill.IFillCallback")
        val endpoint = java.lang.reflect.Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { _, method, args ->
            if (method.name == "onSuccess") response = args?.filterIsInstance<android.service.autofill.FillResponse>()?.firstOrNull()
            null
        }
        val callback = ReflectionHelpers.newInstance(android.service.autofill.FillCallback::class.java)
        ReflectionHelpers.setField(callback, "mCallback", endpoint)
        val service = SenviyaAutofillService()
        ReflectionHelpers.callInstanceMethod<Unit>(service, "attachBaseContext", ReflectionHelpers.ClassParameter.from(android.content.Context::class.java, context))
        service.onFillRequest(request, android.os.CancellationSignal(), callback)
        assertNotNull(response)
        assertNotNull(ReflectionHelpers.callInstanceMethod<android.service.autofill.SaveInfo?>(response!!, "getSaveInfo"))
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val datasets = ReflectionHelpers.callInstanceMethod<List<android.service.autofill.Dataset>?>(response!!, "getDatasets").orEmpty()
            assertTrue(datasets.isNotEmpty())
            for (dataset in datasets) {
                assertNotNull(ReflectionHelpers.callInstanceMethod<android.content.IntentSender?>(dataset, "getAuthentication"))
                val values = ReflectionHelpers.callInstanceMethod<List<android.view.autofill.AutofillValue?>>(dataset, "getFieldValues")
                assertTrue(values.all { it == null })
            }
            assertFalse(ReflectionHelpers.callInstanceMethod<Array<android.view.autofill.AutofillId>?>(response!!, "getFillDialogTriggerIds").isNullOrEmpty())
        } else assertNotNull(ReflectionHelpers.callInstanceMethod<android.content.IntentSender?>(response!!, "getAuthentication"))
        VaultSession.lock()
    }

}
