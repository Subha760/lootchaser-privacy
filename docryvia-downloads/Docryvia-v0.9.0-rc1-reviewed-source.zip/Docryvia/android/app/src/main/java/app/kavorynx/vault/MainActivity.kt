package app.kavorynx.vault

import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ClipDescription
import android.os.Handler
import android.os.Looper
import android.graphics.Color as AndroidColor
import android.view.WindowManager
import android.view.autofill.AutofillManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.File
import java.security.MessageDigest
import java.time.LocalDate



@Composable fun SenviyaAppTheme(content: @Composable () -> Unit) = SenviyaTheme(content)

class MainActivity : FragmentActivity() {
    var privacyEvent by mutableIntStateOf(0); private set
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        if (!BuildConfig.DEMO_MODE) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val dark = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
        window.statusBarColor = if (dark) AndroidColor.rgb(18, 22, 26) else AndroidColor.rgb(244, 247, 251)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (dark) 0 else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        window.navigationBarColor = if (dark) AndroidColor.rgb(18, 22, 26) else AndroidColor.rgb(255, 255, 255)
        // After abrupt process death, remove orphaned temporary encrypted exports.
        // Delay cleanup so an in-progress system file picker isn't disrupted.
        noBackupFilesDir.listFiles()?.filter {
            it.name.startsWith("encrypted-export-") && it.name.endsWith(".zip") &&
                (System.currentTimeMillis() - it.lastModified()) > 24L * 60L * 60L * 1000L
        }?.forEach { it.delete() }
        val repo = VaultRepository(this)
        if (BuildConfig.DEMO_MODE) DemoVault.prepare(this, repo)
        if (BuildConfig.DEMO_MODE && intent.getStringExtra("demo_page") == "PDF") {
            startActivity(Intent(this, DocumentViewerActivity::class.java).putExtra("item_id", "demo-school"))
        }
        val quick = DeviceUnlock(repo)
        setContent { SenviyaAppTheme { SenviyaApp(this, repo, quick) } }
    }
    override fun onUserInteraction() { super.onUserInteraction(); LockPreferences.interaction() }
    override fun onStop() {
        super.onStop()
        // Application owns the 30-second session grace period. Clear transient UI secrets now.
        privacyEvent++
    }
}

@Composable private fun SenviyaApp(activity: MainActivity, repo: VaultRepository, quick: DeviceUnlock) {
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var recoveryDisplay by remember { mutableStateOf("") }
    var questionKitDisplay by remember { mutableStateOf(false) }
    var pendingQuestionCode by remember { mutableStateOf("") }
    var pendingDeviceEnable by remember { mutableStateOf(false) }
    var showAccess by remember { mutableStateOf(!activity.getSharedPreferences("senviya_intro", Context.MODE_PRIVATE).getBoolean("seen_access_v1", false)) }
    var cameraAllowed by remember { mutableStateOf(androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    var scannerRequested by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) {
        val shown = message
        if (shown.isNotBlank()) { snackbar.showSnackbar(shown, duration = SnackbarDuration.Short); if (message == shown) message = "" }
    }
    LaunchedEffect(recoveryDisplay, VaultSession.unlocked, pendingDeviceEnable) {
        if (recoveryDisplay.isEmpty() && pendingDeviceEnable && VaultSession.unlocked) {
            pendingDeviceEnable = false
            quick.enable(activity) { _, info -> message = info }
        }
    }
    var page by remember { mutableStateOf(if (BuildConfig.DEMO_MODE) activity.intent.getStringExtra("demo_page")?.takeIf { it in setOf("Home", "Passwords", "Documents", "Wallet", "Settings", "Generator", "Authenticator", "Duplicates") } ?: "Home" else "Home") }
    val introductionPrefs = remember { activity.getSharedPreferences("senviya_intro", Context.MODE_PRIVATE) }
    var introductionSeen by remember { mutableStateOf(introductionPrefs.getBoolean("seen_v2", false)) }
    var selectedDocumentCategory by remember { mutableStateOf("Other") }
    var pendingCsvUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var csvImportApproved by remember { mutableStateOf(false) }
    var managerPreview by remember { mutableStateOf<ImportPreview?>(null) }
    var scanningDraft by remember { mutableStateOf<VaultItem?>(null) }
    var edit by remember { mutableStateOf<VaultItem?>(null) }
    var newType by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var importPassword by remember { mutableStateOf("") }
    var stagedEncryptedBackup by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(activity.privacyEvent) {
        if (activity.privacyEvent > 0) {
            recoveryDisplay = ""; pendingQuestionCode = ""; pendingDeviceEnable = false // Clear recovery material after background.
            edit = null; newType = null; importPassword = ""
            // Only an *already encrypted* ZIP remains staged while Android's picker is open.
        }
    }
    var pendingBackupUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var pendingDocumentImport by remember { mutableStateOf<android.net.Uri?>(null) }
    var pendingDocumentExport by remember { mutableStateOf<android.net.Uri?>(null) }
    var documentExportId by remember { mutableStateOf<String?>(null) }

    val backupWriter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val staged = stagedEncryptedBackup
        stagedEncryptedBackup = null
        if (uri == null || staged == null) {
            staged?.delete()
            message = UiText.get(R.string.ui_160)
        } else {
            scope.launch {
                busy = true
                try {
                    val verified = withContext(Dispatchers.IO) {
                        // The picker can stop MainActivity: the vault remains locked,
                        // and ONLY the password-encrypted backup ZIP is written.
                        activity.contentResolver.openOutputStream(uri, "w")!!.use { out ->
                            staged.inputStream().use { it.copyTo(out, 8192) }
                            out.flush()
                        }
                        val expected = MessageDigest.getInstance("SHA-256")
                            .digest(staged.readBytes())
                        val actual = runCatching {
                            activity.contentResolver.openInputStream(uri)!!.use { input ->
                                val md = MessageDigest.getInstance("SHA-256")
                                val buf = ByteArray(8192)
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) { break }
                                    md.update(buf, 0, n)
                                }
                                md.digest()
                            }
                        }.getOrNull()
                        actual?.contentEquals(expected)
                    }
                    message = when (verified) {
                        true -> UiText.get(R.string.ui_314)
                        false -> UiText.get(R.string.ui_315)
                        null -> UiText.get(R.string.ui_316)
                    }
                } catch (_: Exception) { message = UiText.get(R.string.ui_161) }
                finally { staged.delete(); busy = false }
            }
        }
    }
    val backupReader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingBackupUri = uri
            importPassword = ""
            message = UiText.get(R.string.ui_162)
        }
    }
    // Register at the root: stopping MainActivity clears/disposes the editor while
    // the protected camera screen is open. The draft remains RAM-only until return or lock.
    val authenticatorScanner = rememberLauncherForActivityResult(com.journeyapps.barcodescanner.ScanContract()) { result ->
        val draft = scanningDraft; scanningDraft = null
        if (VaultSession.unlocked && draft != null) {
            val scanned = result.contents
            if (scanned == null) { edit = draft; newType = null }
            else try {
                TotpGenerator.parse(scanned)
                edit = draft.copy(totpSecret = scanned); newType = null
            } catch (_: Exception) { edit = draft; newType = null; message = UiText.get(R.string.ui_191) }
        }
    }
    fun scannerOptions() = com.journeyapps.barcodescanner.ScanOptions().setDesiredBarcodeFormats(com.journeyapps.barcodescanner.ScanOptions.QR_CODE)
        .setPrompt(UiText.get(R.string.qr_prompt)).setBeepEnabled(false).setCaptureActivity(SecureCaptureActivity::class.java)
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { allowed ->
        cameraAllowed = allowed
        if (scannerRequested) {
            scannerRequested = false
            if (allowed && VaultSession.unlocked && scanningDraft != null) authenticatorScanner.launch(scannerOptions())
            else { edit = scanningDraft; scanningDraft = null; message = UiText.get(R.string.access_camera_denied) }
        } else if (!allowed) message = UiText.get(R.string.access_camera_denied)
    }
    DisposableEffect(activity) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) cameraAllowed = androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }
    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pendingCsvUri = uri; csvImportApproved = false
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pendingDocumentImport = uri
    }
    val documentWriter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        pendingDocumentExport = uri
        // If the picker sent us to the background, we locked. Finish only after the next unlock.
    }
    LaunchedEffect(VaultSession.unlocked, pendingDocumentImport, pendingDocumentExport, pendingCsvUri, csvImportApproved) {
        if (VaultSession.unlocked) {
            pendingCsvUri?.let { uri ->
                try {
                    val preview = withContext(Dispatchers.IO) {
                        val source = activity.contentResolver.openInputStream(uri)!!.use { input ->
                            val buffer = java.io.ByteArrayOutputStream(); val chunk = ByteArray(8192)
                            while (true) { val n = input.read(chunk); if (n < 0) { break }
                                require(buffer.size() + n <= 5_000_000); buffer.write(chunk, 0, n) }
                            buffer.toString(Charsets.UTF_8.name())
                        }
                        ManagerImporter.parse(source)
                    }
                    if (VaultSession.unlocked) managerPreview = preview
                } catch (_: Exception) { message = UiText.get(R.string.ui_163) }
                finally { pendingCsvUri = null }
            }
            pendingDocumentImport?.let { uri ->
                busy = true; message = ""
                try {
                    val bytes = withContext(Dispatchers.IO) {
                        activity.contentResolver.openInputStream(uri)!!.use { input ->
                            val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192)
                            while (true) {
                                val n = input.read(buffer); if (n < 0) { break }
                                require(out.size() + n <= 8 * 1024 * 1024) { "File is too large" }
                                out.write(buffer, 0, n)
                            }; out.toByteArray()
                        }
                    }
                    try {
                        val name = androidx.documentfile.provider.DocumentFile.fromSingleUri(activity, uri)?.name ?: "Document"
                        val doc = withContext(Dispatchers.Default) {
                            VaultItem(type = TYPE_DOCUMENT, title = name, fileName = name,
                                mime = activity.contentResolver.getType(uri) ?: "application/octet-stream",
                                fileData = Crypto.b64(bytes), category = selectedDocumentCategory)
                        }
                        withContext(Dispatchers.IO) { VaultSession.save(doc, repo) }
                        message = UiText.get(R.string.ui_164)
                    } finally { bytes.fill(0) }
                } catch (_: Exception) { message = UiText.get(R.string.ui_165) }
                finally { pendingDocumentImport = null; busy = false }
            }
            pendingDocumentExport?.let { uri ->
                try {
                    val selected = VaultSession.items.firstOrNull { it.id == documentExportId && it.type == TYPE_DOCUMENT }
                        ?: error("Missing selected document")
                    withContext(Dispatchers.IO) {
                        val bytes = VaultSession.documentBytes(selected.id, repo)
                        try { activity.contentResolver.openOutputStream(uri, "w")!!.use { it.write(bytes) } }
                        finally { bytes.fill(0) }
                    }
                    message = UiText.get(R.string.ui_166)
                } catch (_: Exception) { message = UiText.get(R.string.ui_167) }
                finally { pendingDocumentExport = null; documentExportId = null }
            }
        }
    }

    LaunchedEffect(VaultSession.unlocked) {
        if (!VaultSession.unlocked) { managerPreview = null; scanningDraft = null; edit = null; newType = null }
    }
    BackHandler(enabled = VaultSession.unlocked && (edit != null || newType != null || page != "Home")) {
        when {
            edit != null -> edit = null
            newType != null -> newType = null
            else -> page = "Home"
        }
    }
    Box(Modifier.fillMaxSize().background(soft).safeDrawingPadding()) {
        when {
            BuildConfig.DEMO_MODE && activity.intent.getStringExtra("demo_page") == "SetupPreview" -> SenviyaSetup(false, 0) { _, _, _, _ -> }
            BuildConfig.DEMO_MODE && activity.intent.getStringExtra("demo_page") == "RecoveryPreview" -> SenviyaRecovery(Crypto.printRecoveryToken(ByteArray(32) { 1 })) { }
            BuildConfig.DEMO_MODE && activity.intent.getStringExtra("demo_page") == "AccessPreview" -> AccessPermissionsPage(activity, cameraAllowed, { cameraPermission.launch(android.Manifest.permission.CAMERA) }, { })
            !introductionSeen -> SenviyaIntro {
                introductionPrefs.edit().putBoolean("seen_v2", true).apply()
                introductionSeen = true
            }
            showAccess -> AccessPermissionsPage(activity, cameraAllowed,
                onCamera = { cameraPermission.launch(android.Manifest.permission.CAMERA) },
                onDone = { activity.getSharedPreferences("senviya_intro", Context.MODE_PRIVATE).edit().putBoolean("seen_access_v1", true).apply(); showAccess = false })
            !repo.exists() -> SenviyaSetup(busy, activity.privacyEvent) { password, question, answer, enableDevice ->
                if (!busy) {
                    busy = true
                    val capturedEvent = activity.privacyEvent
                    val chars = password.toCharArray(); val answerChars = answer.toCharArray()
                    scope.launch {
                        try {
                            val created = withContext(Dispatchers.Default) { repo.createWithQuestion(chars, question, answerChars) }
                            if (capturedEvent == activity.privacyEvent) {
                                VaultSession.start(created.key, repo)
                                recoveryDisplay = created.recoveryKey; questionKitDisplay = false
                                pendingQuestionCode = created.questionCode; pendingDeviceEnable = enableDevice
                            } else created.key.fill(0)
                        } catch (_: Exception) { message = UiText.get(R.string.ui_168) }
                        finally { chars.fill('\u0000'); answerChars.fill('\u0000'); busy = false }
                    }
                }
            }
            recoveryDisplay.isNotEmpty() -> SenviyaRecovery(recoveryDisplay, questionKitDisplay) {
                if (pendingQuestionCode.isNotEmpty()) {
                    recoveryDisplay = pendingQuestionCode; pendingQuestionCode = ""; questionKitDisplay = true
                } else recoveryDisplay = ""
            }
            !VaultSession.unlocked -> SenviyaUnlock(
                privacyEvent = activity.privacyEvent,
                busy = busy,
                questionId = repo.recoveryQuestion(),
                quickEnabled = repo.hasDeviceUnlock(),
                onMaster = { pw ->
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        val chars = pw.toCharArray()
                        scope.launch {
                            try {
                                val key = withContext(Dispatchers.Default) { repo.unlock(chars) }
                                if (capturedEvent == activity.privacyEvent) {
                                    VaultSession.start(key, repo); message = ""
                                } else key.fill(0)
                            } catch (_: Exception) { message = UiText.get(R.string.ui_169) }
                            finally { chars.fill('\u0000'); busy = false }
                        }
                    }
                },
                onRecovery = { token, newPassword ->
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        val chars = newPassword.toCharArray()
                        scope.launch {
                            try {
                                val key = withContext(Dispatchers.Default) { repo.resetPassword(token, chars) }
                                if (capturedEvent == activity.privacyEvent) {
                                    VaultSession.start(key, repo)
                                    message = UiText.get(R.string.ui_170)
                                } else key.fill(0)
                            } catch (_: Exception) { message = UiText.get(R.string.ui_171) }
                            finally { chars.fill('\u0000'); busy = false }
                        }
                    }
                },
                onQuestionRecovery = { answer, code, pw ->
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        val chars = pw.toCharArray(); val answerChars = answer.toCharArray()
                        scope.launch {
                            try {
                                val key = withContext(Dispatchers.Default) { repo.resetWithQuestion(answerChars, code, chars) }
                                if (capturedEvent == activity.privacyEvent) {
                                    VaultSession.start(key, repo)
                                    message = UiText.get(R.string.ui_172)
                                } else key.fill(0)
                            } catch (_: Exception) { message = UiText.get(R.string.ui_173) }
                            finally { chars.fill('\u0000'); answerChars.fill('\u0000'); busy = false }
                        }
                    }
                },
                onDevice = {
                    if (!busy) {
                        busy = true
                        quick.unlock(activity, UnlockMethod.BIOMETRIC) { _, info -> message = info; busy = false }
                    }
                },
                onScreenLock = {
                    if (!busy) { busy = true; quick.unlock(activity, UnlockMethod.SCREEN_LOCK) { _, info -> message = info; busy = false } }
                }
            )
            else -> {
                Column(Modifier.fillMaxSize()) {
                    SenviyaTopBar(onLock = { VaultSession.lock() }, count = VaultSession.activeItems.size)
                    Box(Modifier.weight(1f)) {
                        androidx.compose.animation.AnimatedContent(targetState = page, label = "vault_navigation",
                            transitionSpec = { androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(160)) togetherWith androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(100)) }) { destination ->
                        when (destination) {
                            "Home" -> SenviyaHome(VaultSession.activeItems.toList(),
                                onGo = { page = it }, onAdd = { newType = it },
                                onPickDocument = { if (!busy) { selectedDocumentCategory = "Other"; documentPicker.launch(arrayOf("*/*")) } })
                            "Passwords" -> SenviyaPasswords(VaultSession.activeItems.toList(),
                                onSelect = { edit = it }, onAdd = { newType = TYPE_PASSWORD },
                                onGenerator = { page = "Generator" }, onDuplicates = { page = "Duplicates" })
                            "Documents" -> SenviyaDocuments(VaultSession.activeItems.toList(),
                                onSelect = { edit = it },
                                onPick = { selectedDocumentCategory = it; documentPicker.launch(arrayOf("*/*")) })
                            "Wallet" -> SenviyaWallet(VaultSession.activeItems.toList(),
                                onSelect = { edit = it }, onAdd = { newType = it })
                            "Generator" -> GeneratorPage(activity)
                            "Duplicates" -> DuplicateReviewPage(repo, onNotice = { message = it }, onEdit = { edit = it })
                            "Authenticator" -> AuthenticatorPage(activity, onAdd = { newType = TYPE_AUTHENTICATOR }, onEdit = { edit = it })
                            "Settings" -> SettingsPage(
                                activity, quick, repo, onNotice = { message = it },
                                onExport = { password ->
                                    if (!busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        val chars = password.toCharArray()
                                        scope.launch {
                                            try {
                                                val staged = withContext(Dispatchers.IO) {
                                                    val bytes = VaultSession.export(repo, chars)
                                                    try {
                                                        // Verify encrypted archive before asking user where to save it.
                                                        repo.readEncryptedZip(bytes, chars)
                                                        val file = File.createTempFile("encrypted-export-", ".zip", activity.noBackupFilesDir)
                                                        try { file.outputStream().use { it.write(bytes) } }
                                                        catch (e: Exception) { file.delete(); throw e }
                                                        file
                                                    } finally { bytes.fill(0) }
                                                }
                                                if (capturedEvent == activity.privacyEvent) {
                                                    stagedEncryptedBackup?.delete()
                                                    stagedEncryptedBackup = staged
                                                    backupWriter.launch("Docryvia-encrypted-backup.zip")
                                                } else staged.delete()
                                            } catch (_: Exception) { message = UiText.get(R.string.ui_174) }
                                            finally { chars.fill('\u0000'); busy = false }
                                        }
                                    }
                                },
                                importPassword = importPassword,
                                onImportPassword = { importPassword = it },
                                selectedBackup = pendingBackupUri != null,
                                onImport = { backupReader.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                                onRestore = {
                                    val uri = pendingBackupUri
                                    if (uri != null && !busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        val pass = importPassword.toCharArray(); importPassword = ""
                                        scope.launch {
                                            try {
                                                val imported = withContext(Dispatchers.IO) {
                                                    val bytes = activity.contentResolver.openInputStream(uri)!!.use { input ->
                                                        val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192)
                                                        while (true) {
                                                            val n = input.read(buffer); if (n < 0) { break }
                                                            require(out.size() + n <= 100 * 1024 * 1024)
                                                            out.write(buffer, 0, n)
                                                        }; out.toByteArray()
                                                    }
                                                    repo.readEncryptedZip(bytes, pass)
                                                }
                                                if (capturedEvent == activity.privacyEvent && VaultSession.unlocked) {
                                                    withContext(Dispatchers.IO) { VaultSession.import(repo, imported) }
                                                    pendingBackupUri = null; message = UiText.get(R.string.ui_175)
                                                }
                                            } catch (_: Exception) { message = UiText.get(R.string.ui_176) }
                                            finally { pass.fill('\u0000'); busy = false }
                                        }
                                    }
                                },
                                onAuthenticator = { page = "Authenticator" },
                                onDuplicates = { page = "Duplicates" }, onAccess = { showAccess = true },
                                onCsvImport = { csvPicker.launch(arrayOf("text/*", "application/json", "application/vnd.ms-excel", "*/*")) },
                                busy = busy,
                                onQuestionSetup = { question, answer ->
                                    if (!busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        val chars = answer.toCharArray()
                                        scope.launch {
                                            try {
                                                val code = withContext(Dispatchers.Default) { VaultSession.setupQuestionRecovery(repo, question, chars) }
                                                if (capturedEvent == activity.privacyEvent) {
                                                    questionKitDisplay = true; recoveryDisplay = code
                                                }
                                            } catch (_: Exception) { message = UiText.get(R.string.ui_177) }
                                            finally { chars.fill('\u0000'); busy = false }
                                        }
                                    }
                                },
                                onQuestionDisable = {
                                    if (!busy) {
                                        busy = true
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) { VaultSession.removeQuestionRecovery(repo) }
                                                message = UiText.get(R.string.ui_178)
                                            } catch (_: Exception) { message = UiText.get(R.string.ui_179) }
                                            finally { busy = false }
                                        }
                                    }
                                },
                                onRotateRecovery = {
                                    if (!busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        scope.launch {
                                            try {
                                                val code = withContext(Dispatchers.IO) { VaultSession.rotateRecovery(repo) }
                                                if (capturedEvent == activity.privacyEvent) {
                                                    questionKitDisplay = false; recoveryDisplay = code
                                                }
                                            } catch (_: Exception) { message = UiText.get(R.string.ui_180) }
                                            finally { busy = false }
                                        }
                                    }
                                },
                                onChangePassword = { pw ->
                                    if (!busy) {
                                        busy = true
                                        val chars = pw.toCharArray()
                                        val capturedEvent = activity.privacyEvent
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.Default) { VaultSession.changePassword(repo, chars) }
                                                if (capturedEvent == activity.privacyEvent) message = UiText.get(R.string.ui_181)
                                            } catch (_: Exception) { message = UiText.get(R.string.ui_182) }
                                            finally { chars.fill('\u0000'); busy = false }
                                        }
                                    }
                                }
                            )
                        }
                    }
                    }
                    SenviyaBottomBar(page, onPage = { page = it })
                }
            }
        }
        // Present the editor *after* navigation, so every Add and Edit action has a real screen.
        if (VaultSession.unlocked && (edit != null || newType != null)) {
            val editing = edit
            val current = remember(editing, newType) { editing ?: VaultItem(type = newType ?: TYPE_NOTE) }
            ItemEditor(item = current, busy = busy, onDismiss = { edit = null; newType = null },
                onScanTotp = { draft ->
                    scanningDraft = draft
                    edit = null; newType = null
                    if (androidx.core.content.ContextCompat.checkSelfPermission(activity, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED)
                        authenticatorScanner.launch(scannerOptions())
                    else { scannerRequested = true; cameraPermission.launch(android.Manifest.permission.CAMERA) }
                },
                onSave = { updated ->
                    if (updated.type == TYPE_PASSWORD && (DomainPolicy.canonicalHost(updated.site) == null || updated.secret.isBlank())) {
                        message = UiText.get(R.string.ui_183)
                    } else if (updated.type == TYPE_AUTHENTICATOR && updated.totpSecret.isBlank()) {
                        message = UiText.get(R.string.authenticator_seed_required)
                    } else if (!ExpiryPolicy.validate(updated.expiryDate)) {
                        message = UiText.get(R.string.ui_184)
                    } else if (!busy) {
                        busy = true; message = ""
                        val capturedEvent = activity.privacyEvent
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { VaultSession.save(updated, repo) }
                                if (capturedEvent == activity.privacyEvent) {
                                    edit = null; newType = null
                                    message = UiText.get(if (updated.type == TYPE_DOCUMENT) R.string.ui_164 else R.string.ui_185)
                                }
                            } catch (_: Exception) { message = UiText.get(R.string.ui_186) }
                            finally { busy = false }
                        }
                    }
                },
                onDelete = if (editing == null || VaultSession.items.none { it.id == editing.id }) null else ({
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { VaultSession.remove(editing.id, repo) }
                                if (capturedEvent == activity.privacyEvent) {
                                    edit = null; newType = null; message = UiText.get(R.string.ui_187)
                                }
                            } catch (_: Exception) { message = UiText.get(R.string.ui_188) }
                            finally { busy = false }
                        }
                    }
                }),
                onViewDocument = if (editing?.type != TYPE_DOCUMENT) null else ({ item ->
                    activity.startActivity(Intent(activity, DocumentViewerActivity::class.java).putExtra("item_id", item.id))
                }),
                onExportDocument = if (editing?.type != TYPE_DOCUMENT) null else ({ item ->
                    documentExportId = item.id
                    edit = null
                    documentWriter.launch(item.fileName.ifBlank { "document.bin" })
                }),
                onShareAddress = if (editing?.type != TYPE_ADDRESS) null else ({ item ->
                    // Only share an explicitly selected record, never the full vault.
                    val summary = listOf(item.username, item.notes, item.site)
                        .filter { it.isNotBlank() }.joinToString("\n")
                    if (summary.isNotBlank()) {
                        activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, summary)
                        }, UiText.get(R.string.ui_317)))
                    }
                }))
        }
        if (managerPreview != null && VaultSession.unlocked) {
            val preview = managerPreview!!
            AlertDialog(onDismissRequest = { managerPreview = null },
                title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_154, (preview.format), (preview.total))) },
                text = { Column(Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState())) {
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_155, (preview.items.size), (preview.skipped.size)))
                    preview.skipped.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                } },
                confirmButton = { Button(enabled = preview.items.isNotEmpty() && !busy, onClick = {
                    busy = true
                    scope.launch {
                        try { withContext(Dispatchers.IO) { VaultSession.import(repo, preview.items) }; message = UiText.get(R.string.ui_189) }
                        catch (_: Exception) { message = UiText.get(R.string.ui_190) }
                        finally { busy = false; managerPreview = null }
                    }
                }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_1)) } },
                dismissButton = { TextButton(onClick = { managerPreview = null }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_2)) } })
        }
        if (busy) {
            Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 98.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_3))
                }
            }
        }
        SnackbarHost(snackbar, modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp, vertical = 90.dp))

    }
}

@Composable private fun ItemEditor(item: VaultItem, busy: Boolean = false, onDismiss: () -> Unit, onSave: (VaultItem) -> Unit,
    onDelete: (() -> Unit)? = null, onExportDocument: ((VaultItem) -> Unit)? = null,
    onShareAddress: ((VaultItem) -> Unit)? = null, onViewDocument: ((VaultItem) -> Unit)? = null, onScanTotp: ((VaultItem) -> Unit)? = null) {
    var title by remember(item.id) { mutableStateOf(item.title) }
    var website by remember(item.id) { mutableStateOf(item.site) }
    var username by remember(item.id) { mutableStateOf(item.username) }
    var secret by remember(item.id) { mutableStateOf(item.secret) }
    var notes by remember(item.id) { mutableStateOf(item.notes) }
    var category by remember(item.id) { mutableStateOf(item.category) }
    var favorite by remember(item.id) { mutableStateOf(item.favorite) }
    var expiryDate by remember(item.id) { mutableStateOf(item.expiryDate) }
    var revealHistory by remember(item.id) { mutableStateOf(false) }
    var totp by remember(item.id, item.totpSecret) { mutableStateOf(item.totpSecret) }
    var fields by remember(item.id) { mutableStateOf(item.customFields) }
    var linkedApps by remember(item.id) { mutableStateOf(item.linkedApps) }
    var signatures by remember(item.id) { mutableStateOf(item.appSignatures) }
    var appPicker by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf("") }
    val editorContext = LocalContext.current
    var visible by remember { mutableStateOf(false) }
    var confirmAddressShare by remember(item.id) { mutableStateOf(false) }
    if (appPicker) {
        val apps = remember { AppIdentity.installed(editorContext) }
        AlertDialog(onDismissRequest = { appPicker = false }, title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_5)) },
            text = { Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                Text(androidx.compose.ui.res.stringResource(R.string.ui_6))
                apps.forEach { app -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(app.packageName in linkedApps, { checked ->
                        linkedApps = if (checked) linkedApps + app.packageName else linkedApps - app.packageName
                        signatures = if (checked) signatures + (app.packageName to app.signature) else signatures - app.packageName
                    }); Column { Text(app.label); Text(app.packageName, style = MaterialTheme.typography.labelSmall) }
                } }
            } }, confirmButton = { TextButton(onClick = { appPicker = false }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_7)) } })
    }
    if (confirmAddressShare && onShareAddress != null) {
        AlertDialog(onDismissRequest = { confirmAddressShare = false },
            title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_8)) },
            text = { Text(androidx.compose.ui.res.stringResource(R.string.ui_9)) },
            confirmButton = { Button(onClick = { confirmAddressShare = false; onShareAddress(item) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_10)) } },
            dismissButton = { TextButton(onClick = { confirmAddressShare = false }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_2)) } })
    }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(if (item.title.isBlank()) UiText.get(R.string.ui_235, (item.type)) else UiText.get(R.string.ui_236, (item.type))) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_11)) }, singleLine = true)
                if (item.type == TYPE_PASSWORD || item.type == TYPE_AUTHENTICATOR) {
                    if (item.type == TYPE_PASSWORD) {
                    OutlinedTextField(website, { website = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_12)) }, singleLine = true)
                    OutlinedTextField(username, { username = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_13)) }, singleLine = true)
                    OutlinedTextField(secret, { secret = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_14)) },
                        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = { IconButton(onClick = { visible = !visible }) { Icon(Icons.Default.Visibility, androidx.compose.ui.res.stringResource(R.string.ui_60)) } })
                    TextButton(onClick = { secret = PasswordStudio.password(PasswordOptions()) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_15)) }
                    }
                    OutlinedTextField(totp, { totp = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_16)) }, visualTransformation = PasswordVisualTransformation())
                    if (onScanTotp != null) TextButton(onClick = {
                        onScanTotp(item.copy(title = title, site = website, username = username, secret = secret,
                            notes = notes, category = category, favorite = favorite, expiryDate = expiryDate,
                            totpSecret = totp, customFields = fields, linkedApps = linkedApps, appSignatures = signatures))
                    }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_17)) }
                    if (totp.isNotBlank()) TotpCard(totp, editorContext)
                    if (item.type == TYPE_PASSWORD) {
                    TextButton(onClick = { appPicker = true }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_156, (linkedApps.size))) }
                    if (item.history.isNotEmpty()) {
                        Text(androidx.compose.ui.res.stringResource(R.string.ui_157, (item.history.size)))
                        TextButton(onClick = { revealHistory = !revealHistory }) { Text(androidx.compose.ui.res.stringResource(if (revealHistory) R.string.hide_history else R.string.reveal_history)) }
                        item.history.reversed().forEach { entry -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (entry.changedAt == 0L) androidx.compose.ui.res.stringResource(R.string.legacy_history_date) else androidx.compose.ui.res.stringResource(R.string.ui_158, java.time.Instant.ofEpochMilli(entry.changedAt).atZone(java.time.ZoneId.systemDefault()).toLocalDate()))
                                Text(if (revealHistory) entry.password else "••••••••")
                            }
                            TextButton(onClick = { secret = entry.password }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_18)) }
                        } }
                    }
                    }
                } else if (item.type != TYPE_NOTE && item.type != TYPE_DOCUMENT) {
                    OutlinedTextField(username, { username = it }, label = { Text(if (item.type == TYPE_ADDRESS) UiText.get(R.string.ui_237) else if (item.type == TYPE_IDENTITY) UiText.get(R.string.ui_238) else UiText.get(R.string.ui_239)) })
                    OutlinedTextField(website, { website = it }, label = { Text(if (item.type == TYPE_ADDRESS) UiText.get(R.string.ui_240) else if (item.type == TYPE_IDENTITY) UiText.get(R.string.ui_241) else UiText.get(R.string.ui_242)) })
                    OutlinedTextField(secret, { secret = it }, label = { Text(if (item.type == TYPE_ADDRESS) UiText.get(R.string.ui_243) else UiText.get(R.string.ui_244)) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = favorite, onCheckedChange = { favorite = it })
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_19), style = MaterialTheme.typography.bodyMedium)
                }
                if (item.type in setOf(TYPE_DOCUMENT, TYPE_IDENTITY, TYPE_TICKET, TYPE_TRAVEL,
                        TYPE_VEHICLE, TYPE_FINANCE, TYPE_MEMBERSHIP)) {
                    OutlinedTextField(expiryDate, { expiryDate = it.take(10) },
                        label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_20)) }, singleLine = true)
                }
                if (item.type != TYPE_DOCUMENT) {
                    OutlinedTextField(category, { category = it.take(60) }, label = { Text(androidx.compose.ui.res.stringResource(R.string.organization_category)) }, singleLine = true)
                }
                if (item.type == TYPE_DOCUMENT) {
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_21), style = MaterialTheme.typography.labelMedium)
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        items(documentCategories.filter { it != "All" }) { candidate ->
                            FilterChip(selected = category == candidate, onClick = { category = candidate },
                                label = { Text(candidate) })
                        }
                    }
                }
                if (item.type != TYPE_DOCUMENT) {
                    OutlinedTextField(notes, { notes = it }, label = { Text(if (item.type == TYPE_ADDRESS) UiText.get(R.string.ui_245) else UiText.get(R.string.ui_246)) },
                        minLines = 2)
                } else {
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_22))
                    if (onViewDocument != null) OutlinedButton(onClick = { onViewDocument(item) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_23)) }
                    if (onExportDocument != null) OutlinedButton(onClick = { onExportDocument(item) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_24)) }
                }
                if (onShareAddress != null && item.type == TYPE_ADDRESS && item.title.isNotBlank()) {
                    OutlinedButton(onClick = { confirmAddressShare = true }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_25)) }
                }
                Text(androidx.compose.ui.res.stringResource(R.string.ui_26))
                fields.forEachIndexed { index, field ->
                    OutlinedTextField(field.label, { value -> fields = fields.mapIndexed { i, f -> if (i == index) f.copy(label = value) else f } }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_27)) })
                    OutlinedTextField(field.value, { value -> fields = fields.mapIndexed { i, f -> if (i == index) f.copy(value = value) else f } },
                        label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_28)) }, visualTransformation = if (field.isSecured) PasswordVisualTransformation() else VisualTransformation.None)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(field.isSecured, { value -> fields = fields.mapIndexed { i, f -> if (i == index) f.copy(isSecured = value) else f } }); Text(androidx.compose.ui.res.stringResource(R.string.ui_29))
                        TextButton(onClick = { fields = fields.filterNot { it.id == field.id } }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_30)) }
                        TextButton(onClick = { SensitiveClipboard.copy(editorContext, field.value) }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_31)) }
                    }
                }
                if (fields.size < 100) TextButton(onClick = { fields = fields + CustomField() }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_32)) }
                if (formError.isNotEmpty()) Text(formError, color = MaterialTheme.colorScheme.error)
                if (onDelete != null) TextButton(onClick = onDelete) { Text(androidx.compose.ui.res.stringResource(R.string.ui_33), color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (totp.isNotBlank() && runCatching { TotpGenerator.parse(totp) }.isFailure) formError = UiText.get(R.string.ui_192)
                else onSave(item.copy(title = title.trim(), site = website.trim(),
                username = username, secret = secret, notes = notes, category = category.trim().ifBlank { "General" },
                favorite = favorite, expiryDate = expiryDate.trim(), totpSecret = totp.trim(), customFields = fields, linkedApps = linkedApps.distinct(), appSignatures = signatures)) }, enabled = title.isNotBlank() && !busy) { Text(androidx.compose.ui.res.stringResource(if (busy) R.string.ui_3 else R.string.ui_34)) }
        }, dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text(androidx.compose.ui.res.stringResource(R.string.ui_2)) } }
    )
}

@Composable private fun GeneratorPage(context: Context) { AdvancedPasswordStudio(context) }

@Composable private fun SettingsPage(activity: MainActivity, quick: DeviceUnlock, repo: VaultRepository,
    onNotice: (String) -> Unit, onExport: (String) -> Unit, importPassword: String,
    onImportPassword: (String) -> Unit, selectedBackup: Boolean,
    onImport: () -> Unit, onRestore: () -> Unit, onCsvImport: () -> Unit, onRotateRecovery: () -> Unit,
    onChangePassword: (String) -> Unit, busy: Boolean, onAuthenticator: () -> Unit, onDuplicates: () -> Unit, onAccess: () -> Unit,
    onQuestionSetup: (String, String) -> Unit, onQuestionDisable: () -> Unit) {
    var changePass by remember { mutableStateOf("") }
    var confirmChangePass by remember { mutableStateOf("") }
    var exportPass by remember { mutableStateOf("") }
    var legalText by remember { mutableStateOf<String?>(null) }
    val secrets = VaultSession.activeItems.filter { it.type == TYPE_PASSWORD }
    val health = PasswordHealth.analyze(secrets.map {
        PasswordHealthInput(it.id, it.site, it.username, it.secret)
    })
    val weakCount = health.weak
    val reusedCount = health.reused
    val legalContext = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text(androidx.compose.ui.res.stringResource(R.string.ui_35), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(androidx.compose.ui.res.stringResource(R.string.ui_36), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(androidx.compose.ui.res.stringResource(R.string.ui_159, (health.total), (weakCount), (reusedCount), (health.duplicateAccounts)),
                    color = if (weakCount + reusedCount > 0) Color(0xFFFFD19C) else teal,
                    style = MaterialTheme.typography.bodySmall)
            }
        }
        var deviceEnabled by remember { mutableStateOf(repo.hasDeviceUnlock()) }
        DisposableEffect(activity, repo) {
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event -> if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) deviceEnabled = repo.hasDeviceUnlock() }
            activity.lifecycle.addObserver(observer)
            onDispose { activity.lifecycle.removeObserver(observer) }
        }
        SecurityTile(UiText.get(R.string.ui_247), UiText.get(R.string.ui_248),
            if (deviceEnabled) UiText.get(R.string.ui_249) else UiText.get(R.string.ui_250)) {
            if (repo.hasDeviceUnlock()) {
                try { quick.disable(); deviceEnabled = repo.hasDeviceUnlock(); onNotice(UiText.get(R.string.ui_193)) }
                catch (_: Exception) { onNotice(UiText.get(R.string.ui_194)) }
            } else quick.enable(activity) { _, info -> deviceEnabled = repo.hasDeviceUnlock(); onNotice(info) }
        }
        Text(if (deviceEnabled) UiText.get(R.string.device_enabled) else UiText.get(R.string.device_disabled))
        if (!deviceEnabled) {
            OutlinedButton(onClick = { quick.enable(activity, UnlockMethod.BIOMETRIC) { _, info -> deviceEnabled = repo.hasDeviceUnlock(); onNotice(info) } }) { Text(UiText.get(R.string.device_biometric_enable)) }
            if (Build.VERSION.SDK_INT >= 30) OutlinedButton(onClick = { quick.enable(activity, UnlockMethod.SCREEN_LOCK) { _, info -> deviceEnabled = repo.hasDeviceUnlock(); onNotice(info) } }) { Text(UiText.get(R.string.device_screen_enable)) }
        }
        var autofillEnabled by remember { mutableStateOf(AutofillReadiness.selected(activity)) }
        DisposableEffect(activity) {
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) autofillEnabled = AutofillReadiness.selected(activity)
            }
            activity.lifecycle.addObserver(observer)
            onDispose { activity.lifecycle.removeObserver(observer) }
        }
        val autofillStatus = if (autofillEnabled) UiText.get(R.string.autofill_active) else UiText.get(R.string.ui_319)
        SecurityTile(UiText.get(R.string.ui_251), autofillStatus, if (autofillEnabled) UiText.get(R.string.manage_autofill) else UiText.get(R.string.ui_252)) {
            try { AutofillReadiness.open(activity) } catch (_: Exception) { onNotice(UiText.get(R.string.ui_195)) }
        }
        OutlinedButton(onClick = onAccess) { Text(UiText.get(R.string.open_access_settings)) }
        Text(UiText.get(R.string.autofill_details), style = MaterialTheme.typography.bodySmall)
        Text(UiText.get(R.string.autofill_epfo), style = MaterialTheme.typography.bodySmall)
        Text(androidx.compose.ui.res.stringResource(R.string.ui_37))
        Text(androidx.compose.ui.res.stringResource(R.string.ui_38))
        OutlinedButton(onClick = onAuthenticator) { Text(androidx.compose.ui.res.stringResource(R.string.authenticator)) }
        OutlinedButton(onClick = onDuplicates) { Text(androidx.compose.ui.res.stringResource(R.string.review_duplicates)) }
        UpgradeSettings(activity, repo, onNotice)
        Text(androidx.compose.ui.res.stringResource(R.string.ui_39), style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(exportPass, { exportPass = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_40)) },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button(onClick = { onExport(exportPass); exportPass = "" }, enabled = exportPass.length >= 12,
            modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(R.string.ui_41)) }
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(R.string.ui_42)) }
        if (selectedBackup) {
            OutlinedTextField(importPassword, onImportPassword, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_43)) },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button(onClick = onRestore, enabled = importPassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text(androidx.compose.ui.res.stringResource(R.string.ui_44))
            }
        }
        Text(androidx.compose.ui.res.stringResource(R.string.ui_45), style = MaterialTheme.typography.titleMedium)
        OutlinedButton(onClick = onCsvImport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text(androidx.compose.ui.res.stringResource(R.string.ui_46))
        }
        Text(androidx.compose.ui.res.stringResource(R.string.ui_47),
            style = MaterialTheme.typography.bodySmall, color = subtle)
        Text(androidx.compose.ui.res.stringResource(R.string.ui_48), style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(changePass, { changePass = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_49)) },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(confirmChangePass, { confirmChangePass = it }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_50)) },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { onChangePassword(changePass); changePass = ""; confirmChangePass = "" },
            enabled = !busy && changePass.length >= 12 && changePass == confirmChangePass) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_51))
        }
        QuestionRecoverySettings(repo.recoveryQuestion() != null, busy, onQuestionSetup, onQuestionDisable)
        OutlinedButton(onClick = onRotateRecovery, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_52))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                legalText = legalContext.resources.openRawResource(R.raw.privacy_policy).bufferedReader().use { it.readText() }
            }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_53)) }
            OutlinedButton(onClick = {
                legalText = legalContext.resources.openRawResource(R.raw.terms_of_use).bufferedReader().use { it.readText() }
            }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_54)) }
        }
        Text(androidx.compose.ui.res.stringResource(R.string.ui_55), style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html")))
            } catch (_: Exception) { onNotice(UiText.get(R.string.ui_196)) }
        }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_56)) }
        Text(androidx.compose.ui.res.stringResource(R.string.ui_57) +
            "Brief app switches keep your unlocked session for at most 30 seconds. Screen-off and manual lock clear it immediately. Biometric/device quick unlock is optional. Use your master password, main recovery key, or optional question plus separate rescue code. Password resets disable device unlock; set it up again afterward.\n\n" +
            "Strong biometric capability depends on device hardware. Some face unlock implementations are not eligible.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
    if (legalText != null) AlertDialog(
        onDismissRequest = { legalText = null }, title = { Text(androidx.compose.ui.res.stringResource(R.string.ui_58)) },
        text = { Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) { Text(legalText ?: "") } },
        confirmButton = { TextButton(onClick = { legalText = null }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_59)) } }
    )

}

@Composable private fun SecurityTile(title: String, desc: String, action: String, onClick: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onClick) { Text(action) }
        }
    }
}
