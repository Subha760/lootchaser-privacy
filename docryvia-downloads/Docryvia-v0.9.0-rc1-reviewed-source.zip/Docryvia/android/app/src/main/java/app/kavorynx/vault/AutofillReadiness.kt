package app.kavorynx.vault

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.autofill.AutofillManager

internal object AutofillReadiness {
    fun matchesComponent(value: String?, packageName: String): Boolean? =
        value?.takeIf { it.isNotBlank() }?.let {
            ComponentName.unflattenFromString(it)?.let { component ->
                component.packageName == packageName && component.className == "app.kavorynx.vault.SenviyaAutofillService"
            } ?: false
        }
    fun selected(context: Context): Boolean {
        val setting = runCatching { Settings.Secure.getString(context.contentResolver, "autofill_service") }.getOrNull()
        return matchesComponent(setting, context.packageName)
            ?: (runCatching { context.getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true }.getOrDefault(false))
    }
    fun open(context: Context) {
        val request = android.content.Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE).apply {
            data = android.net.Uri.parse("package:${context.packageName}")
        }
        try { context.startActivity(request) }
        catch (_: Exception) { context.startActivity(android.content.Intent(Settings.ACTION_SETTINGS)) }
    }
}
