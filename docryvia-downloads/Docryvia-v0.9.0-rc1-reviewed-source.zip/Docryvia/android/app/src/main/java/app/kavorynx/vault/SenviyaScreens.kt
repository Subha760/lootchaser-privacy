package app.kavorynx.vault

import androidx.compose.ui.text.input.PasswordVisualTransformation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** This theme is intentionally independent of DigiLocker, UMANG and Google Wallet branding. */
internal val ink: Color @Composable get() = MaterialTheme.colorScheme.onSurface
internal val ocean: Color @Composable get() = MaterialTheme.colorScheme.primary
internal val teal: Color @Composable get() = MaterialTheme.colorScheme.secondary
internal val soft: Color @Composable get() = MaterialTheme.colorScheme.background
internal val subtle: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant
internal val outline: Color @Composable get() = MaterialTheme.colorScheme.outline

@Composable
fun SenviyaTheme(content: @Composable () -> Unit) {
    val scheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme(
        primary = Color(0xFF9CC7FF), secondary = Color(0xFF77DACC),
        surface = Color(0xFF12161A), background = Color(0xFF12161A),
        surfaceVariant = Color(0xFF1A222B), onSurface = Color(0xFFE5EAF0),
        onBackground = Color(0xFFE5EAF0), onSurfaceVariant = Color(0xFFB8C5D4)
    ) else lightColorScheme(
        primary = Color(0xFF1766C5), onPrimary = Color.White, secondary = Color(0xFF0B887D),
        surface = Color.White, onSurface = Color(0xFF142940), background = Color(0xFFF4F7FB),
        onBackground = Color(0xFF142940), surfaceVariant = Color(0xFFEAF1F8),
        onSurfaceVariant = Color(0xFF65788D), outline = Color(0xFFE3EAF1), error = Color(0xFFAF3939))
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}

private data class IntroPage(val icon: ImageVector, val title: String, val description: String, val foot: String)
private val introSlides get() = listOf(
    IntroPage(Icons.Outlined.Shield, UiText.get(R.string.ui_267), UiText.get(R.string.ui_268), UiText.get(R.string.ui_269)),
    IntroPage(Icons.Outlined.Fingerprint, UiText.get(R.string.ui_270), UiText.get(R.string.ui_271), UiText.get(R.string.ui_272)),
    IntroPage(Icons.Outlined.AutoAwesome, UiText.get(R.string.ui_273), UiText.get(R.string.ui_274), UiText.get(R.string.ui_275)),
    IntroPage(Icons.Outlined.Folder, UiText.get(R.string.ui_276), UiText.get(R.string.ui_277), UiText.get(R.string.ui_278)),
    IntroPage(Icons.Outlined.Backup, UiText.get(R.string.ui_279), UiText.get(R.string.ui_280), UiText.get(R.string.ui_281))
)

@Composable
fun SenviyaIntro(onDone: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    val slide = introSlides[index]
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).padding(horizontal = 27.dp, vertical = 26.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BrandMark()
            Spacer(Modifier.width(11.dp))
            Column {
                Text(androidx.compose.ui.res.stringResource(R.string.ui_61), fontSize = 23.sp, fontWeight = FontWeight.Bold, color = ink)
                Text(androidx.compose.ui.res.stringResource(R.string.ui_62), style = MaterialTheme.typography.labelMedium, color = subtle)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onDone) { Text(androidx.compose.ui.res.stringResource(R.string.ui_63)) }
        }
        Spacer(Modifier.weight(.7f))
        Box(Modifier.fillMaxWidth().height(245.dp), contentAlignment = Alignment.Center) {
            Surface(Modifier.size(215.dp), shape = RoundedCornerShape(54.dp),
                color = MaterialTheme.colorScheme.surfaceVariant, border = BorderStroke(1.dp, Color(0xFFDAE8F5))) {
                Box(contentAlignment = Alignment.Center) {
                    Surface(shape = RoundedCornerShape(39.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 9.dp) {
                        Icon(slide.icon, null, Modifier.padding(35.dp).size(90.dp), tint = ocean)
                    }
                }
            }
        }
        Spacer(Modifier.weight(.5f))
        AnimatedContent(targetState = slide, transitionSpec = {
            androidx.compose.animation.fadeIn(tween(220)) togetherWith androidx.compose.animation.fadeOut(tween(160))
        }, label = "intro") { it ->
            Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text(it.foot, style = MaterialTheme.typography.labelMedium, color = teal, fontWeight = FontWeight.Bold)
                Text(it.title, fontSize = 29.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, color = ink)
                Text(it.description, fontSize = 16.sp, lineHeight = 25.sp, color = subtle)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                repeat(introSlides.size) { i ->
                    Box(Modifier.width(if (i == index) 23.dp else 7.dp).height(7.dp)
                        .clip(CircleShape).background(if (i == index) ocean else outline))
                }
            }
            Spacer(Modifier.weight(1f))
            Button(onClick = { if (index == introSlides.lastIndex) onDone() else index++ },
                shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 25.dp, vertical = 15.dp)) {
                Text(if (index == introSlides.lastIndex) UiText.get(R.string.ui_253) else UiText.get(R.string.ui_254))
                Spacer(Modifier.width(9.dp)); Icon(Icons.Default.ArrowForward, null, Modifier.size(17.dp))
            }
        }
    }
}

@Composable
fun BrandMark() {
    Surface(shape = RoundedCornerShape(14.dp), color = ocean, modifier = Modifier.size(45.dp)) {
        Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Shield, androidx.compose.ui.res.stringResource(R.string.ui_109), tint = Color.White, modifier = Modifier.size(27.dp)) }
    }
}

@Composable
fun SenviyaTopBar(count: Int, onLock: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        BrandMark(); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_61), style = MaterialTheme.typography.titleLarge, color = ink)
            Text(androidx.compose.ui.res.stringResource(R.string.ui_62), style = MaterialTheme.typography.labelMedium, color = subtle)
        }
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_64), color = teal, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
        }
        IconButton(onClick = onLock) { Icon(Icons.Outlined.Lock, androidx.compose.ui.res.stringResource(R.string.ui_110), tint = ink) }
    }
}

private data class QuickCategory(val title: String, val detail: String, val icon: ImageVector, val tint: Color, val type: String)
private val categories = listOf(
    QuickCategory(UiText.get(R.string.ui_282), UiText.get(R.string.ui_283), Icons.Outlined.Key, Color(0xFF2366C4), TYPE_PASSWORD),
    QuickCategory(UiText.get(R.string.ui_284), UiText.get(R.string.ui_285), Icons.Outlined.Description, Color(0xFF0D8B7D), TYPE_DOCUMENT),
    QuickCategory(UiText.get(R.string.ui_286), UiText.get(R.string.ui_287), Icons.Outlined.LocationOn, Color(0xFF985A3E), TYPE_ADDRESS),
    QuickCategory(UiText.get(R.string.ui_288), UiText.get(R.string.ui_289), Icons.Outlined.FlightTakeoff, Color(0xFF6E52BB), TYPE_TICKET),
    QuickCategory(UiText.get(R.string.ui_290), UiText.get(R.string.ui_291), Icons.Outlined.Badge, Color(0xFFAF6450), TYPE_IDENTITY),
    QuickCategory(UiText.get(R.string.ui_246), UiText.get(R.string.ui_292), Icons.Outlined.EditNote, Color(0xFF188091), TYPE_NOTE)
)

@Composable
private fun SectionHeading(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth()) {
        Text(title, color = ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = subtle, modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
private fun InfoTile(icon: ImageVector, title: String, sub: String, accent: Color, modifier: Modifier = Modifier,
    onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, outline)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = accent.copy(alpha = .09f)) {
                Icon(icon, null, Modifier.padding(10.dp).size(23.dp), tint = accent)
            }
            Text(title, maxLines = 1, color = ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(sub, fontSize = 11.sp, color = subtle, maxLines = 1)
        }
    }
}

@Composable
fun SenviyaHome(entries: List<VaultItem>, onGo: (String) -> Unit, onAdd: (String) -> Unit, onPickDocument: () -> Unit) {
    val docCount = entries.count { it.type == TYPE_DOCUMENT }
    val passCount = entries.count { it.type == TYPE_PASSWORD }
    val favoriteCount = entries.count { it.favorite }
    val expiringCount = entries.count { ExpiryPolicy.status(it.expiryDate) == ExpiryState.UPCOMING }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 26.dp)) {
        item {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_65), fontSize = 14.sp, color = subtle)
            Text(androidx.compose.ui.res.stringResource(R.string.ui_66), fontSize = 27.sp, fontWeight = FontWeight.Bold, color = ink)
        }
        item {
            Surface(shape = RoundedCornerShape(25.dp), color = Color(0xFF142940)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.VerifiedUser, null, tint = Color(0xFF96DAD8))
                        Spacer(Modifier.width(9.dp))
                        Text(androidx.compose.ui.res.stringResource(R.string.ui_67), fontWeight = FontWeight.Medium, color = Color.White)
                    }
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_68), fontSize = 22.sp, lineHeight = 28.sp,
                        fontWeight = FontWeight.SemiBold, color = Color.White)
                    HorizontalDivider(color = Color.White.copy(alpha = .16f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(androidx.compose.ui.res.stringResource(R.string.ui_197, (passCount)), color = Color.White.copy(alpha = .87f))
                        Spacer(Modifier.width(18.dp))
                        Text(androidx.compose.ui.res.stringResource(R.string.ui_198, (docCount)), color = Color.White.copy(alpha = .87f))
                    }
                }
            }
        }
        if (expiringCount > 0 || favoriteCount > 0) item {
            Surface(shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, Color(0xFFF0E4CC)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.EventAvailable, androidx.compose.ui.res.stringResource(R.string.ui_111), tint = Color(0xFF9B621F))
                    Spacer(Modifier.width(12.dp))
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_199, (expiringCount), (favoriteCount)),
                        color = ink, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item { SectionHeading(UiText.get(R.string.ui_295), UiText.get(R.string.ui_296)) }
        items(categories.chunked(2)) { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { item ->
                    InfoTile(item.icon, item.title, item.detail, item.tint, Modifier.weight(1f)) {
                        when (item.type) {
                            TYPE_PASSWORD -> onGo("Passwords")
                            TYPE_DOCUMENT -> onGo("Documents")
                            TYPE_NOTE, TYPE_ADDRESS, TYPE_TICKET, TYPE_IDENTITY -> { onGo("Wallet"); onAdd(item.type) }
                            else -> onGo("Wallet")
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item { SectionHeading(UiText.get(R.string.ui_297)) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { onAdd(TYPE_PASSWORD) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text(androidx.compose.ui.res.stringResource(R.string.ui_69))
                }
                OutlinedButton(onClick = onPickDocument, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Outlined.UploadFile, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(androidx.compose.ui.res.stringResource(R.string.ui_70))
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Info, null, tint = subtle, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(androidx.compose.ui.res.stringResource(R.string.ui_71), fontSize = 11.sp, color = subtle)
            }
        }
    }
}

@Composable
fun SenviyaEntryCard(item: VaultItem, onSelect: () -> Unit) {
    val (icon, color) = when (item.type) {
        TYPE_PASSWORD -> Icons.Outlined.Language to ocean
        TYPE_DOCUMENT -> Icons.Outlined.InsertDriveFile to teal
        TYPE_TICKET, TYPE_TRAVEL -> Icons.Outlined.ConfirmationNumber to Color(0xFF7655AE)
        TYPE_ADDRESS -> Icons.Outlined.LocationOn to Color(0xFF9C6543)
        TYPE_IDENTITY -> Icons.Outlined.Badge to Color(0xFFBA6452)
        TYPE_NOTE -> Icons.Outlined.EditNote to Color(0xFF218B9F)
        else -> Icons.Outlined.Folder to ocean
    }
    Surface(onClick = onSelect, shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, outline), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(13.dp), color = color.copy(alpha = .09f)) {
                Icon(icon, null, Modifier.padding(11.dp).size(23.dp), tint = color)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title.ifBlank { "Untitled ${item.type.lowercase()}" }, color = ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text((if (item.type == TYPE_DOCUMENT) item.category else item.username.ifBlank { item.site.ifBlank { item.type } }),
                    fontSize = 12.sp, color = subtle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (item.expiryDate.isNotBlank()) {
                    val status = ExpiryPolicy.status(item.expiryDate)
                    Text(when (status) {
                        ExpiryState.EXPIRED -> "Expired · ${item.expiryDate}"
                        ExpiryState.UPCOMING -> "Due soon · ${item.expiryDate}"
                        ExpiryState.VALID -> "Expires · ${item.expiryDate}"
                        ExpiryState.NONE -> "Expiry not available"
                    }, fontSize = 11.sp,
                        color = if (status == ExpiryState.EXPIRED || status == ExpiryState.UPCOMING)
                            Color(0xFFA8662A) else subtle)
                }
                if (item.type == TYPE_PASSWORD && item.totpSecret.isNotBlank()) {
                    TotpCard(item.totpSecret, androidx.compose.ui.platform.LocalContext.current)
                }
            }
            if (item.favorite) {
                Icon(Icons.Filled.Star, androidx.compose.ui.res.stringResource(R.string.ui_112), tint = Color(0xFFC89127), modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(6.dp))
            }
            Icon(Icons.Default.ChevronRight, null, tint = subtle, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
fun SenviyaPasswords(entries: List<VaultItem>, onSelect: (VaultItem) -> Unit, onAdd: () -> Unit, onGenerator: () -> Unit, onDuplicates: () -> Unit) {
    var filter by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<String?>(null) }; var favorites by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf(VaultSort.TITLE) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp), modifier = Modifier.fillMaxSize()) {
        item { SectionHeading(UiText.get(R.string.ui_298), UiText.get(R.string.ui_299)) }
        item {
            val passwords = entries.filter { it.type == TYPE_PASSWORD }
            val health = remember(passwords) {
                PasswordHealth.analyze(passwords.map { PasswordHealthInput(it.id, it.site, it.username, it.secret) })
            }
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, Color(0xFFD6E8E0)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.VerifiedUser, null, tint = teal, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(androidx.compose.ui.res.stringResource(R.string.ui_72), color = ink, fontWeight = FontWeight.SemiBold)
                    }
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_200, (health.total), (health.weak), (health.reused), (health.duplicateAccounts)),
                        fontSize = 12.sp, lineHeight = 18.sp, color = ink)
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_73), fontSize = 11.sp, color = subtle)
                }
            }
        }
        item { SearchField(filter, { filter = it }) }
        item { OrganizationControls(entries.filter { it.type == TYPE_PASSWORD }, category, { category = it }, favorites, { favorites = it }, sort, { sort = it }) }
        item { OutlinedButton(onClick = onDuplicates) { Text(androidx.compose.ui.res.stringResource(R.string.review_duplicates)) } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onAdd, shape = RoundedCornerShape(15.dp)) { Icon(Icons.Default.Add, null); Text(androidx.compose.ui.res.stringResource(R.string.ui_74)) }
                OutlinedButton(onClick = onGenerator, shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text(androidx.compose.ui.res.stringResource(R.string.ui_75))
                }
            }
        }
        val shown = VaultOrganization.select(entries.filter { it.type == TYPE_PASSWORD }, filter, category, favorites, sort)
        if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Key, UiText.get(R.string.ui_304), UiText.get(R.string.ui_305)) }
        items(shown, key = { it.id }) { item -> SenviyaEntryCard(item) { onSelect(item) } }
    }
}

@Composable
private fun SearchField(value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(androidx.compose.ui.res.stringResource(R.string.ui_76), color = subtle) },
        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
        shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = outline))
}

val documentCategories = listOf("All", "Identity", "Education", "Health", "Finance", "Insurance", "Vehicle", "Travel", "Property", "Work", "Family", "Other")

@Composable
fun SenviyaDocuments(entries: List<VaultItem>, onSelect: (VaultItem) -> Unit, onPick: (String) -> Unit) {
    var selected by remember { mutableStateOf("All") }
    var filter by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(top = 16.dp)) {
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionHeading(UiText.get(R.string.ui_300), UiText.get(R.string.ui_301))
            SearchField(filter) { filter = it }
            Button(onClick = { onPick(if (selected == "All") "Other" else selected) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text(androidx.compose.ui.res.stringResource(R.string.ui_77))
            }
            Text(androidx.compose.ui.res.stringResource(R.string.ui_78), color = subtle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(9.dp))
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(documentCategories) { category ->
                FilterChip(selected = selected == category, onClick = { selected = category },
                    label = { Text(category) }, shape = RoundedCornerShape(12.dp))
            }
        }
        val shown = entries.filter { it.type == TYPE_DOCUMENT && (selected == "All" || it.category.equals(selected, true)) &&
            VaultOrganization.select(listOf(it), filter).isNotEmpty() }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 15.dp)) {
            item { Text(androidx.compose.ui.res.stringResource(R.string.ui_201, (shown.size), (if (shown.size == 1) "" else "s")), fontSize = 12.sp, color = subtle) }
            if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Description, UiText.get(R.string.ui_306, (selected.lowercase())), UiText.get(R.string.ui_307)) }
            items(shown, key = { it.id }) { item -> SenviyaEntryCard(item) { onSelect(item) } }
        }
    }
}

@Composable
fun SenviyaWallet(entries: List<VaultItem>, onSelect: (VaultItem) -> Unit, onAdd: (String) -> Unit) {
    var selected by remember { mutableStateOf("All") }
    val types = listOf("All", TYPE_ADDRESS, TYPE_IDENTITY, TYPE_TICKET, TYPE_TRAVEL, TYPE_NOTE, TYPE_MEMBERSHIP, TYPE_FINANCE, TYPE_HEALTH, TYPE_VEHICLE)
    Column(Modifier.fillMaxSize().padding(top = 16.dp)) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            SectionHeading(UiText.get(R.string.ui_302), UiText.get(R.string.ui_303))
            Spacer(Modifier.height(13.dp))
            Text(androidx.compose.ui.res.stringResource(R.string.ui_79), color = subtle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            items(types.filter { it != "All" }) { type ->
                AssistChip(onClick = { onAdd(type) }, label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_202, (type))) }, shape = RoundedCornerShape(12.dp))
            }
        }
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(types) { type -> FilterChip(selected = selected == type, onClick = { selected = type },
                label = { Text(type) }, shape = RoundedCornerShape(10.dp)) }
        }
        val shown = entries.filter { it.type != TYPE_PASSWORD && it.type != TYPE_DOCUMENT && (selected == "All" || it.type == selected) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
            if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Wallet, UiText.get(R.string.ui_308), UiText.get(R.string.ui_309)) }
            items(shown, key = { it.id }) { item -> SenviyaEntryCard(item) { onSelect(item) } }
        }
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, desc: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 45.dp, horizontal = 25.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(23.dp)) {
            Icon(icon, null, Modifier.padding(21.dp).size(34.dp), tint = ocean)
        }
        Text(title, color = ink, fontWeight = FontWeight.SemiBold)
        Text(desc, fontSize = 13.sp, color = subtle, lineHeight = 20.sp)
    }
}

@Composable
fun SenviyaBottomBar(page: String, onPage: (String) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
        listOf("Home", "Passwords", "Documents", "Wallet", "Settings").forEach { section ->
            val icon = when (section) {
                "Home" -> Icons.Outlined.Home
                "Passwords" -> Icons.Outlined.Key
                "Documents" -> Icons.Outlined.Folder
                "Wallet" -> Icons.Outlined.Wallet
                else -> Icons.Outlined.Settings
            }
            NavigationBarItem(selected = page == section, onClick = { onPage(section) },
                icon = { Icon(icon, section, modifier = Modifier.size(23.dp)) },
                label = { Text(section, fontSize = 10.sp, maxLines = 1) }, alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(selectedIconColor = ocean, indicatorColor = Color(0xFFE6F0FC),
                    selectedTextColor = ocean, unselectedIconColor = subtle, unselectedTextColor = subtle))
        }
    }
}

@Composable
fun SenviyaSetup(busy: Boolean, privacyEvent: Int, onCreate: (String, String, String, Boolean) -> Unit) {
    var question by remember { mutableStateOf("school") }
    var answer by remember { mutableStateOf("") }
    var confirmAnswer by remember { mutableStateOf("") }
    var enableDevice by remember { mutableStateOf(false) }
    var master by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(privacyEvent) { if (privacyEvent > 0) { master = ""; confirm = ""; answer = ""; confirmAnswer = "" } }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).verticalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(horizontal = 25.dp, vertical = 34.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BrandMark(); Spacer(Modifier.width(10.dp))
            Text(androidx.compose.ui.res.stringResource(R.string.ui_61), fontSize = 24.sp, color = ink, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, null, tint = ocean, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(14.dp))
                Text(androidx.compose.ui.res.stringResource(R.string.ui_80),
                    color = ink, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(androidx.compose.ui.res.stringResource(R.string.ui_81), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ink)
        Text(androidx.compose.ui.res.stringResource(R.string.ui_82), color = subtle)
        OutlinedTextField(master, { master = it }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_83)) }, singleLine = true,
            visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
            shape = RoundedCornerShape(16.dp))
        OutlinedTextField(confirm, { confirm = it }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_84)) }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            shape = RoundedCornerShape(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(show, { show = it }); Text(androidx.compose.ui.res.stringResource(R.string.ui_85), color = ink)
        }
        Surface(shape = RoundedCornerShape(16.dp), color = soft) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_86),
                Modifier.padding(17.dp), color = subtle, style = MaterialTheme.typography.bodyMedium)
        }
        Text(androidx.compose.ui.res.stringResource(R.string.setup_question_required), color = ink, fontWeight = FontWeight.Bold)
        QuestionRecovery.questions.keys.forEach { id ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = question == id, onClick = { question = id }, enabled = !busy)
                Text(UiText.question(id), color = ink)
            }
        }
        OutlinedTextField(answer, { answer = it.take(200) }, modifier = Modifier.fillMaxWidth(), enabled = !busy,
            label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_103)) }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        OutlinedTextField(confirmAnswer, { confirmAnswer = it.take(200) }, modifier = Modifier.fillMaxWidth(), enabled = !busy,
            label = { Text(androidx.compose.ui.res.stringResource(R.string.setup_answer_confirm)) }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        Text(androidx.compose.ui.res.stringResource(R.string.setup_question_help), color = subtle)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(enableDevice, { enableDevice = it }, enabled = !busy)
            Text(androidx.compose.ui.res.stringResource(R.string.setup_device_option), color = ink)
        }
        Text(androidx.compose.ui.res.stringResource(R.string.setup_device_help), color = subtle)
        Spacer(Modifier.height(8.dp))
        val answerChars = answer.toCharArray()
        val answerValid = QuestionRecovery.validAnswer(answerChars)
        answerChars.fill('\u0000')
        Button(enabled = !busy && master.length >= 12 && master == confirm && answerValid && answer == confirmAnswer, onClick = {
            onCreate(master, question, answer, enableDevice)
        }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_87), fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SenviyaRecovery(token: String, questionKit: Boolean = false, onDone: () -> Unit) {
    var acknowledged by remember(token) { mutableStateOf(false) }
    var copied by remember(token) { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).verticalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(26.dp), verticalArrangement = Arrangement.spacedBy(19.dp)) {
        Spacer(Modifier.height(24.dp))
        Icon(Icons.Outlined.Key, null, Modifier.size(49.dp), tint = teal)
        Text(if (questionKit) UiText.get(R.string.ui_255) else UiText.get(R.string.ui_256), fontSize = 27.sp, color = ink, fontWeight = FontWeight.Bold)
        Text(if (questionKit) UiText.get(R.string.ui_257) else UiText.get(R.string.ui_258), color = subtle)
        Surface(shape = RoundedCornerShape(17.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(token, Modifier.fillMaxWidth().padding(19.dp), color = ink, fontWeight = FontWeight.SemiBold)
        }
        OutlinedButton(onClick = { SensitiveClipboard.copy(context, token); copied = true }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.ContentCopy, null); Spacer(Modifier.width(8.dp))
            Text(androidx.compose.ui.res.stringResource(R.string.copy_recovery_key))
        }
        if (copied) Text(androidx.compose.ui.res.stringResource(R.string.recovery_copied), color = teal)
        Text(if (questionKit) UiText.get(R.string.ui_259) else UiText.get(R.string.ui_260), color = MaterialTheme.colorScheme.error)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(acknowledged, { acknowledged = it }); Text(androidx.compose.ui.res.stringResource(R.string.ui_89), color = ink)
        }
        Button(enabled = acknowledged, onClick = onDone, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(15.dp)) {
            Text(androidx.compose.ui.res.stringResource(R.string.ui_94))
        }
    }
}

@Composable
fun SenviyaUnlock(privacyEvent: Int, quickEnabled: Boolean, onMaster: (String) -> Unit,
                  onRecovery: (String, String) -> Unit, onDevice: () -> Unit, onScreenLock: () -> Unit,
                  busy: Boolean = false, questionId: String? = null,
                  onQuestionRecovery: (String, String, String) -> Unit) {
    var password by remember { mutableStateOf("") }
    var recoverMode by remember { mutableStateOf(false) }
    var questionMode by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var recovery by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    LaunchedEffect(privacyEvent) {
        if (privacyEvent > 0) { password = ""; recovery = ""; newPassword = ""; answer = ""; confirmPassword = "" }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).verticalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(40.dp))
        Surface(shape = RoundedCornerShape(32.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(110.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Shield, null, Modifier.size(67.dp), tint = ocean)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(if (recoverMode) UiText.get(R.string.ui_261) else UiText.get(R.string.ui_262), fontSize = 29.sp, color = ink,
            fontWeight = FontWeight.Bold)
        Text(if (recoverMode) UiText.get(R.string.ui_263) else UiText.get(R.string.ui_264), color = subtle)
        Spacer(Modifier.height(25.dp))
        if (!recoverMode) {
            OutlinedTextField(password, { password = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_96)) }, singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                shape = RoundedCornerShape(15.dp))
            Button(onClick = { onMaster(password); password = "" }, enabled = password.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text(androidx.compose.ui.res.stringResource(R.string.ui_97)) }
            if (quickEnabled) {
                OutlinedButton(onClick = onDevice, enabled = !busy, modifier = Modifier.fillMaxWidth().height(51.dp),
                    shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Outlined.Fingerprint, null); Spacer(Modifier.width(9.dp))
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_98))
                }
            }
            if (quickEnabled && android.os.Build.VERSION.SDK_INT >= 30) {
                OutlinedButton(onClick = onScreenLock, enabled = !busy, modifier = Modifier.fillMaxWidth().height(51.dp), shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Outlined.Lock, null); Spacer(Modifier.width(9.dp))
                    Text(androidx.compose.ui.res.stringResource(R.string.screen_lock_option))
                }
            }
            if (!quickEnabled) Text(androidx.compose.ui.res.stringResource(R.string.ui_99), color = subtle)
            TextButton(enabled = !busy, onClick = { recoverMode = true; password = "" }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_100)) }
        } else {
            if (questionId != null) {
                Row {
                    TextButton(enabled = !busy, onClick = { questionMode = false; recovery = ""; answer = "" }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_101)) }
                    TextButton(enabled = !busy, onClick = { questionMode = true; recovery = ""; answer = "" }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_102)) }
                }
            }
            if (questionMode && questionId != null) {
                Text(UiText.question(questionId), color = ink)
                OutlinedTextField(answer, { answer = it.take(200) }, modifier = Modifier.fillMaxWidth(),
                    label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_103)) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                Text(androidx.compose.ui.res.stringResource(R.string.ui_104), color = subtle)
            }
            OutlinedTextField(recovery, { recovery = it }, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                label = { Text(if (questionMode) UiText.get(R.string.ui_265) else UiText.get(R.string.ui_266)) }, shape = RoundedCornerShape(15.dp))
            OutlinedTextField(newPassword, { newPassword = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_105)) },
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                shape = RoundedCornerShape(15.dp))
            OutlinedTextField(confirmPassword, { confirmPassword = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_50)) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation())
            Button(enabled = !busy && recovery.isNotBlank() && newPassword.length >= 12 &&
                newPassword == confirmPassword && (!questionMode || answer.trim().length >= 2),
                onClick = {
                    if (questionMode) onQuestionRecovery(answer, recovery, newPassword)
                    else onRecovery(recovery, newPassword)
                    recovery = ""; newPassword = ""; confirmPassword = ""; answer = ""
                },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text(androidx.compose.ui.res.stringResource(R.string.ui_106)) }
            TextButton(enabled = !busy, onClick = { recoverMode = false; questionMode = false; answer = ""; recovery = ""; newPassword = ""; confirmPassword = "" }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_107)) }
        }
        Spacer(Modifier.height(15.dp))
        Text(androidx.compose.ui.res.stringResource(R.string.ui_108), fontSize = 12.sp, color = subtle)
    }
}
