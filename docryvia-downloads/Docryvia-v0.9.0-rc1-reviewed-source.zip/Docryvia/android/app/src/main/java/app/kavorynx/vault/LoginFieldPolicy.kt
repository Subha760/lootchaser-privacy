package app.kavorynx.vault

import android.text.InputType
import java.util.Locale

internal enum class LoginFieldRole { NONE, USERNAME, PASSWORD }
internal object LoginFieldPolicy {
    private val accountIds = setOf("username", "userid", "loginid", "loginname", "email", "emailaddress", "uan", "memberid", "memberusername")
    fun classify(hints: List<String>, attributes: Map<String, String>, androidId: String?, inputType: Int): LoginFieldRole {
        val html = attributes.mapKeys { it.key.lowercase(Locale.ROOT) }.mapValues { it.value.lowercase(Locale.ROOT) }
        val type = html["type"].orEmpty()
        val completion = html["autocomplete"].orEmpty().split(Regex("\\s+"))
        val identifiers = listOfNotNull(html["name"], html["id"], androidId?.lowercase(Locale.ROOT)).map { it.replace(Regex("[^a-z0-9]"), "") }
        if (type in setOf("hidden", "search", "submit", "button", "checkbox", "radio") ||
            "one-time-code" in completion || identifiers.any { it.contains("captcha") || it == "otp" || it == "onetimecode" }) return LoginFieldRole.NONE
        val loweredHints = hints.map { it.lowercase(Locale.ROOT) }
        val variation = inputType and InputType.TYPE_MASK_VARIATION
        val inputClass = inputType and InputType.TYPE_MASK_CLASS
        val passwordInput = inputClass == InputType.TYPE_CLASS_TEXT && variation in setOf(InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) ||
            inputClass == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        if (type == "password" || loweredHints.any { it in setOf("password", "current-password", "new-password") } || completion.any { it in setOf("current-password", "new-password") } || passwordInput) return LoginFieldRole.PASSWORD
        if (type == "email" || loweredHints.any { it in setOf("username", "email", "emailaddress") } || completion.any { it in setOf("username", "email") } || identifiers.any { it in accountIds }) return LoginFieldRole.USERNAME
        return LoginFieldRole.NONE
    }
}
