package app.kavorynx.vault

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Launched by the system's Save UI, never by an arbitrary website directly. */
class SaveCredentialActivity : FragmentActivity() {
    override fun onStop() { super.onStop(); if (!isChangingConfigurations) finish() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val host = intent.getStringExtra("site_domain") ?: run { finish(); return }
        if (DomainPolicy.canonicalHost("https://$host") != host) { finish(); return }
        val user = intent.getStringExtra("site_user") ?: ""
        val pass = intent.getStringExtra("site_pass") ?: run { finish(); return }
        val repository = VaultRepository(this)
        if (!repository.exists() || pass.isEmpty()) { finish(); return }
        setContent {
            SenviyaTheme {
                var master by remember { mutableStateOf("") }
                var error by remember { mutableStateOf("") }
                var loading by remember { mutableStateOf(false) }
                val scope = rememberCoroutineScope()
                Column(Modifier.fillMaxSize().background(soft).safeDrawingPadding().padding(24.dp),
                    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    BrandMark()
                    Spacer(Modifier.height(18.dp))
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_120), style = MaterialTheme.typography.headlineMedium, color = ink)
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_121), color = subtle)
                    Spacer(Modifier.height(20.dp))
                    Surface(shape = RoundedCornerShape(22.dp), color = androidx.compose.ui.graphics.Color.White) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(androidx.compose.ui.res.stringResource(R.string.ui_122), color = subtle, style = MaterialTheme.typography.labelMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Language, null, tint = teal)
                                Spacer(Modifier.width(8.dp))
                                Text(host, fontWeight = FontWeight.SemiBold, color = ink)
                            }
                            HorizontalDivider()
                            Text(androidx.compose.ui.res.stringResource(R.string.ui_204, (user.ifBlank { UiText.get(R.string.ui_331) })), color = ink)
                            Text(androidx.compose.ui.res.stringResource(R.string.ui_123), color = subtle)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    if (!VaultSession.unlocked) OutlinedTextField(master, { master = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_124)) }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Outlined.Lock, null) })
                    Spacer(Modifier.height(12.dp))
                    Button(modifier = Modifier.fillMaxWidth(), enabled = !loading && (VaultSession.unlocked || master.isNotEmpty()),
                        shape = RoundedCornerShape(14.dp), onClick = {
                            loading = true
                            val chars = master.toCharArray(); master = ""
                            scope.launch {
                                try {
                                    withContext(Dispatchers.Default) {
                                        VaultSession.confirmAndSaveLogin(repository, chars, host, user, pass)
                                    }
                                    finish()
                                } catch (_: Exception) { error = UiText.get(R.string.ui_205) }
                                finally { loading = false; chars.fill('\u0000') }
                            }
                        }) { Text(if (loading) "Saving…" else "Confirm & save securely") }
                    TextButton(onClick = { finish() }) { Text(androidx.compose.ui.res.stringResource(R.string.ui_125)) }
                    if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_126),
                        color = subtle, style = MaterialTheme.typography.labelSmall)
                    Text(androidx.compose.ui.res.stringResource(R.string.ui_127),
                        color = subtle, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
