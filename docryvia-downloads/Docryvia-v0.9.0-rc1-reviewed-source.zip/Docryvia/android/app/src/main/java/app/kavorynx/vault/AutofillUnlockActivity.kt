package app.kavorynx.vault

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.view.autofill.AutofillId
import android.view.autofill.AutofillManager
import android.view.autofill.AutofillValue
import android.service.autofill.Dataset
import android.service.autofill.FillResponse
import android.widget.RemoteViews
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Every fill requires separate authentication; never returns a complete vault. */
class AutofillUnlockActivity : FragmentActivity() {
    private var securityScreenEvent by mutableIntStateOf(0)
    override fun onUserInteraction() { super.onUserInteraction(); LockPreferences.interaction() }
    override fun onStop() { super.onStop(); if (!isChangingConfigurations) securityScreenEvent++ }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val host = intent.getStringExtra("requested_domain") ?: run { finish(); return }
        val browser = intent.getStringExtra("verified_browser") ?: run { finish(); return }
        val native = intent.getBooleanExtra("native_app", false)
        if (native) {
            if (browser != host || AppIdentity.signature(this, browser) == null) { finish(); return }
        } else if (browser !in FieldScanner.browsers || DomainPolicy.canonicalHost("https://$host") != host) { finish(); return }
        val selectedId = intent.getStringExtra("selected_item")
        fun accounts(): List<VaultItem> {
            val matches = if (native) VaultSession.accountsForApp(this, browser) else VaultSession.accountsForHost(host)
            return if (selectedId == null) matches else matches.filter { it.id == selectedId }
        }
        val displayOrigin = if (native) getString(R.string.app_origin, browser) else "https://$host"
        @Suppress("DEPRECATION") val userId = intent.getParcelableExtra<AutofillId>("field_user")
        @Suppress("DEPRECATION") val passId = intent.getParcelableExtra<AutofillId>("field_password") ?: run { finish(); return }
        val repo = VaultRepository(this)
        setContent {
            SenviyaAppTheme {
                var master by remember { mutableStateOf("") }
                var entries by remember { mutableStateOf<List<VaultItem>>(
                    if (VaultSession.unlocked) runCatching { accounts() }.getOrDefault(emptyList())
                    else emptyList()) }
                var usingSession by remember { mutableStateOf(VaultSession.unlocked) }
                LaunchedEffect(VaultSession.unlocked) {
                    if (usingSession && !VaultSession.unlocked) { entries = emptyList(); finish() }
                }
                var error by remember { mutableStateOf("") }
                var busy by remember { mutableStateOf(false) }
                val scope = rememberCoroutineScope()
                LaunchedEffect(securityScreenEvent) {
                    if (securityScreenEvent > 0) { entries = emptyList(); master = ""; finish() }
                }
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding(), contentAlignment = Alignment.BottomCenter) {
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
                        color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp) {
                        Column(Modifier.padding(horizontal = 23.dp, vertical = 22.dp),
                            verticalArrangement = Arrangement.spacedBy(15.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BrandMark(); Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(androidx.compose.ui.res.stringResource(R.string.ui_113), fontWeight = FontWeight.Bold, color = ink)
                                    Text(androidx.compose.ui.res.stringResource(R.string.ui_114), color = subtle, style = MaterialTheme.typography.labelSmall)
                                }
                                IconButton(onClick = { setResult(Activity.RESULT_CANCELED); finish() }) {
                                    Icon(Icons.Outlined.Close, androidx.compose.ui.res.stringResource(R.string.ui_2), tint = subtle)
                                }
                            }
                            HorizontalDivider(color = outline)
                            Text(androidx.compose.ui.res.stringResource(R.string.ui_115), color = subtle)
                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Lock, null, tint = teal)
                                    Spacer(Modifier.width(10.dp))
                                    Text(displayOrigin, color = ink, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            if (entries.isEmpty() && VaultSession.unlocked) {
                                Text(androidx.compose.ui.res.stringResource(R.string.ui_116), color = subtle)
                                if (!native) TextButton(onClick = { SensitiveClipboard.copy(this@AutofillUnlockActivity, displayOrigin); error = UiText.get(R.string.autofill_site_copied) }) {
                                    Text(UiText.get(R.string.copy_autofill_site))
                                }
                            } else if (entries.isEmpty()) {
                                Text(androidx.compose.ui.res.stringResource(R.string.ui_117), color = subtle)
                                OutlinedTextField(master, { master = it }, modifier = Modifier.fillMaxWidth(),
                                    label = { Text(androidx.compose.ui.res.stringResource(R.string.ui_96)) }, singleLine = true,
                                    visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(15.dp))
                                Button(enabled = master.isNotEmpty() && !busy, shape = RoundedCornerShape(15.dp),
                                    modifier = Modifier.fillMaxWidth().height(52.dp), onClick = {
                                        busy = true
                                        val chars = master.toCharArray(); master = ""
                                        val capturedEvent = securityScreenEvent
                                        scope.launch {
                                            var key: ByteArray? = null
                                            try {
                                                withContext(Dispatchers.Default) { key = repo.unlock(chars) }
                                                if (capturedEvent == securityScreenEvent && !isFinishing) {
                                                    VaultSession.start(key ?: error("No key"), repo)
                                                    usingSession = true
                                                    entries = accounts()
                                                    error = if (entries.isEmpty()) UiText.get(R.string.ui_332) else ""
                                                }
                                            } catch (_: Exception) { error = UiText.get(R.string.ui_203) }
                                            finally { key?.fill(0); chars.fill('\u0000'); busy = false }
                                        }
                                    }) { Text(if (busy) UiText.get(R.string.ui_293) else UiText.get(R.string.ui_294)) }
                            } else {
                                Text(androidx.compose.ui.res.stringResource(R.string.ui_118), style = MaterialTheme.typography.titleMedium, color = ink)
                                LazyColumn(Modifier.heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    items(entries, key = { it.id }) { item ->
                                        Surface(onClick = account@{
                                            if (usingSession && !VaultSession.unlocked) {
                                                entries = emptyList(); finish(); return@account
                                            }
                                            val view = RemoteViews(packageName, android.R.layout.simple_list_item_1)
                                            view.setTextViewText(android.R.id.text1, "Docryvia · ${item.username}")
                                            val builder = Dataset.Builder(view)
                                            userId?.let { builder.setValue(it, AutofillValue.forText(item.username)) }
                                            builder.setValue(passId, AutofillValue.forText(item.secret))
                                            val authenticatedFill: android.os.Parcelable = if (intent.getBooleanExtra("dataset_auth", false)) builder.build()
                                            else FillResponse.Builder().addDataset(builder.build()).build()
                                            val response = Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, authenticatedFill)
                                            setResult(Activity.RESULT_OK, response)
                                            entries = emptyList()
                                            finish()
                                        }, shape = RoundedCornerShape(15.dp), color = soft) {
                                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Outlined.AccountCircle, null, tint = ocean)
                                                Spacer(Modifier.width(12.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(item.username.ifBlank { item.title }, fontWeight = FontWeight.SemiBold, color = ink)
                                                    Text(host, style = MaterialTheme.typography.labelSmall, color = subtle)
                                                }
                                                Icon(Icons.Outlined.ChevronRight, null, tint = subtle)
                                            }
                                        }
                                    }
                                }
                            }
                            if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
                            Text(androidx.compose.ui.res.stringResource(R.string.ui_119),
                                style = MaterialTheme.typography.labelSmall, color = subtle)
                        }
                    }
                }
            }
        }
    }
}
