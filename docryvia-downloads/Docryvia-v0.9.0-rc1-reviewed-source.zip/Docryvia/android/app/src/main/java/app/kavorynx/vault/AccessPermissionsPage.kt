package app.kavorynx.vault

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

@Composable
fun AccessPermissionsPage(activity: FragmentActivity, cameraAllowed: Boolean, onCamera: () -> Unit, onDone: () -> Unit) {
    var selected by remember { mutableStateOf(AutofillReadiness.selected(activity)) }
    DisposableEffect(activity) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) selected = AutofillReadiness.selected(activity) }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        BrandMark()
        Text(UiText.get(R.string.access_heading), style = MaterialTheme.typography.headlineMedium)
        Text(UiText.get(R.string.access_help))
        Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(UiText.get(R.string.access_files), Modifier.padding(16.dp))
        }
        Text(UiText.get(R.string.access_camera))
        if (cameraAllowed) Text(UiText.get(R.string.access_camera_allowed), color = MaterialTheme.colorScheme.primary)
        else Button(onClick = onCamera) { Text(UiText.get(R.string.access_camera_allow)) }
        OutlinedButton(onClick = { activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${activity.packageName}"))) }) { Text(UiText.get(R.string.open_access_settings)) }
        HorizontalDivider()
        Text(UiText.get(R.string.access_autofill))
        Text(if (selected) UiText.get(R.string.autofill_active) else UiText.get(R.string.ui_319))
        OutlinedButton(onClick = { AutofillReadiness.open(activity) }) { Text(if (selected) UiText.get(R.string.manage_autofill) else UiText.get(R.string.ui_252)) }
        Text(UiText.get(R.string.autofill_details), style = MaterialTheme.typography.bodySmall)
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text(UiText.get(R.string.access_continue)) }
    }
}
