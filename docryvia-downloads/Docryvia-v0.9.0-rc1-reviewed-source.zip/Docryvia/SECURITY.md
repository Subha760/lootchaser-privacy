# Docryvia security reporting

Current reviewed build: v0.9.0-rc1 release candidate. See docs/V0_9_USER_FIXES.md for implemented controls, validation evidence and remaining acceptance gates.

Contact choicematrix at help@choicematrix.in using a minimal reproduction and fictional data. Never send passwords, recovery codes, private signing keys or identity documents. Keep signing material outside public repositories and artifacts.

Encryption does not protect against a compromised device, hostile keyboard or externally exported copies. JVM strings and decrypted objects are garbage-collected; clearing selected arrays does not guarantee physical memory erasure. Report vulnerabilities privately before disclosing details that could expose users.
