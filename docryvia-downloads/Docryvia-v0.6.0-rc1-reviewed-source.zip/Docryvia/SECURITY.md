# Docryvia security reporting

Version 0.6.0-rc1 is a release candidate. It has build and regression-test evidence but has not received an independent security certification or real-device/browser acceptance testing in this review.

Contact provided by the publisher choicematrix: **lootchaser2026@gmail.com**. Report vulnerabilities using a minimal reproduction and synthetic data. Never send passwords, recovery codes, private signing keys or identity documents.

Do not publish sensitive user data in a report. Encryption does not protect against a compromised device, hostile keyboard, external exported copies, or earlier copies of access material. JVM strings and decrypted objects are garbage-collected; wiping selected arrays does not guarantee physical memory erasure.

See `docs/V0_6_REVIEW.md` for implemented controls, verification evidence and unresolved publication requirements.
