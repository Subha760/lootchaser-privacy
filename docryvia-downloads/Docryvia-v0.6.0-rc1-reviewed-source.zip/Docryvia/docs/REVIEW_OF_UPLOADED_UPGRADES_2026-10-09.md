# Review: Docryvia Tools, Features and Upgrades

Source reviewed: user-provided `Docryvia-Tools-Features-Upgrades.txt`, 9 October 2026.

The report expressly says that Senviya v0.2 / Docryvia v0.3 were **not compiled or device-tested**. It also references `Senviya-Fix-List.txt`, which was not supplied with the uploaded guide. Do not treat the guide's `DONE` labels as independently established without code and device inspection.

## Highest priority

1. Actual debug and release builds on Android SDK 36, with unit tests, Android Lint, and CI logs.
2. Fully operational vault edit/create/delete and user-confirmed autofill FillResponse handling.
3. Biometrics cancellation/error handling and safe recovery key confirmation.
4. Clipboard handling that does not read clipboard in the background; sensitive marker for Android 13+.
5. Save, export, import and restore durability tests; immutable, authenticated storage formats; threat-model review.
6. Safe off-main-thread processing and one-document-per-encrypted-file design to avoid huge copies and UI stalls.
7. OS and browser interoperability testing using dummy logins; fail closed on origins/associations that cannot be verified.
8. OWASP MASVS verification, dependence vulnerability scanning, independent penetration testing before release.

## Valuable features after core quality gate

- Offline document scanner with immediate encryption of the scanned output.
- OCR with locally encrypted extracted text, language-specific review (Hindi and Bengali).
- Expiry reminders revealing no document names or numbers in lockscreen notifications.
- Password health, secure TOTP import/QR and managed recovery-code storage.
- Secure explicit-share workflow with temporary URI grants and recipient-risk disclosure.
- Verified encrypted backup-to-user-selected folder and restore preview.
- Adaptive Material 3 layout, dark mode, reduced-motion accessibility, large font, TalkBack, Hindi/Bengali localization.
- Password/passkey provider using Android Credential Manager after separate authentication and security design.

## Defer or reject

- No cloud accounts, network permission, ads, analytics, accessibility-service extraction, or overlay permissions by default.
- No unreviewed native crypto implementation or homemade streaming AES-GCM format.
- No promise that a decoy vault, root detection, screenshot blocking or local time-delayed access is unbreakable.
- Do not advertise official DigiLocker/government verification.

## What changed in this v0.4 source package

- Wired previously unused ItemEditor to add/edit/delete action and document-export picker.
- Added back navigation while unlocked.
- Fixed authentication result from selected Dataset to FillResponse with the selected Dataset.
- Hardened exact HTTPS host parsing using JVM URI and added standalone domain-policy tests.
- Centralized sensitive clipboard write and delayed clear without background read.
- Improved biometric prompt terminal error/cancel handling and clears the pending key copy on error.
- Recovery-key display hides the code before the user verifies two groups.
- Reduced a password-health false positive affecting long letter-only passwords.
- Rejected duplicate entries in encrypted ZIP import.
- Updated CI for Android platform 36 / Gradle 8.13 with lint, unit, debug and release build tasks.
- Added .gitignore, Dependabot, debug-only StrictMode and LeakCanary; SECURITY.md.

## Important remaining gaps

- No Android SDK or Gradle installed in this workspace; real compilation and emulator testing are not validated here.
- Missing `Senviya-Fix-List.txt` prevents completing the report's specified full prerequisite plan.
- Core still stores documents within one big encrypted JSON blob; large file operations may cause latency or high memory use.
- Biometric key validity and device credential behavior require multi-OEM/device testing.
- Data may be visible in unmanaged device memory on compromised devices; privacy cannot be guaranteed against all attacks.
- Backup and restore are not yet instrumented-tested for power loss or malformed archive edge cases.
- Credential Manager provider / passkeys, scanner, OCR, expiry reminders, TOTP and full app autofill are not implemented.
- Branding and store policy clearance, independent security audit and signed release AAB still pending.

Use synthetic test data only until all relevant risks are resolved.
