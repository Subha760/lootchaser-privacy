# Docryvia Android v0.5 source audit, fixes and caveats

9 October 2026. This is a review of the latest user-supplied Docryvia v0.4 source with v0.5 code modifications. **No APK was built, installed, or executed on an Android phone.** The build environment lacks Android SDK/Gradle and cannot access the network to install them. Therefore **do not use real credentials, identity documents, or payment information**.

## What was inspected
- Manifest permissions, app backup settings, source organization, encryption module, repository, session handling, device unlock, autofill service, save-confirmation and account-fill activities, document imports, exports and backup ZIP logic.
- Compose navigation/editor, screens, categories, settings and onboarding.
- Existing JVM tests, app release/CI files and security checklists.
- User-provided `Docryvia-Tools-Features-Upgrades.txt` and the referenced improvements. Separate `Senviya-Fix-List.txt` is still unavailable.

## v0.5 source changes
1. **Encrypted backup picker lifecycle:** the v0.4 prepared ZIP was kept only in Compose state and erased on `onStop`, often before Android's CreateDocument picker returned. v0.5 instead validates the generated ZIP and temporarily stages **only the already password-encrypted ZIP** in `noBackupFilesDir`; picker callback writes it even while vault is locked, optionally compares SHA-256 against the saved result, and deletes the staged copy. Abandoned staged files older than 24 hours are removed on next startup. Temporary staging is NOT an unencrypted secret.
2. **Long operations off UI thread:** importing/exporting bytes, encrypted item save/delete and master-password rewrap use coroutines with IO/background dispatchers rather than blocking Compose UI. This is a first improvement, **not proof of zero jank**.
3. **Encrypted favorite and expiry metadata:** `VaultItem` has optional `favorite` and ISO date `expiryDate`, read with defaults from older JSON. No ciphertext format or associated-data strings were changed; existing encrypted vault and ZIP structure remain compatible at the source-data level (not device-tested).
4. **Renewal visibility:** local expiry policy, home 30-day due count, item due/expired labels, optional expiry field in editor. **No background notification reminders** added; notification permission is still absent.
5. **Explicit address sharing confirmation:** selected address is reviewed before opening Android share sheet, with warning that destination gets a copy. Sharing is never automatic.
6. **Unified password health:** Settings now uses the same local `PasswordHealth.analyze` as the Passwords tab, including duplicate-login detection.
7. **Save confirmation transparency:** on duplicate website/username, save prompt warns that the password will be replaced; update retains prior item's ID, notes, favorite and category.
8. **Conditional callbacks:** clarified Kotlin lambda syntax for edit/delete/export/share; no verified defect was established in v0.4's original `else {{ ... }}` form (it is valid Kotlin block returning a lambda). v0.5 uses `else ({ ... })` explicitly.
9. **Regression testing:** added JVM unit-test sources for `ExpiryPolicy`, `PasswordHealth` and `DomainPolicy`; standalone Kotlinc test drivers for expiry, domain matching, health and CSV were executed successfully; extended XML/manifest/wiring source contracts.
10. **Visual preview assets:** four **static** design illustrations included under `docs/previews/`. They are **not actual Android device screenshots** and use synthetic entries.

## Status by feature
- **Source present, limited to website/browser support:** Android AutofillService, native Android SaveInfo flow, master-password authenticator, on-device encrypted passwords, document import/export, addresses/notes/travel records, encrypted ZIP backup and merge restore, biometric/device unlock setup.
- **Source additions in v0.5, not runtime-tested:** reliable encrypted ZIP picker lifecycle, saved favorites/expiry dates, due indicators, background writes, address share confirmation.
- **Still missing:** document scanner, OCR, TOTP UI, expiry notification scheduler, full secure document viewer, verified native-app autofill and Digital Asset Links verification, Credential Manager provider/passkeys, encrypted media streaming, independent security audit, signed APK/AAB/store publication.
- **Still unresolved:** current single encrypted JSON document blob re-encrypts all files for every mutation; 8 MB individual-file cap and RAM consumption; biometric Keystore compatibility across OEMs, passphrase/KDF metadata migration, file picker process-death restoration, backup restore interruptions, phishing across web iframes and real browsers.

## Checks completed
- `python3 tests/source_contract.py` static contracts: pass.
- `kotlinc` + Java test drivers: domain, password health, CSV, expiry: pass.
- Basic Kotlin conditional callback semantics: pass.
- Source ZIP CRC verification: see deliverable verification logs.
- **Not run:** Gradle assembleDebug/Release, Android Lint, full JUnit/Compose tests, emulator/device UI tests, real browser autofill, profiling, independent audit.

## Next responsible gate
1. Commit v0.5 to a repository and run `.github/workflows/checks.yml` to compile the APK and run unit tests. Fix all compile/lint failures first; do not assume it will pass.
2. Test it on Android 9, 11, 13, 14, 15 and 16, especially OEM biometric prompts and browser autofill.
3. Build instrumented tests for create/edit/delete, save-login, vault lock on background, backup picker/verify/restore and malformed ZIP/CSV cases.
4. Separate documents as independently encrypted files with tested migration, design true secure viewing/scanning, then add OCR, TOTP and expiry reminders.
5. Obtain security review, privacy-policy legal review, brand clearance, app signing, signed production AAB and store listing.
