# Autofill and save-password design

The Android system owns the initial autofill dropdown and save-password UI. An independent password manager **cannot force an identical Google Wallet floating popup above every app** without dangerous overlays or accessibility abuse. Docryvia intentionally uses the official AutofillService API rather than background scraping.

## Filled login flow
1. The user enables Docryvia as Autofill provider in Android Settings.
2. A supported browser publishes its AssistStructure to the Android OS for a login form.
3. Docryvia reads reported form types and HTTPS webScheme/webDomain, enforces single exact host and a browser package allowlist. Uncertain scheme/domain → refuse.
4. Android displays "Docryvia · Unlock for hostname" as a system autofill suggestion.
5. Selecting the suggestion launches `AutofillUnlockActivity`, which displays the requested HTTPS hostname.
6. The user enters a master password, then selects exactly one matching saved account. Only those two fields (username and password) return in an authenticated Dataset.
7. Docryvia never silently sends an entire vault to a browser. Closing the sheet cancels the transaction.

## Save login flow
1. For supported browser forms, `onFillRequest()` returns `SaveInfo` with required password ID and optional username ID, allowing Android to display its own Save UI after the user submits/changes a form.
2. **Only after the user accepts Android's Save UI**, `onSaveRequest` reads the requested form, rejects non-HTTPS or ambiguous origins, and opens `SaveCredentialActivity`.
3. This activity shows the **exact reported host and username**, masks the password, and requires explicit master-password confirmation.
4. The new or replaced login is added to the AES-GCM encrypted local vault; there is no internet/network request.
5. Exact timing and whether the Android Save UI appears are decided by the browser, the site and Android autofill integration. This code has not been runtime validated across websites.

## Security caveats
- The hostname is supplied via Android AssistStructure, not certified against all native app website associations. Native non-browser apps are **not** allowlisted. Websites with nested iframes might be refused.
- Strong phishing defense requires testing with real browsers, digital asset links for native apps, scheme verification, iframe isolation, Unicode hostname tests, and changing forms.
- A password necessarily becomes visible to the **chosen** login form at fill time. A malicious but matching HTTPS page may still access it.
- Android 14+ Credential Manager provider/passkey support **is not implemented**. Do not advertise passkeys.
- The app cannot promise fill/save support on all shopping, ticket, banking or food apps; each integration must be individually validated.

Official references:
- https://developer.android.com/reference/android/service/autofill/AutofillService
- https://developer.android.com/reference/android/service/autofill/SaveInfo
- https://developer.android.com/reference/android/app/assist/AssistStructure.ViewNode
- https://developer.android.com/identity/sign-in/credential-provider
