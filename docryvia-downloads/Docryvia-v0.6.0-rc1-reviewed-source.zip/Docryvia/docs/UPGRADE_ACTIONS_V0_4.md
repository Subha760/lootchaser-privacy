# Docryvia v0.4: targeted source fixes after tools-and-features guide review

This is a focused repair, **not** the full guide or the missing `Senviya-Fix-List.txt`.

Changes made:
- Connect New/Edit item dialogs to real local vault save/delete and document export entry point.
- Back button navigates home/dismisses editor instead of abruptly closing the app.
- Response-level Android autofill authentication returns a `FillResponse` with the user-selected `Dataset`, as required by Android documentation.
- Tight HTTPS/domain parser uses java.net.URI, exact host equality, rejects userinfo, non-443 ports and malformed host labels.
- Password clipboard uses sensitive flag (API 33+) and scheduled clear without background clipboard reads. IMPORTANT: may clear a subsequently copied value because reading clipboard in background is restricted.
- Recovery flow requires re-entering two key groups before dismissal.
- Reject duplicate README entries in encrypted backup ZIP.
- CI now targets SDK 36 and Gradle 8.13 and attempts debug, release, lint and JVM tests; Dependabot, StrictMode in debug, and debug-only LeakCanary.
- Existing vault encryption context and Keystore alias remain unchanged intentionally for backward data format compatibility.

Not fixed yet: all issues in the unavailable `Senviya-Fix-List.txt`; one-blob document encryption; main-thread writes; biometric failure/cancellation polish; cross-app autofill identity verification; security-reviewed backup restore; Credential Manager and passkeys; Android SDK build and real-device testing.

The generated alpha must not hold real passwords, recovery codes or identity documents until security evaluation is completed.
