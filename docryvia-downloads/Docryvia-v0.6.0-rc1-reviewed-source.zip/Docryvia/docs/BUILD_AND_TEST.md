# Build and verification

Use JDK 17, Android SDK Platform 36, Build Tools 35.0.0, Android Gradle Plugin 8.13.2, Gradle 8.13 and Kotlin 2.0.21.

From `android/`:

```sh
./gradlew --no-daemon :app:lintDebug :app:testDebugUnitTest :app:assembleDebug
```

Signed release builds require private `keystore.properties` and the matching private signing key. Use `keystore.properties.example` only as a template; never commit real signing material.

```sh
./gradlew --no-daemon :app:assembleRelease :app:bundleRelease
```

From the project root:

```sh
python3 -m pip install lxml
python3 tests/source_contract.py
```

JVM/Robolectric tests use synthetic data and cover core policies, recovery, repository mutation, app/session timeout and screen-off behavior. They are not device UI, Android Keystore or real-browser tests. See `V0_6_REVIEW.md` for completed results and `QA_MANUAL_TEST_PLAN.md` for remaining device tests.
