# v0.6 release-candidate status

- [x] Debug and signed release APK/AAB builds; see current verification in `V0_6_REVIEW.md`.
- [x] Regression tests for recovery, import identities, metadata preservation, and session lifecycle.
- [x] choicematrix publisher and support details; public GitHub privacy-policy page.
- [ ] Real-device, biometric, browser/iframe, update/migration and accessibility testing.
- [ ] Independent security/dependency review and final legal/store declarations.
- [ ] Store internal-test track and publication. Signing does not constitute store approval.

The older checklist below remains a planning reference; the v0.6 report is the current source of verification evidence.

# Release gate (must complete before accepting real users)

- [ ] Fix all Android compilation failures and run `assembleDebug`, `assembleRelease`, unit and instrumentation tests
- [ ] Test full vault lifecycle on Android 9, 10, 11, 12, 13, 14, 15, 16
- [ ] Check strong fingerprint, 3D face (where eligible), weak face refusal, device PIN, pattern, password, cancel, lockout, enrollment removal
- [ ] Validate no unexpected access on background, screen-off, process death, rotation, backup restoration and user-profile switching
- [ ] Verify forgot-master-password recovery and rotate recovery key on real phones
- [ ] Verify encryption tamper rejection, wrong backup passphrase, corrupt ZIP, ZIP bomb and interrupted writes
- [ ] Thoroughly verify AutofillService with browsers: Chrome, Edge, Firefox and OEM browsers; remove unsafe allowlists
- [ ] Independent phishing-origin and embedded iframe security audit; Digital Asset Links assessment
- [ ] Implement Android 14+ Credential Manager provider and passkeys before claiming parity with Google Password Manager
- [ ] Add truly compatible cross-platform encrypted backups, user-confirmed encrypted sharing
- [ ] Audit third-party dependencies, generate SBOM, static/dynamic security analysis, independent penetration testing
- [ ] Add accessibility labels, screenreader, reduced motion, tablet layouts, font scaling and low-memory handling
- [ ] Complete translations and internationalisation; ensure sensitive notes cannot leak to screenshots or clipboard
- [ ] Write and validate contact information in Privacy Policy, Terms and support website; host public policy URL
- [ ] Review Google Play Data Safety, privacy and credential management policies, Indus requirements, icon and screenshots
- [ ] Create secure release signing key, sign AAB/APK, internal testing track and staged rollout

**Status: not yet approved for publication.**


## October 2026 policy update
- Confirm targetSdk 36 (Android 16) for new regular Google Play submissions after 31 August 2026.
- Verify Android Studio/AGP 8.13 and Gradle 8.13 build on actual SDK 36.
- Finalize unique brand and release package ID before Play Console publication; preserve existing vault crypto identifiers until a tested migration exists.
