# Threat model — Docryvia alpha

| Threat | Implemented mitigation | Residual risk |
|---|---|---|
| Stolen locked handset | Random 256-bit DEK, AES-256-GCM, slow password KDF, Android app-private files | Weak master passwords remain vulnerable to offline cracking if ciphertext obtained |
| Password recovery abuse | Offline random recovery token, independent authenticated DEK wrap | If printed key stolen, an attacker with app data can unlock |
| Strong biometric/device lock | Android Keystore bound key + BiometricPrompt CryptoObject | Weak face sensors blocked; credential-enrollment changes can invalidate key |
| Malicious Android app | No exported vault activity; system-protected AutofillService; limited browser packages | Accessibility malware/privileged compromise may intercept login forms |
| Phishing pages | Explicit exact HTTPS host checks, per-fill master unlock and selection | Homograph domains, malicious scripts on the legitimate domain, browser quirks, and origin spoofing need device audits |
| Backup theft | ZIP contents encrypted with independent PBKDF2/AES-GCM key | Backup passphrase must be long and unique; physical copies need protection |
| ZIP bomb | Byte-size cap, per-entry decompression cap, validated entry count/names | Further fuzzing required |
| Sensitive OS UI | FLAG_SECURE; app locks on background; Android file picker | Keyboard apps, IME caches, clipboard, screenshots from other applications |
| Release malware/supply chain | Minification enabled; no analytics/ads; build workflow included | No signed reproducible release or third-party dependency audit yet |

The current code has not undergone external security testing, red teaming, Android instrumented tests, rooted-device analysis, browser compatibility testing, or formal cryptographic review. This is explicitly not a zero-leak guarantee.
