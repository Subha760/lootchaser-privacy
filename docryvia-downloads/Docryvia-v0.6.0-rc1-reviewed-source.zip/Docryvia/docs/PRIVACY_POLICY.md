# Docryvia Privacy Policy

Effective date: 10 October 2026. Applies to Docryvia Android v0.6.0-rc1.

Publisher: **choicematrix**  
Privacy and support contact: **lootchaser2026@gmail.com**  
Public policy: https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html

## Data stays on your device
Docryvia is an offline password and document vault. It has no developer-managed account, cloud sync, internet permission, advertising or analytics service in the release build. choicematrix does not receive your vault contents, master password, recovery answers, recovery codes or biometric templates through the app. No vault information is sold or used for advertising.

You choose what to store: passwords, usernames, website addresses, notes, address/identity/travel records and imported files. These records and their metadata are encrypted in app-private storage. The app decrypts them while you use an unlocked vault. AES-256-GCM protects vault data; PBKDF2-HMAC-SHA256 with 600,000 iterations protects password-based key wrapping. Encryption does not protect information already disclosed to another app, a compromised device, or an untrusted keyboard.

## Unlocking and recovery
The master password stays on the device and is not sent to choicematrix. Optional quick unlock uses Android's biometric/device-credential interface and Keystore. Android controls fingerprint, face and screen-lock authentication; Docryvia does not store biometric templates.

Optional question recovery stores a question identifier and an encrypted key envelope. It requires both your answer and a separate random rescue code. Neither the answer nor that rescue code is stored in plaintext. Successful question recovery consumes the kit. Main recovery-key reset also invalidates the question kit. Password changes and resets disable the app's stored device-unlock wrapper; you can enable it again afterward. The main recovery key remains valid until you rotate it.

An unlocked session stays in RAM for up to 30 seconds after the app's activities leave the foreground, allowing brief file-picker/browser switches without another login. Screen-off, manual lock, timeout and process death clear that session. While an app activity remains visible, the vault stays unlocked until locked. Sensitive screens block normal Android screenshots, subject to device/OS behavior.

## Permissions and browser autofill
The release build requests biometric authentication permissions and lets you enable its Android AutofillService in system settings. It does not request internet, SMS, contacts, location, camera, microphone, broad storage, overlay or accessibility permissions. File access uses Android's picker for files you select.

Android may supply browser form metadata and entered values to the local autofill service. Docryvia checks exact HTTPS hostnames for supported browsers. Filling requires authentication or an already authenticated session, and your explicit account selection. Saving requires your approval. Only the chosen login is returned to the destination. Browser/native-app support is limited and is not guaranteed for every form.

## Exports, clipboard and sharing
An encrypted ZIP backup is created only at a destination you choose and uses its own passphrase. An encrypted temporary export may be staged in app-private no-backup storage while a picker is open. It is removed on completion/cancellation; abandoned files older than 24 hours are cleaned at a later app startup.

Google Password Manager CSV imports are plaintext source files. Docryvia reads them locally and encrypts supported entries; you must remove unwanted original CSV copies yourself. A document export creates a decrypted copy at your selected destination. Address sharing requires your confirmation and Android's share sheet. Generated-password clipboard copies are marked sensitive where supported and scheduled for clearing after 30 seconds; OS behavior and copies taken by another app are outside Docryvia's control.

Once you share, export or autofill information, the destination, operating system, file provider, browser and other apps follow their own policies. Docryvia cannot revoke or remotely delete their copies. Opening this public policy launches a browser, which contacts GitHub Pages under GitHub's privacy policy: https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement.

## Retention and deletion
Local records remain until you delete them or clear/uninstall the app. Deleting an item rewrites the encrypted vault without that item. Clearing app data or uninstalling removes the app's local vault and access material. Android backup/data-transfer settings are disabled for the vault; keep your own encrypted backups. Exported files and external copies remain until you remove them. Physical flash-storage remnants and historical backups may persist; secure physical erasure is not guaranteed.

There is no remote Docryvia account to delete. You can review, edit, export or delete your records locally. If all usable passwords/recovery methods are lost, choicematrix cannot recover the encrypted vault for you.

## Support and changes
If you email support, the email and information you voluntarily send are handled by the email provider and choicematrix to address your request. Do not send passwords, recovery codes or identity documents. Contact lootchaser2026@gmail.com for privacy questions or to request deletion of support correspondence.

This is a release candidate and has not received an independent security certification. Review device testing and maintain encrypted backups before relying on it for valuable data. If data handling changes, the effective date and this policy will be updated. New cloud, analytics or permission-dependent features require an updated policy describing their behavior.
