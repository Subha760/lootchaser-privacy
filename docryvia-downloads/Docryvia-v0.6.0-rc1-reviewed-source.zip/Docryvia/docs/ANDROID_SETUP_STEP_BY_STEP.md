# Android Studio build, setup and deployment — step by step

## Prerequisites
1. Install an up-to-date Android Studio capable of using Android Gradle Plugin 8.13.x.
2. Select JDK 17 in Settings → Build, Execution, Deployment → Gradle. Install Android SDK Platform 36 and Build Tools 35.0.0.
3. Install Gradle 8.13 locally or use the GitHub Actions build recipe. No downloaded wrapper JAR is in this archive.
4. Unzip the entire project in a normal writable folder. Open the *nested `android/`* folder as the Android Studio project. Let dependency sync complete.
5. Confirm `settings.gradle.kts` has `google()` and `mavenCentral()` repositories. Build type `debug` generates a test APK signed with the local debug key; never publish that key's APK to an app store.
6. In Android Studio use Build → Make Project, then Run app on a test device. Capture/log any compile errors; this alpha has not completed an Android build in the author's environment.

## On-device tests (dummy data only)
1. Start fresh, watch onboarding (five slides), try Skip, test both small and large text size settings.
2. Make master password of at least twelve characters and save the recovery key **offline**.
3. Verify wrong password and wrong recovery key do not unlock. Use a test vault to verify the correct recovery key resets the master password.
4. Enable device unlock in Settings. Test supported fingerprint/face or device PIN/pattern. Test fallback to master password after changing your device lock.
5. Add several credentials for `https://example.com`, secure notes and an address. Confirm secrets are absent from logs and cannot be accessed when locked.
6. Add a small dummy PDF and JPEG under different document categories, relaunch and verify categories survive. Test invalid/oversized files.
7. In Settings enable Docryvia as the Android Autofill service. Visit a dummy HTTPS page in a supported browser and check the Android system's suggestion; verify it requires unlock. Submit a new dummy login and check whether the native Save UI appears. Browser/site differences are expected and must be recorded.
8. Ensure nothing appears or fills on HTTP, unknown-origin, mixed-origin or lookalike domains. Native apps are **not** supported unless separately verified and built.
9. Export encrypted ZIP via Android file picker, relaunch, import, and verify data. Test wrong passphrase, corrupt ZIP, oversized files, duplicate entries, and interrupted restores.
10. Import a **dummy** Google-format CSV and check the imported passwords. Delete the original plaintext file from downloads afterward; inspect backups too.
11. Rotate recovery key. Verify prior token no longer works in a test vault. Confirm no sensitive content appears when multitasking because `FLAG_SECURE` is set.
12. Test Android 9, 10, 11, 13, 14, 15, various OEMs including Oppo/Realme/OnePlus, with 60/90/120 Hz displays; test offline and with battery saver.

## Release steps (not completed)
1. Replace drafts in `docs/` with legally reviewed policy and contact info. Host a public privacy policy URL.
2. Choose and clear a final brand, domain, application ID, and app signing key with Play Console.
3. Run security audits, automated UI/instrumented tests, performance baselines and full penetration testing.
4. Upgrade target SDK as store policy requires, check API-level permission prompts, verify accessibility and store Data Safety declarations.
5. Sign a **release AAB** with a key stored securely outside the repository. Enable Play App Signing and verify the artifact on fresh devices.
6. Prepare screenshots showing actual built app, real test output, app icon, description, privacy policy and support channel. Review Indus Appstore-specific guidelines separately.
7. Run closed testing on multiple devices before public rollout; handle crashes and OEM autofill compatibility before making any claims about universal support.
