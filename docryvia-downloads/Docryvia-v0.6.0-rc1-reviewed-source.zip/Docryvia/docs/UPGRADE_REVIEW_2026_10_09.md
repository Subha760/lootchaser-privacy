# Docryvia — feature review, enhancement plan and alpha status

**Date:** 9 October 2026  
**Working name:** Docryvia — Private Documents & Passwords (NOT trademark cleared)  
**Project stage:** Android-only security-sensitive alpha source. NOT approved to store real secrets or release to a store.

## What the uploaded document actually contains
The submitted `Senviya-Android-Step-by-Step-Guide.md` is an Android Studio build, manual test and release procedure. It is not a Claude review. It recommends onboarding checks, a >=12 character master password, 256-bit recovery-key verification, supported biometric and device-lock checks, dummy document and login tests, HTTPS autofill testing, encrypted ZIP restore, CSV import, OEM device testing and a release security review. It clearly says the Android app was not built or tested in its author's environment.

## Strong recommendations, in order of implementation priority

### P0: correctness before extras
1. Produce a compiling Android 16 / target API 36 build and run instrumented tests on real phones.
2. Audit the encrypted vault's key hierarchy, authentication, backups, recovery, key rotation, memory lifecycle and rollback risks. Evaluate Argon2id vs current PBKDF2 configuration and document the reason for the selection.
3. Verify Android's native autofill fill/save workflow with real test forms in supported browsers, including Android 9–16 and major OEM builds. Never autofill unverified HTTPS origins or another app's form without trusted association.
4. Ensure passwords and documents never appear in logs, crash reporting, OS previews, clipboard history or unencrypted temporary files. Test restore interruption and wrong backup keys.
5. Correct permissions and store declarations. Use native system pickers; avoid accessibility and drawing overlays for autofill.

### P1: make document vault competitive
6. Fully offline scanning with edge detection, perspective correction, grayscale/contrast control and multi-page PDF assembly.
7. On-device OCR for *user-authorized* document search; encrypt the extracted text index as well as the original PDF/image.
8. Document templates (Aadhaar, PAN, passport, driving licence, education, insurance, medical, banking, receipts and travel) with user-controlled manual fields, expiry reminders and flexible tags.
9. Local duplicate detection and smart suggestions; background workloads must have size/time limits and respect battery-saver settings.
10. Secure document export/share via short-lived Android content URI grants with explicit user confirmation; never claim persistent revocation after an external recipient saved a copy.

### P2: more powerful wallet and autofill
11. Android 14+ Credential Manager password/passkey provider following official docs; separate this from Android 8+ AutofillService. Do not claim broad native-app fill until origin/certificate association is proven.
12. Saved identity, address, passenger, shipping and booking profiles with selective field disclosure; never autofill PAN/Aadhaar/payment data without explicit per-use approval.
13. Encrypted TOTP codes and recovery-code storage; no automatic OTP interception or SMS permission.
14. Full-vault one-tap backup entry point, with encrypted output and separate backup passphrase. Add verified, atomic import/restore with preview and deduplication.
15. App's private-data viewer for PDF, photo and selected text types; prevent exporting decrypted files inadvertently.

### P3: premium UI and performance
16. Material 3 adaptive screens (small phones, tablets, foldables), dark/light mode, large font support and localization (English, Hindi and Bengali after testing).
17. Motion only where it clarifies interactions: bottom-sheet enter/exit, list transitions, vault unlock, onboarding, saved confirmations. Respect reduced-motion system accessibility settings.
18. Lazy lists, image thumbnails off the main thread, paging, cancellation, keyboard insets and benchmark profiles; measure actual jank and memory under slow/older phones.
19. Five-slide introduction with screenshots/illustrations that truthfully explain local encryption, recovery risks, permission choices and autofill scope.
20. Dashboard categories by life area, pin/favorite/recent filters, encrypted local search, accessibility labels, responsive touch targets and haptic feedback.

## Implemented in the source in this review
- Android display branding changed to **Docryvia**, with a fresh document-plus-lock blue app icon; Kotlin class names and cryptographic associated-data constants deliberately retained for backward compatibility.
- Gradle settings moved to target/compile API 36, AGP 8.13.2 and Gradle 8.13, and version bumped to `0.3.0-alpha`. **Android build remains unverified.**
- Passwords tab includes an offline-only weak/reused/duplicate credential summary. The heuristic warns; it is not a breach database or guarantee of security.
- Added a standalone Kotlin regression test and source-level checks for the above.
- Browser extension remains excluded.

## Not yet implemented
Camera scanner, OCR, offline ML categorization, passkey provider, native-app credential association, universal form filling, TOTP, expiry scheduling, multi-device migration, production storage-performance benchmarks, store submission and independent security audit.

## Build and release sequence
1. Unzip the project and open `android/` in Android Studio with JDK 17, API 36 and an AGP 8.13-capable environment.
2. Run `:app:assembleDebug :app:testDebugUnitTest` and resolve any compilation failures; install the debug build on test devices only.
3. Validate cryptography, vault recovery, device unlock, document import, password save/fill and encrypted ZIP import with dummy data; record OEM/version-specific failures.
4. Add scanner/OCR under separate encrypted boundaries, with permissionless system picker first and optional camera permission only if an in-app camera is built.
5. Conduct external security audit and performance testing, update legal policy/privacy disclosures, finalize package/name/domain, sign release AAB and test the release build before Play/Indus submission.

**Naming note:** Preliminary exact-match web searches found no exact `Docryvia` brand/app entries at the time of review. This is *not* confirmation of Indian trademark, domain registration, or Play/Indus availability; check official registries and developer portals before publication.
