# Provisional name research — 2026-10-09

Goal: pronounceable and approachable Android-only password + document vault, with no government-looking logo or borrowed official marks.

- Kavorynx: rejected by project owner for sound/branding.
- Privora: search revealed an existing Secure Offline Vault app; rejected.
- Nivetra: rejected after finding existing nivetra.com (ecommerce) and earlier commercial uses.
- Velniva: rejected after finding an existing beauty brand and trademark.
- Safnora: rejected after finding an existing home-goods store.
- Docryvia: preliminary exact string queries (`"Docryvia"`, Play Store search, trademark keyword) did not surface an identical brand in their returned search results. Similar-looking Senvia and Senuvia trademarks do exist. **Not cleared for registration.**

Working display title: **Docryvia — Your Private Digital Vault**. Google Play short-name limits and official Indian IP India trademark records must be checked manually, including phonetic variants in relevant classes (9, 42). Do not purchase a domain or apply for publication based solely on this preliminary research.
