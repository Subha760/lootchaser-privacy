# Current v0.6 additions

- Bounded 30-second session grace period for brief app switches; screen-off and manual lock still clear the session.
- Authenticated-session reuse for browser autofill and save confirmation.
- Optional favourite-food/first-school/nickname recovery question plus independent random rescue code. The question kit is consumed after successful recovery.
- New-password confirmation, prompt guards, device-unlock revocation on password changes/resets, preserved autofill metadata, and safer import deduplication.

See `V0_6_REVIEW.md` for current verification. The following earlier roadmap is historical; unimplemented items remain unimplemented.

# Feature list and roadmap

## Implemented in alpha source, but not verified in an Android build
- Five-slide welcome with Skip, progress dots and discreet crossfade; locally stored seen state
- Elegant light Material 3 visual language, soft blue/teal cards, trusted category navigation
- Home dashboard with counts, categories and quick actions
- Password list with search, password generator, add/edit/delete
- Document wallet, eleven categories, rename/delete/export, PDF/image/files imported through picker (max 8 MB)
- Identity, address, health, finance, vehicle, membership, travel/ticket and notes records
- Master-password encryption, 256-bit offline recovery key and rotation
- Fingerprint/eligible face and device lock quick unlock via Android Keystore
- System AutofillService HTTPS restricted fill and save confirmation for supported browsers
- Google Password Manager CSV import from system picker (limited size, plaintext warning)
- Password-encrypted ZIP export, import and local record merging
- Android system share of selected address, with explicit warning/confirmation and user choosing recipient
- Encrypted favorites and ISO expiry dates; in-vault due/expired visual labels, not notification reminders
- Encrypted ZIP export staged across file-picker background locking with destination read-back digest where permitted
- Encrypted item save/delete and selected heavy file operations dispatched off main thread
- Offline operation, app screen screenshot protection, background lock, no ads/analytics SDK

## Future work before public beta
- Android APK compile, structured Compose UI/instrumentation suite, benchmark profiles, API 28-35 compatibility grid
- Unicode/homograph and iframe-origin security tests; verified Android native-app associations
- Credential Manager (Android 14+) first-class password provider; passkey support after independent verification
- Device-change/biometric invalidation regression tests; secure save sheet improvements
- Large encrypted file streaming to avoid loading 8MB+ files into RAM; thumbnail extraction only after unlock
- Background expiry notification reminders (not implemented); import preview, dedup rules, duplicate-password merge prompts; delete/export undo and bin with secure erasure caveats
- Camera scanning with explicit permission; on-device OCR and offline AI classification only after privacy and model audits
- Encrypted TOTP generator, QR importer, offline metadata expiry reminders, password history with bounded retention
- Android Quick Settings tile, privacy-respecting app shortcuts and multiwindow/tablet navigation
- Scoped secure document share through short-lived FileProvider URI with explicit consent, not permanent plain exports
- Tamper/threat modeling and independent audit. No "unhackable" or "zero leak" claims.

> **v0.5 audit note (9 October 2026):** See `docs/V0_5_AUDIT_AND_CHANGES.md`. This is **source-level implementation only**; actual build/runtime security has not been established.
