# Deployment preference recorded from the user

Requested on 10 October 2026: use the Indus Appstore Release GitHub Action at https://github.com/marketplace/actions/indus-appstore-release for Docryvia deployments.

The current marketplace source is PhonePe/Indus-Flows. v1 resolves to d0b550922eff1366945ffe6137a44609752c6dc4. Use the verified signed APK and explicit package app.kavorynx.vault. Do not put private signing material or API tokens into tracked files. Indus uploads require INDUS_APP_STORE_API_TOKEN as a GitHub Actions secret and an existing registered app/listing; this action calls an upgrade endpoint. An upload is not proof of store review/publication.

This file records a project preference, not guaranteed cross-conversation assistant memory.
