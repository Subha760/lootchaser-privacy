# v0.6 session and recovery acceptance tests

Use synthetic data and retain encrypted backups. Device tests below are not claimed as executed.

1. Create a vault or update an existing v0.5 install using the same signing certificate. Verify old entries/backup imports still decrypt. Confirm installation retains data; never uninstall to upgrade.
2. Switch to another app/file picker for 10 seconds, return: the vault should remain unlocked. Switch for at least 30 seconds: it should require authentication. Repeat app/activity switches to check the deadline is not extended while fully in the background.
3. Turn the screen off, immediately turn it on and return: master/device authentication should be required. Manual lock should clear both main and autofill access. Check sleep/suspension lasting several minutes.
4. Open a supported browser’s matching HTTPS login form within the grace period. Choose the saved account without another master prompt. Verify different hostnames, subdomains, HTTP pages and ambiguous iframes are refused. With no matching login, show an empty result rather than another prompt.
5. Accept Android’s save confirmation with an unlocked vault: confirm without re-entering the master password. With a locked vault, require it. Update an existing account and verify notes/favourite/category/expiry remain intact.
6. Enable device unlock; repeat taps and cancel/background the prompt. Only one prompt should be active; no late callback may reopen the stopped app. Test strong fingerprint, eligible face and device credential on API 28/29 and 30+ devices.
7. In Settings create each question rescue kit; confirm answer and paper code groups. Lock the vault, reset with question + code and matching new-password fields. Check answer normalization, wrong answer, wrong code, truncated code, mismatched passwords and failed attempts preserving data.
8. On successful question recovery, the old master password, consumed question kit and previous device-unlock setup should fail. The new master password and unchanged main recovery key should still work. Create a fresh kit and re-enable device unlock.
9. Replace/disable the kit; verify the prior code stops working. Reset using the main recovery key; verify question recovery/device unlock are disabled. Ordinary password change also disables device unlock.
10. Exercise CSV import and backup merge with case-sensitive usernames, duplicates, malformed/truncated ZIPs, wrong passphrases, file-provider denial, process death, background interruptions and large documents.
11. Review accessibility, screen reader, keyboard insets, Android 16 edge-to-edge, tablet/multiwindow and low-memory behavior. Check that legal/operator information is complete before any public listing.

The earlier test plan below is historical and remains useful for broader feature coverage.

# Device and website verification matrix (NOT YET EXECUTED)

No external services, fake users or live passwords may be used in tests without explicit permission. Create disposable accounts and sample documents only.

| Case | Pass criteria |
|---|---|
| First launch | Five onboarding slides, Skip works, creates vault and recovery key appears once |
| Recovery | Wrong key fails; correct key can reset password; lost both cannot decrypt |
| Biometric | Eligible strong sensor prompts; cancellation leaves locked; insecure sensor never bypasses |
| Device lock | PIN/pattern allowed only on supported Android 11+ | 
| Login forms | Saved exact hostname fills after unlock; wrong hostname refuses |
| HTTP site | `http://example.com` cannot trigger HTTPS autofill or save |
| Unicode domain | punycode normalization and spoofing review needed |
| Browser popup | Android controls its presentation; Save UI shown on compatible fields after changes |
| Password save | Accept Android Save UI, confirm in-app, verify encrypted record persists |
| Password changes | Account overwrite tested, no unintended other-account overwrite |
| App switch | `onStop` locks the vault; background screen snapshot suppressed |
| Documents | PDF, JPG, large file refusal, categories persist, all exports require explicit target |
| CSV import | UTF-8 quoted values, malformed file rejected; imported passwords encrypted |
| Backups | Wrong password, modified cipher, and damaged ZIP rejected |
| Phones | Android 9/10/11/12/13/14/15, 3GB+ RAM, dynamic text scaling, dark system mode |
| Performance | Measured startup, unlock and scroll frame times on entry-level physical phones |
| Stores | Privacy policy truthfulness, Data Safety, signing, latest API target, accessibility |

Set up Android Benchmark/Macrobenchmark and record frame-time histograms and crash rates before claiming "no lag". This file is a plan and does not assert that tests have run.
