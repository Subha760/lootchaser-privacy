# No blanket class retention: keep code shrinking enabled in release builds.
