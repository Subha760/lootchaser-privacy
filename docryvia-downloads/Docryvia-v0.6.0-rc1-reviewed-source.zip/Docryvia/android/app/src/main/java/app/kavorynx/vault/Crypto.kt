package app.kavorynx.vault

import java.util.Base64
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Crypto is versioned and independently authenticated. No plaintext secrets are logged. */
object Crypto {
    private const val ITERATIONS = 600_000
    private const val KEY_BYTES = 32
    private val random = SecureRandom()
    fun randomBytes(size: Int) = ByteArray(size).also(random::nextBytes)
    fun b64(value: ByteArray): String = Base64.getEncoder().encodeToString(value)
    fun unb64(value: String): ByteArray = Base64.getDecoder().decode(value)

    fun pbkdf2(passphrase: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(passphrase, salt, ITERATIONS, KEY_BYTES * 8)
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    // An authenticated envelope, IV prepended to ciphertext + GCM tag. 12-byte random IV per encryption.
    fun seal(key: ByteArray, data: ByteArray, domain: String): ByteArray {
        require(key.size == KEY_BYTES)
        val iv = randomBytes(12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(domain.toByteArray(Charsets.UTF_8))
        return iv + cipher.doFinal(data)
    }

    fun open(key: ByteArray, packed: ByteArray, domain: String): ByteArray {
        require(key.size == KEY_BYTES && packed.size >= 28)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, packed.copyOfRange(0, 12)))
        cipher.updateAAD(domain.toByteArray(Charsets.UTF_8))
        return cipher.doFinal(packed.copyOfRange(12, packed.size))
    }

    fun wrapByPassword(password: CharArray, dek: ByteArray): String {
        val salt = randomBytes(16)
        val kek = pbkdf2(password, salt)
        return try { b64(salt + seal(kek, dek, "kavorynx:master:v1")) }
        finally { kek.fill(0) }
    }
    fun unwrapByPassword(password: CharArray, envelope: String): ByteArray {
        val bytes = unb64(envelope)
        require(bytes.size >= 16 + 28)
        val kek = pbkdf2(password, bytes.copyOfRange(0, 16))
        return try { open(kek, bytes.copyOfRange(16, bytes.size), "kavorynx:master:v1") }
        finally { kek.fill(0) }
    }

    // Recovery token contains 256 random bits: no expensive password KDF necessary.
    // Domain-separated SHA-256 protects against using the raw token directly as an encryption key.
    fun recoveryKey(token: ByteArray): ByteArray {
        require(token.size == 32)
        return MessageDigest.getInstance("SHA-256")
            .digest("kavorynx:recovery:v1".toByteArray() + token)
    }
    fun printRecoveryToken(token: ByteArray): String = token.joinToString("") { "%02X".format(it.toInt() and 255) }
        .chunked(8).joinToString("-")
    fun parseRecoveryToken(value: String): ByteArray {
        val compact = value.filterNot { it == '-' || it.isWhitespace() }
        require(compact.length == 64 && compact.all { it in "0123456789abcdefABCDEF" })
        return ByteArray(32) { compact.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** Independent authenticated offline export; no unencrypted secrets inside the ZIP. */
    fun exportPayload(passphrase: CharArray, json: ByteArray): ByteArray {
        val salt = randomBytes(16)
        val kek = pbkdf2(passphrase, salt)
        return try { "KVX1".toByteArray() + salt + seal(kek, json, "kavorynx:export:v1") }
        finally { kek.fill(0) }
    }
    fun importPayload(passphrase: CharArray, packed: ByteArray): ByteArray {
        require(packed.size > 48 && String(packed.copyOfRange(0, 4)) == "KVX1")
        val kek = pbkdf2(passphrase, packed.copyOfRange(4, 20))
        return try { open(kek, packed.copyOfRange(20, packed.size), "kavorynx:export:v1") }
        finally { kek.fill(0) }
    }

    fun generatePassword(length: Int = 24): String {
        require(length in 12..128)
        val alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#%^&*_-+=?"
        return buildString { repeat(length) { append(alphabet[random.nextInt(alphabet.length)]) } }
    }
}
