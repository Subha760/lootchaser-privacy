package app.kavorynx.vault

import java.net.URI
import java.net.IDN
import java.util.Locale

/** Prefer false negatives over phishing: NO suffix, substring or fuzzy matching. */
object DomainPolicy {
    fun canonicalHost(url: String): String? {
        val uri = try { URI(url.trim()) } catch (_: Exception) { return null }
        if (uri.scheme?.lowercase(Locale.ROOT) != "https") return null
        if (uri.userInfo != null || (uri.port != -1 && uri.port != 443)) return null
        if (uri.rawUserInfo != null || uri.rawAuthority.isNullOrBlank()) return null
        val host = uri.host ?: return null
        return try {
            val result = IDN.toASCII(host.trimEnd('.').lowercase(Locale.ROOT))
            if (result.isBlank() || result.length > 253 || !result.contains('.') ||
                result.split('.').any { part -> part.isEmpty() || part.length > 63 ||
                    part.startsWith('-') || part.endsWith('-') || !part.all { it.isLetterOrDigit() || it == '-' } }) null
            else result
        } catch (_: Exception) { null }
    }
    // The base-URL domain must match EXACTLY. Subdomains require their own saved entry.
    fun matches(savedUrl: String, requestedUrl: String): Boolean =
        canonicalHost(savedUrl) != null && canonicalHost(savedUrl) == canonicalHost(requestedUrl)
}
