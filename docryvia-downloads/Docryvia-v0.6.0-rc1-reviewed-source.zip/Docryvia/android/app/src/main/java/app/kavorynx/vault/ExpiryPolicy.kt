package app.kavorynx.vault

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Pure local expiry calculations. Document titles and identifiers are never included in alarms. */
enum class ExpiryState { NONE, UPCOMING, EXPIRED, VALID }

object ExpiryPolicy {
    fun validate(isoDate: String): Boolean = isoDate.isBlank() ||
        runCatching { LocalDate.parse(isoDate) }.isSuccess

    fun status(isoDate: String, today: LocalDate = LocalDate.now()): ExpiryState {
        val date = runCatching { LocalDate.parse(isoDate) }.getOrNull() ?: return ExpiryState.NONE
        val days = ChronoUnit.DAYS.between(today, date)
        return when {
            days < 0L -> ExpiryState.EXPIRED
            days <= 30L -> ExpiryState.UPCOMING
            else -> ExpiryState.VALID
        }
    }
}
