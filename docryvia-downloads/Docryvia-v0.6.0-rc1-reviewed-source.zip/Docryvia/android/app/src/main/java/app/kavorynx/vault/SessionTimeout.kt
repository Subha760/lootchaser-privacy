package app.kavorynx.vault

/** A bounded grace period for file pickers and switching to a browser. Monotonic clock only. */
class SessionTimeout(private val graceMillis: Long = 30_000L) {
    private var backgroundAt: Long? = null
    fun background(now: Long) { if (backgroundAt == null) backgroundAt = now }
    fun expired(now: Long): Boolean = backgroundAt?.let { now - it >= graceMillis } ?: false
    fun foreground(now: Long): Boolean {
        val expired = expired(now); backgroundAt = null; return expired
    }
}
