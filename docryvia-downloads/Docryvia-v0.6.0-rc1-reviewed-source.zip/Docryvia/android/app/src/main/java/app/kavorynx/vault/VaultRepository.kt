package app.kavorynx.vault

import android.content.Context
import android.util.AtomicFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

const val TYPE_PASSWORD = "Password"
const val TYPE_ADDRESS = "Address"
const val TYPE_TRAVEL = "Travel"
const val TYPE_NOTE = "Note"
const val TYPE_DOCUMENT = "Document"
const val TYPE_IDENTITY = "Identity"
const val TYPE_TICKET = "Ticket"
const val TYPE_MEMBERSHIP = "Membership"
const val TYPE_FINANCE = "Finance"
const val TYPE_HEALTH = "Health"
const val TYPE_VEHICLE = "Vehicle"


/** Secrets (including metadata such as titles and URLs) live only inside the encrypted blob. */
data class VaultItem(
    val id: String = UUID.randomUUID().toString(),
    val type: String = TYPE_PASSWORD,
    val title: String = "",
    val site: String = "",
    val username: String = "",
    val secret: String = "",
    val notes: String = "",
    val fileName: String = "",
    val mime: String = "",
    val fileData: String = "",
    val created: Long = System.currentTimeMillis(),
    val category: String = "General",
    val favorite: Boolean = false,
    val expiryDate: String = "" // ISO 8601 yyyy-MM-dd, encrypted with the vault
) {
    fun json(): JSONObject = JSONObject().put("id", id).put("type", type)
        .put("title", title).put("site", site).put("username", username)
        .put("secret", secret).put("notes", notes).put("fileName", fileName)
        .put("mime", mime).put("fileData", fileData).put("created", created).put("category", category)
        .put("favorite", favorite).put("expiryDate", expiryDate)
    companion object {
        fun from(o: JSONObject): VaultItem = VaultItem(
            o.getString("id"), o.optString("type", TYPE_PASSWORD), o.optString("title"),
            o.optString("site"), o.optString("username"), o.optString("secret"),
            o.optString("notes"), o.optString("fileName"), o.optString("mime"),
            o.optString("fileData"), o.optLong("created", System.currentTimeMillis()),
            o.optString("category", "General"), o.optBoolean("favorite", false),
            o.optString("expiryDate", "")
        )
    }
}

class VaultRepository(context: Context) {
    private val prefs = context.getSharedPreferences("kavorynx_config", Context.MODE_PRIVATE)
    private val data = AtomicFile(File(context.filesDir, "secure_vault.dat"))
    fun exists(): Boolean = prefs.contains("master")
    fun hasDeviceUnlock(): Boolean = prefs.contains("device_wrap")
    fun readDeviceWrap(): String = prefs.getString("device_wrap", "") ?: ""
    fun saveDeviceWrap(value: String) { check(prefs.edit().putString("device_wrap", value).commit()) }
    fun removeDeviceWrap() { check(prefs.edit().remove("device_wrap").commit()) }

    @Synchronized fun create(password: CharArray): Pair<ByteArray, String> {
        check(!exists()) { "Vault already exists" }
        require(password.size >= 12) { "Use at least 12 characters" }
        val dek = Crypto.randomBytes(32)
        val recovery = Crypto.randomBytes(32)
        val wrapKey = Crypto.recoveryKey(recovery)
        try {
            val masterWrap = Crypto.wrapByPassword(password, dek)
            val recoverWrap = Crypto.b64(Crypto.seal(wrapKey, dek, "kavorynx:recovery-wrap:v1"))
            write(dek, emptyList())
            check(prefs.edit().putString("master", masterWrap).putString("recover", recoverWrap).commit())
            return dek to Crypto.printRecoveryToken(recovery)
        } catch (t: Throwable) { dek.fill(0); throw t }
        finally { recovery.fill(0); wrapKey.fill(0) }
    }
    fun unlock(password: CharArray): ByteArray {
        val dek = Crypto.unwrapByPassword(password, prefs.getString("master", null) ?: error("Not initialized"))
        try { require(dek.size == 32); read(dek); return dek }
        catch (t: Throwable) { dek.fill(0); throw t }
    }
    fun recoveryQuestion(): String? = prefs.getString("question_id", null)
        ?.takeIf { it in QuestionRecovery.questions && prefs.contains("question_wrap") }
    @Synchronized fun setupQuestionRecovery(dek: ByteArray, question: String, answer: CharArray): String {
        read(dek)
        val token = Crypto.randomBytes(32)
        try {
            val code = Crypto.printRecoveryToken(token)
            val envelope = QuestionRecovery.seal(question, answer, code, dek)
            check(prefs.edit().putString("question_id", question).putString("question_wrap", envelope).commit())
            return code
        } finally { token.fill(0) }
    }
    @Synchronized fun removeQuestionRecovery() {
        check(prefs.edit().remove("question_id").remove("question_wrap").commit())
    }
    @Synchronized fun resetWithQuestion(answer: CharArray, rescueCode: String, newPassword: CharArray): ByteArray {
        require(newPassword.size >= 12)
        val question = recoveryQuestion() ?: error("Question recovery is not enabled")
        val dek = QuestionRecovery.open(question, answer, rescueCode, prefs.getString("question_wrap", "")!!)
        try {
            read(dek)
            // Commit new password, consume rescue kit and revoke quick unlock together.
            check(prefs.edit().putString("master", Crypto.wrapByPassword(newPassword, dek))
                .remove("question_id").remove("question_wrap").remove("device_wrap").commit())
            return dek
        } catch (t: Throwable) { dek.fill(0); throw t }
    }
    @Synchronized fun resetPassword(token: String, newPassword: CharArray): ByteArray {
        require(newPassword.size >= 12)
        val recovery = Crypto.parseRecoveryToken(token)
        val key = Crypto.recoveryKey(recovery)
        recovery.fill(0)
        val dek = try { Crypto.open(key, Crypto.unb64(prefs.getString("recover", "")!!), "kavorynx:recovery-wrap:v1") }
            finally { key.fill(0) }
        try {
            read(dek) // Invalid/corrupt vault must not be silently overwritten.
            check(prefs.edit().putString("master", Crypto.wrapByPassword(newPassword, dek))
                .remove("device_wrap").remove("question_id").remove("question_wrap").commit())
            return dek
        } catch (t: Throwable) { dek.fill(0); throw t }
    }
    @Synchronized fun rotateRecovery(dek: ByteArray): String {
        read(dek)
        val token = Crypto.randomBytes(32)
        val wrapKey = Crypto.recoveryKey(token)
        try {
            val wrapped = Crypto.b64(Crypto.seal(wrapKey, dek, "kavorynx:recovery-wrap:v1"))
            check(prefs.edit().putString("recover", wrapped).commit())
            return Crypto.printRecoveryToken(token)
        } finally { token.fill(0); wrapKey.fill(0) }
    }
    @Synchronized fun changePassword(dek: ByteArray, newPassword: CharArray) {
        require(newPassword.size >= 12); read(dek)
        check(prefs.edit().putString("master", Crypto.wrapByPassword(newPassword, dek)).remove("device_wrap").commit())
    }
    @Synchronized fun read(dek: ByteArray): List<VaultItem> {
        val payload = data.openRead().use { it.readBytes() }
        val plaintext = Crypto.open(dek, payload, "kavorynx:vault:v1")
        val json = try { JSONObject(String(plaintext, Charsets.UTF_8)) }
            finally { plaintext.fill(0) }
        require(json.getInt("version") == 1)
        val items = json.getJSONArray("items")
        return (0 until items.length()).map { VaultItem.from(items.getJSONObject(it)) }
    }
    @Synchronized fun write(dek: ByteArray, entries: List<VaultItem>) {
        val arr = JSONArray(); entries.forEach { arr.put(it.json()) }
        val plaintext = JSONObject().put("version", 1).put("items", arr).toString().toByteArray(Charsets.UTF_8)
        val encrypted = try { Crypto.seal(dek, plaintext, "kavorynx:vault:v1") }
            finally { plaintext.fill(0) }
        val stream = data.startWrite()
        try { stream.write(encrypted); data.finishWrite(stream) }
        catch (t: Throwable) { data.failWrite(stream); throw t }
    }

    /** Backup includes only encrypted data and a version label; user selects destination via Storage Access Framework. */
    fun makeEncryptedZip(dek: ByteArray, passphrase: CharArray): ByteArray {
        require(passphrase.size >= 12) { "Backup passphrase must have 12+ characters" }
        val items = read(dek)
        val arr = JSONArray(); items.forEach { arr.put(it.json()) }
        val plaintext = JSONObject().put("version", 1).put("items", arr).toString().toByteArray()
        val cipherBytes = try { Crypto.exportPayload(passphrase, plaintext) }
            finally { plaintext.fill(0) }
        return ByteArrayOutputStream().also { out ->
            ZipOutputStream(out).use { zip ->
                zip.putNextEntry(ZipEntry("encrypted-vault.kvx"))
                zip.write(cipherBytes); zip.closeEntry()
                zip.putNextEntry(ZipEntry("README.txt"))
                zip.write("Docryvia encrypted backup v1. Never share your backup passphrase.".toByteArray())
                zip.closeEntry()
            }
        }.toByteArray()
    }
    fun readEncryptedZip(zipBytes: ByteArray, passphrase: CharArray): List<VaultItem> {
        require(zipBytes.size <= 100 * 1024 * 1024) { "Backup is too large" }
        var encrypted: ByteArray? = null
        val seen = mutableSetOf<String>()
        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zip ->
            var count = 0
            var entry = zip.nextEntry
            while (entry != null) {
                count++
                require(count <= 2 && entry.name in setOf("encrypted-vault.kvx", "README.txt") && seen.add(entry.name)) {
                    "Unexpected or duplicate backup entry"
                }
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                val limit = if (entry.name == "encrypted-vault.kvx") 80 * 1024 * 1024 else 2048
                while (true) {
                    val n = zip.read(buffer)
                    if (n < 0) break
                    require(out.size() + n <= limit) { "Backup entry too large" }
                    out.write(buffer, 0, n)
                }
                if (entry.name == "encrypted-vault.kvx") {
                    require(encrypted == null) { "Duplicate backup payload" }
                    encrypted = out.toByteArray()
                }
                zip.closeEntry(); entry = zip.nextEntry
            }
        }
        val plaintext = Crypto.importPayload(passphrase, encrypted ?: error("Not a Docryvia-compatible backup"))
        val root = try { JSONObject(String(plaintext, Charsets.UTF_8)) }
            finally { plaintext.fill(0) }
        require(root.getInt("version") == 1)
        val arr = root.getJSONArray("items")
        require(arr.length() <= 20_000)
        return (0 until arr.length()).map { VaultItem.from(arr.getJSONObject(it)) }
    }
}
