package app.kavorynx.vault

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** On API 30+ the system supports strong biometrics OR the device PIN/pattern/password.
 *  On API 28-29 only strong biometrics can unwrap the Keystore key; master password is fallback.
 *  'Weak' 2D face recognition is deliberately unsupported for vault decryption.
 */
class DeviceUnlock(private val repo: VaultRepository) {
    private var authenticating = false
    private val alias = "kavorynx_keystore_auth_v1"
    private fun flags(): Int = BiometricManager.Authenticators.BIOMETRIC_STRONG or
        (if (Build.VERSION.SDK_INT >= 30) BiometricManager.Authenticators.DEVICE_CREDENTIAL else 0)
    fun available(activity: FragmentActivity): Boolean =
        BiometricManager.from(activity).canAuthenticate(flags()) == BiometricManager.BIOMETRIC_SUCCESS

    private fun readKey(): SecretKey? =
        (KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.getKey(alias, null) as? SecretKey)

    fun enable(activity: FragmentActivity, onResult: (Boolean, String) -> Unit) {
        if (authenticating) return
        if (!available(activity)) { onResult(false, "Set up a strong biometric or supported device lock in Android settings"); return }
        val dek = try { VaultSession.rawKeyForBiometricSetup() }
        catch (t: Exception) { onResult(false, "Unlock the vault first"); return }
        try {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= 30) {
                spec.setUserAuthenticationParameters(0,
                    KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL)
            } else {
                spec.setUserAuthenticationValidityDurationSeconds(-1)
            }
            keyGenerator.init(spec.build()); val key = keyGenerator.generateKey()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            prompt(activity, cipher, "Enable quick unlock", onFailure = { reason ->
                dek.fill(0)
                onResult(false, reason)
            }) { authenticated ->
                try {
                    val packed = authenticated.iv + authenticated.doFinal(dek)
                    repo.saveDeviceWrap(Crypto.b64(packed))
                    onResult(true, "Quick unlock enabled")
                } catch (t: Exception) { onResult(false, "Could not enable unlock") }
                finally { dek.fill(0) }
            }
        } catch (t: Exception) { dek.fill(0); onResult(false, "Keystore setup failed or was cancelled") }
    }

    fun disable() {
        // Unwrap material is deleted first; deleting the Keystore alias further reduces attack surface.
        repo.removeDeviceWrap()
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (store.containsAlias(alias)) store.deleteEntry(alias)
    }

    fun unlock(activity: FragmentActivity, onResult: (Boolean, String) -> Unit) {
        if (authenticating) return
        if (!repo.hasDeviceUnlock()) { onResult(false, "Enable quick unlock in Settings first"); return }
        if (!available(activity)) { onResult(false, "Biometric/device credential not available; use master password"); return }
        try {
            val key = readKey() ?: throw IllegalStateException("Keystore key missing")
            val packed = Crypto.unb64(repo.readDeviceWrap())
            require(packed.size >= 28)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, packed.copyOfRange(0, 12)))
            prompt(activity, cipher, "Unlock Docryvia", onFailure = { reason ->
                onResult(false, reason)
            }) { authenticated ->
                try {
                    val dek = authenticated.doFinal(packed.copyOfRange(12, packed.size))
                    if (activity.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) && !activity.isFinishing) {
                        VaultSession.start(dek, repo)
                        onResult(true, "Vault unlocked")
                    } else { dek.fill(0); onResult(false, "Unlock cancelled after leaving app") }
                } catch (t: Exception) { onResult(false, "Quick unlock failed; use master password") }
            }
        } catch (t: Exception) {
            if (t is KeyPermanentlyInvalidatedException) {
                try { disable() } catch (_: Exception) { /* already invalidated */ }
            }
            onResult(false, "Device credential changed or unavailable; use master password")
        }
    }

    private fun prompt(activity: FragmentActivity, cipher: Cipher, title: String,
        onFailure: (String) -> Unit, onSuccess: (Cipher) -> Unit) {
        if (authenticating) { onFailure("Authentication already in progress"); return }
        authenticating = true
        var terminal = false
        var observer: LifecycleEventObserver? = null
        fun complete(): Boolean {
            if (terminal) return false
            terminal = true; authenticating = false
            observer?.let { activity.lifecycle.removeObserver(it) }
            return true
        }
        val config = BiometricPrompt.PromptInfo.Builder().setTitle(title)
            .setSubtitle("Your secrets never leave this device")
            .setAllowedAuthenticators(flags())
        if (Build.VERSION.SDK_INT < 30) config.setNegativeButtonText("Use master password")
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    if (!complete()) return
                    val confirmedCipher = result.cryptoObject?.cipher
                    if (confirmedCipher == null) onFailure("Authentication method unavailable; use master password")
                    else onSuccess(confirmedCipher)
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // Cancellation/error is terminal; do not leave pending key material in RAM.
                    if (complete()) onFailure("Quick unlock cancelled or unavailable; use master password")
                }
            })
        observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && complete()) {
                prompt.cancelAuthentication()
                onFailure("Quick unlock cancelled after leaving app")
            }
        }
        activity.lifecycle.addObserver(observer!!)
        try { prompt.authenticate(config.build(), BiometricPrompt.CryptoObject(cipher)) }
        catch (t: Exception) { if (complete()) onFailure("Quick unlock unavailable") }
    }
}
