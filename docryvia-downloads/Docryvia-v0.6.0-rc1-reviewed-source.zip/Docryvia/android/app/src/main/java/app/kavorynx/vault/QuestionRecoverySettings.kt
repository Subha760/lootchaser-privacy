package app.kavorynx.vault

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun QuestionRecoverySettings(enabled: Boolean, busy: Boolean,
    onSetup: (String, String) -> Unit, onDisable: () -> Unit) {
    var question by remember { mutableStateOf("food") }
    var answer by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var warningAccepted by remember { mutableStateOf(false) }
    var confirmDisable by remember { mutableStateOf(false) }
    Text("Question recovery", style = MaterialTheme.typography.titleMedium)
    Text(if (enabled) "Enabled. A new kit replaces your previous question rescue code."
        else "Optional: select a question and save a separate rescue code.")
    Text("Common answers are easy to guess. Recovery requires BOTH your answer and a separate random code. Keep the code offline, away from your answer.",
        style = MaterialTheme.typography.bodySmall)
    QuestionRecovery.questions.forEach { (id, label) ->
        FilterChip(selected = question == id, enabled = !busy, onClick = { question = id }, label = { Text(label) })
    }
    OutlinedTextField(answer, { answer = it.take(200) }, label = { Text("Answer (2–200 characters)") },
        singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
    OutlinedTextField(confirm, { confirm = it.take(200) }, label = { Text("Confirm answer") },
        singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
    Row {
        Checkbox(warningAccepted, { warningAccepted = it })
        Text("I will save the separate rescue code offline.", modifier = Modifier.padding(top = 12.dp))
    }
    OutlinedButton(enabled = !busy && warningAccepted && answer.trim().length >= 2 && answer == confirm,
        onClick = { onSetup(question, answer); answer = ""; confirm = ""; warningAccepted = false }) {
        Text(if (enabled) "Replace question rescue kit" else "Create question rescue kit")
    }
    if (enabled) TextButton(enabled = !busy, onClick = { confirmDisable = true }) { Text("Disable question recovery") }
    if (confirmDisable) AlertDialog(onDismissRequest = { confirmDisable = false },
        title = { Text("Disable question recovery?") },
        text = { Text("Your question rescue code will stop working. Your main recovery key remains valid.") },
        confirmButton = { TextButton(onClick = { confirmDisable = false; onDisable() }) { Text("Disable") } },
        dismissButton = { TextButton(onClick = { confirmDisable = false }) { Text("Cancel") } })
}
