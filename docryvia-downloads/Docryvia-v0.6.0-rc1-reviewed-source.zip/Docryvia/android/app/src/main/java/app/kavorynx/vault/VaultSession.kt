package app.kavorynx.vault

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** RAM-only session: no secret is stored in SavedStateHandle, Intents, logs or SharedPreferences. */
object VaultSession {
    private var dek: ByteArray? = null
    var items by mutableStateOf<List<VaultItem>>(emptyList()); private set
    var unlocked by mutableStateOf(false); private set
    @Synchronized fun start(key: ByteArray, repo: VaultRepository) {
        try {
            val loaded = repo.read(key)
            lock()
            dek = key.copyOf()
            items = loaded
            unlocked = true
        } finally { key.fill(0) }
    }
    @Synchronized fun accountsForHost(host: String): List<VaultItem> {
        check(dek != null && unlocked) { "Vault locked" }
        return items.filter { it.type == TYPE_PASSWORD && DomainPolicy.matches(it.site, "https://$host") }
    }
    @Synchronized fun save(item: VaultItem, repo: VaultRepository) {
        val key = dek ?: error("Vault locked")
        val next = items.filterNot { it.id == item.id } + item
        repo.write(key, next); items = next
    }
    @Synchronized fun confirmAndSaveLogin(repo: VaultRepository, password: CharArray,
        host: String, username: String, secret: String) {
        val sessionKey = dek
        val key = sessionKey ?: repo.unlock(password)
        try {
            val latest = repo.read(key)
            val existing = latest.firstOrNull { it.type == TYPE_PASSWORD && it.username == username &&
                DomainPolicy.matches(it.site, "https://$host") }
            val record = existing?.copy(secret = secret) ?: VaultItem(type = TYPE_PASSWORD,
                title = host, site = "https://$host", username = username, secret = secret)
            val next = latest.filterNot { it.id == record.id } + record
            repo.write(key, next)
            if (sessionKey != null) items = next
        } finally { if (sessionKey == null) key.fill(0) }
    }
    @Synchronized fun remove(id: String, repo: VaultRepository) {
        val key = dek ?: error("Vault locked")
        val next = items.filterNot { it.id == id }
        repo.write(key, next); items = next
    }
    @Synchronized fun changePassword(repo: VaultRepository, password: CharArray) {
        repo.changePassword(dek ?: error("Vault locked"), password)
    }
    @Synchronized fun rotateRecovery(repo: VaultRepository): String =
        repo.rotateRecovery(dek ?: error("Vault locked"))
    @Synchronized fun setupQuestionRecovery(repo: VaultRepository, question: String, answer: CharArray): String =
        repo.setupQuestionRecovery(dek ?: error("Vault locked"), question, answer)
    @Synchronized fun removeQuestionRecovery(repo: VaultRepository) {
        check(dek != null) { "Vault locked" }; repo.removeQuestionRecovery()
    }
    @Synchronized fun export(repo: VaultRepository, passphrase: CharArray): ByteArray =
        repo.makeEncryptedZip(dek ?: error("Vault locked"), passphrase)
    @Synchronized fun import(repo: VaultRepository, imported: List<VaultItem>) {
        val key = dek ?: error("Vault locked")
        // Merge by ID; existing data is retained. All writes are authenticated and atomic.
        val originalIds = items.map { it.id }.toSet()
        fun loginIdentity(item: VaultItem) = Triple(
            DomainPolicy.canonicalHost(item.site) ?: item.site.trim(), item.username.trim(), item.secret)
        val knownLogins = items.filter { it.type == TYPE_PASSWORD }.map(::loginIdentity).toSet()
        val newEntries = imported.filterNot { it.id in originalIds ||
            (it.type == TYPE_PASSWORD && loginIdentity(it) in knownLogins)
        }.distinctBy { it.id }.distinctBy {
            if (it.type == TYPE_PASSWORD) listOf(it.type, loginIdentity(it).first, it.username.trim(), it.secret)
            else listOf(it.type, it.id)
        }
        val unique = items + newEntries
        repo.write(key, unique); items = unique
    }
    @Synchronized fun rawKeyForBiometricSetup(): ByteArray = (dek ?: error("Vault locked")).copyOf()
    @Synchronized fun lock() {
        dek?.fill(0); dek = null
        items = emptyList(); unlocked = false
    }
}
