package app.kavorynx.vault

import androidx.compose.ui.text.input.PasswordVisualTransformation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** This theme is intentionally independent of DigiLocker, UMANG and Google Wallet branding. */
internal val ink = Color(0xFF142940)
internal val ocean = Color(0xFF1766C5)
internal val teal = Color(0xFF0B887D)
internal val soft = Color(0xFFF4F7FB)
internal val subtle = Color(0xFF65788D)
internal val outline = Color(0xFFE3EAF1)

@Composable
fun SenviyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = ocean, onPrimary = Color.White, secondary = teal,
            surface = Color.White, onSurface = ink, background = soft,
            onBackground = ink, surfaceVariant = Color(0xFFEAF1F8),
            onSurfaceVariant = subtle, outline = outline,
            error = Color(0xFFAF3939)
        ),
        typography = Typography(
            headlineMedium = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            titleLarge = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            titleMedium = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
        ), content = content
    )
}

private data class IntroPage(val icon: ImageVector, val title: String, val description: String, val foot: String)
private val introSlides = listOf(
    IntroPage(Icons.Outlined.Shield, "A safe place for your digital life", "Save your passwords, private notes, IDs and documents in one encrypted space.", "PRIVATE BY DESIGN"),
    IntroPage(Icons.Outlined.Fingerprint, "Access that feels effortless", "Unlock with your master password, or enable your phone's supported fingerprint, face or screen lock.", "YOU CHOOSE HOW TO UNLOCK"),
    IntroPage(Icons.Outlined.AutoAwesome, "Your details, ready when you need them", "Android can suggest saved logins on supported sites. You verify the website and approve the fill.", "YOU ALWAYS STAY IN CONTROL"),
    IntroPage(Icons.Outlined.Folder, "Every important document, organised", "Create categories for IDs, education, medical papers, insurance, tickets and personal records.", "ON THIS DEVICE · OFFLINE"),
    IntroPage(Icons.Outlined.Backup, "You hold the recovery key", "Export an encrypted ZIP whenever you want. Without your master password or recovery key, nobody can unlock your vault.", "NO ACCOUNT OR SERVER REQUIRED")
)

@Composable
fun SenviyaIntro(onDone: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    val slide = introSlides[index]
    Column(Modifier.fillMaxSize().background(Color.White).padding(horizontal = 27.dp, vertical = 26.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BrandMark()
            Spacer(Modifier.width(11.dp))
            Column {
                Text("Docryvia", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = ink)
                Text("Private Documents & Passwords", style = MaterialTheme.typography.labelMedium, color = subtle)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onDone) { Text("Skip") }
        }
        Spacer(Modifier.weight(.7f))
        Box(Modifier.fillMaxWidth().height(245.dp), contentAlignment = Alignment.Center) {
            Surface(Modifier.size(215.dp), shape = RoundedCornerShape(54.dp),
                color = Color(0xFFE8F3FF), border = BorderStroke(1.dp, Color(0xFFDAE8F5))) {
                Box(contentAlignment = Alignment.Center) {
                    Surface(shape = RoundedCornerShape(39.dp), color = Color.White, shadowElevation = 9.dp) {
                        Icon(slide.icon, null, Modifier.padding(35.dp).size(90.dp), tint = ocean)
                    }
                }
            }
        }
        Spacer(Modifier.weight(.5f))
        AnimatedContent(targetState = slide, transitionSpec = {
            androidx.compose.animation.fadeIn(tween(220)) togetherWith androidx.compose.animation.fadeOut(tween(160))
        }, label = "intro") { it ->
            Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Text(it.foot, style = MaterialTheme.typography.labelMedium, color = teal, fontWeight = FontWeight.Bold)
                Text(it.title, fontSize = 29.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, color = ink)
                Text(it.description, fontSize = 16.sp, lineHeight = 25.sp, color = subtle)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                repeat(introSlides.size) { i ->
                    Box(Modifier.width(if (i == index) 23.dp else 7.dp).height(7.dp)
                        .clip(CircleShape).background(if (i == index) ocean else outline))
                }
            }
            Spacer(Modifier.weight(1f))
            Button(onClick = { if (index == introSlides.lastIndex) onDone() else index++ },
                shape = RoundedCornerShape(18.dp), contentPadding = PaddingValues(horizontal = 25.dp, vertical = 15.dp)) {
                Text(if (index == introSlides.lastIndex) "Get started" else "Continue")
                Spacer(Modifier.width(9.dp)); Icon(Icons.Default.ArrowForward, null, Modifier.size(17.dp))
            }
        }
    }
}

@Composable
fun BrandMark() {
    Surface(shape = RoundedCornerShape(14.dp), color = ocean, modifier = Modifier.size(45.dp)) {
        Box(contentAlignment = Alignment.Center) { Icon(Icons.Filled.Shield, "Docryvia shield", tint = Color.White, modifier = Modifier.size(27.dp)) }
    }
}

@Composable
fun SenviyaTopBar(count: Int, onLock: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        BrandMark(); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Docryvia", style = MaterialTheme.typography.titleLarge, color = ink)
            Text("Private Documents & Passwords", style = MaterialTheme.typography.labelMedium, color = subtle)
        }
        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE7F7F1)) {
            Text("OFFLINE", color = teal, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
        }
        IconButton(onClick = onLock) { Icon(Icons.Outlined.Lock, "Lock now", tint = ink) }
    }
}

private data class QuickCategory(val title: String, val detail: String, val icon: ImageVector, val tint: Color, val type: String)
private val categories = listOf(
    QuickCategory("Passwords", "Logins & accounts", Icons.Outlined.Key, Color(0xFF2366C4), TYPE_PASSWORD),
    QuickCategory("Documents", "Files & IDs", Icons.Outlined.Description, Color(0xFF0D8B7D), TYPE_DOCUMENT),
    QuickCategory("Addresses", "Delivery & home", Icons.Outlined.LocationOn, Color(0xFF985A3E), TYPE_ADDRESS),
    QuickCategory("Travel", "Tickets & trips", Icons.Outlined.FlightTakeoff, Color(0xFF6E52BB), TYPE_TICKET),
    QuickCategory("Identity", "Personal details", Icons.Outlined.Badge, Color(0xFFAF6450), TYPE_IDENTITY),
    QuickCategory("Private notes", "Things to remember", Icons.Outlined.EditNote, Color(0xFF188091), TYPE_NOTE)
)

@Composable
private fun SectionHeading(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth()) {
        Text(title, color = ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = subtle, modifier = Modifier.padding(top = 3.dp))
    }
}

@Composable
private fun InfoTile(icon: ImageVector, title: String, sub: String, accent: Color, modifier: Modifier = Modifier,
    onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(20.dp),
        color = Color.White, border = BorderStroke(1.dp, outline)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = accent.copy(alpha = .09f)) {
                Icon(icon, null, Modifier.padding(10.dp).size(23.dp), tint = accent)
            }
            Text(title, maxLines = 1, color = ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(sub, fontSize = 11.sp, color = subtle, maxLines = 1)
        }
    }
}

@Composable
fun SenviyaHome(entries: List<VaultItem>, onGo: (String) -> Unit, onAdd: (String) -> Unit, onPickDocument: () -> Unit) {
    val docCount = entries.count { it.type == TYPE_DOCUMENT }
    val passCount = entries.count { it.type == TYPE_PASSWORD }
    val favoriteCount = entries.count { it.favorite }
    val expiringCount = entries.count { ExpiryPolicy.status(it.expiryDate) == ExpiryState.UPCOMING }
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 26.dp)) {
        item {
            Text("Good to have everything together.", fontSize = 14.sp, color = subtle)
            Text("Your digital essentials", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = ink)
        }
        item {
            Surface(shape = RoundedCornerShape(25.dp), color = ink) {
                Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.VerifiedUser, null, tint = Color(0xFF96DAD8))
                        Spacer(Modifier.width(9.dp))
                        Text("Protected on this device", fontWeight = FontWeight.Medium, color = Color.White)
                    }
                    Text("One private place.\nA little less to worry about.", fontSize = 22.sp, lineHeight = 28.sp,
                        fontWeight = FontWeight.SemiBold, color = Color.White)
                    HorizontalDivider(color = Color.White.copy(alpha = .16f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("$passCount logins", color = Color.White.copy(alpha = .87f))
                        Spacer(Modifier.width(18.dp))
                        Text("$docCount documents", color = Color.White.copy(alpha = .87f))
                    }
                }
            }
        }
        if (expiringCount > 0 || favoriteCount > 0) item {
            Surface(shape = RoundedCornerShape(17.dp), color = Color(0xFFFFF8E9),
                border = BorderStroke(1.dp, Color(0xFFF0E4CC)), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.EventAvailable, "Expiry summary", tint = Color(0xFF9B621F))
                    Spacer(Modifier.width(12.dp))
                    Text("$expiringCount due in 30 days · $favoriteCount favorites",
                        color = ink, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item { SectionHeading("Explore your vault", "Find the right place for every detail") }
        items(categories.chunked(2)) { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { item ->
                    InfoTile(item.icon, item.title, item.detail, item.tint, Modifier.weight(1f)) {
                        when (item.type) {
                            TYPE_PASSWORD -> onGo("Passwords")
                            TYPE_DOCUMENT -> onGo("Documents")
                            TYPE_NOTE, TYPE_ADDRESS, TYPE_TICKET, TYPE_IDENTITY -> { onGo("Wallet"); onAdd(item.type) }
                            else -> onGo("Wallet")
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item { SectionHeading("Quick actions") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { onAdd(TYPE_PASSWORD) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Add login")
                }
                OutlinedButton(onClick = onPickDocument, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Outlined.UploadFile, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Add file")
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Info, null, tint = subtle, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Personal copies only. Not government-issued or verified documents.", fontSize = 11.sp, color = subtle)
            }
        }
    }
}

@Composable
fun SenviyaEntryCard(item: VaultItem, onSelect: () -> Unit) {
    val (icon, color) = when (item.type) {
        TYPE_PASSWORD -> Icons.Outlined.Language to ocean
        TYPE_DOCUMENT -> Icons.Outlined.InsertDriveFile to teal
        TYPE_TICKET, TYPE_TRAVEL -> Icons.Outlined.ConfirmationNumber to Color(0xFF7655AE)
        TYPE_ADDRESS -> Icons.Outlined.LocationOn to Color(0xFF9C6543)
        TYPE_IDENTITY -> Icons.Outlined.Badge to Color(0xFFBA6452)
        TYPE_NOTE -> Icons.Outlined.EditNote to Color(0xFF218B9F)
        else -> Icons.Outlined.Folder to ocean
    }
    Surface(onClick = onSelect, shape = RoundedCornerShape(17.dp), color = Color.White,
        border = BorderStroke(1.dp, outline), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(13.dp), color = color.copy(alpha = .09f)) {
                Icon(icon, null, Modifier.padding(11.dp).size(23.dp), tint = color)
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title.ifBlank { "Untitled ${item.type.lowercase()}" }, color = ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text((if (item.type == TYPE_DOCUMENT) item.category else item.username.ifBlank { item.site.ifBlank { item.type } }),
                    fontSize = 12.sp, color = subtle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (item.expiryDate.isNotBlank()) {
                    val status = ExpiryPolicy.status(item.expiryDate)
                    Text(when (status) {
                        ExpiryState.EXPIRED -> "Expired · ${item.expiryDate}"
                        ExpiryState.UPCOMING -> "Due soon · ${item.expiryDate}"
                        ExpiryState.VALID -> "Expires · ${item.expiryDate}"
                        ExpiryState.NONE -> "Expiry not available"
                    }, fontSize = 11.sp,
                        color = if (status == ExpiryState.EXPIRED || status == ExpiryState.UPCOMING)
                            Color(0xFFA8662A) else subtle)
                }
            }
            if (item.favorite) {
                Icon(Icons.Filled.Star, "Favorite", tint = Color(0xFFC89127), modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(6.dp))
            }
            Icon(Icons.Default.ChevronRight, null, tint = subtle, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
fun SenviyaPasswords(entries: List<VaultItem>, onSelect: (VaultItem) -> Unit, onAdd: () -> Unit, onGenerator: () -> Unit) {
    var filter by remember { mutableStateOf("") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp), modifier = Modifier.fillMaxSize()) {
        item { SectionHeading("Passwords & logins", "One-tap access on supported websites") }
        item {
            val passwords = entries.filter { it.type == TYPE_PASSWORD }
            val health = remember(passwords) {
                PasswordHealth.analyze(passwords.map { PasswordHealthInput(it.id, it.site, it.username, it.secret) })
            }
            Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFE7F3EF),
                border = BorderStroke(1.dp, Color(0xFFD6E8E0)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.VerifiedUser, null, tint = teal, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Private password health", color = ink, fontWeight = FontWeight.SemiBold)
                    }
                    Text("${health.total} saved · ${health.weak} potentially weak · ${health.reused} reused · ${health.duplicateAccounts} duplicate login entries",
                        fontSize = 12.sp, lineHeight = 18.sp, color = ink)
                    Text("Calculated only while unlocked. These checks don't prove a password is safe.", fontSize = 11.sp, color = subtle)
                }
            }
        }
        item { SearchField(filter, { filter = it }) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onAdd, shape = RoundedCornerShape(15.dp)) { Icon(Icons.Default.Add, null); Text("Save login") }
                OutlinedButton(onClick = onGenerator, shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Generator")
                }
            }
        }
        val shown = entries.filter { it.type == TYPE_PASSWORD && listOf(it.title, it.site, it.username).any { value -> value.contains(filter, ignoreCase = true) } }
        if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Key, "No logins found", "Add a login to keep its username and password protected.") }
        items(shown, key = { it.id }) { item -> SenviyaEntryCard(item) { onSelect(item) } }
    }
}

@Composable
private fun SearchField(value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text("Search securely", color = subtle) },
        leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
        shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = outline))
}

val documentCategories = listOf("All", "Identity", "Education", "Health", "Finance", "Insurance", "Vehicle", "Travel", "Property", "Work", "Family", "Other")

@Composable
fun SenviyaDocuments(entries: List<VaultItem>, onSelect: (VaultItem) -> Unit, onPick: (String) -> Unit) {
    var selected by remember { mutableStateOf("All") }
    var filter by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(top = 16.dp)) {
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionHeading("Document wallet", "Your important files, neatly organised")
            SearchField(filter) { filter = it }
            Button(onClick = { onPick(if (selected == "All") "Other" else selected) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Encrypt & add document")
            }
            Text("CATEGORIES", color = subtle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(9.dp))
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(documentCategories) { category ->
                FilterChip(selected = selected == category, onClick = { selected = category },
                    label = { Text(category) }, shape = RoundedCornerShape(12.dp))
            }
        }
        val shown = entries.filter { it.type == TYPE_DOCUMENT && (selected == "All" || it.category.equals(selected, true)) &&
            it.title.contains(filter, ignoreCase = true) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 15.dp)) {
            item { Text("${shown.size} document${if (shown.size == 1) "" else "s"}", fontSize = 12.sp, color = subtle) }
            if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Description, "Nothing in ${selected.lowercase()} yet", "Add a PDF or image securely from your phone.") }
            items(shown, key = { it.id }) { item -> SenviyaEntryCard(item) { onSelect(item) } }
        }
    }
}

@Composable
fun SenviyaWallet(entries: List<VaultItem>, onSelect: (VaultItem) -> Unit, onAdd: (String) -> Unit) {
    var selected by remember { mutableStateOf("All") }
    val types = listOf("All", TYPE_ADDRESS, TYPE_IDENTITY, TYPE_TICKET, TYPE_TRAVEL, TYPE_NOTE, TYPE_MEMBERSHIP, TYPE_FINANCE, TYPE_HEALTH, TYPE_VEHICLE)
    Column(Modifier.fillMaxSize().padding(top = 16.dp)) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            SectionHeading("Personal wallet", "Profiles and records you can reuse")
            Spacer(Modifier.height(13.dp))
            Text("ADD INFORMATION", color = subtle, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            items(types.filter { it != "All" }) { type ->
                AssistChip(onClick = { onAdd(type) }, label = { Text("+ $type") }, shape = RoundedCornerShape(12.dp))
            }
        }
        androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(types) { type -> FilterChip(selected = selected == type, onClick = { selected = type },
                label = { Text(type) }, shape = RoundedCornerShape(10.dp)) }
        }
        val shown = entries.filter { it.type != TYPE_PASSWORD && it.type != TYPE_DOCUMENT && (selected == "All" || it.type == selected) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
            if (shown.isEmpty()) item { EmptyState(Icons.Outlined.Wallet, "Your wallet is ready", "Save passenger details, addresses, ID information and private notes.") }
            items(shown, key = { it.id }) { item -> SenviyaEntryCard(item) { onSelect(item) } }
        }
    }
}

@Composable
private fun EmptyState(icon: ImageVector, title: String, desc: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 45.dp, horizontal = 25.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(color = Color(0xFFEAF2FA), shape = RoundedCornerShape(23.dp)) {
            Icon(icon, null, Modifier.padding(21.dp).size(34.dp), tint = ocean)
        }
        Text(title, color = ink, fontWeight = FontWeight.SemiBold)
        Text(desc, fontSize = 13.sp, color = subtle, lineHeight = 20.sp)
    }
}

@Composable
fun SenviyaBottomBar(page: String, onPage: (String) -> Unit) {
    NavigationBar(containerColor = Color.White, tonalElevation = 3.dp) {
        listOf("Home", "Passwords", "Documents", "Wallet", "Settings").forEach { section ->
            val icon = when (section) {
                "Home" -> Icons.Outlined.Home
                "Passwords" -> Icons.Outlined.Key
                "Documents" -> Icons.Outlined.Folder
                "Wallet" -> Icons.Outlined.Wallet
                else -> Icons.Outlined.Settings
            }
            NavigationBarItem(selected = page == section, onClick = { onPage(section) },
                icon = { Icon(icon, section, modifier = Modifier.size(23.dp)) },
                label = { Text(section, fontSize = 10.sp, maxLines = 1) }, alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(selectedIconColor = ocean, indicatorColor = Color(0xFFE6F0FC),
                    selectedTextColor = ocean, unselectedIconColor = subtle, unselectedTextColor = subtle))
        }
    }
}

@Composable
fun SenviyaSetup(onCreate: (String) -> Unit) {
    var master by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(horizontal = 25.dp, vertical = 34.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BrandMark(); Spacer(Modifier.width(10.dp))
            Text("Docryvia", fontSize = 24.sp, color = ink, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE8F3FF)) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, null, tint = ocean, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(14.dp))
                Text("Private by default. Everything you store is encrypted on your phone.",
                    color = ink, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Create your secure space", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ink)
        Text("Choose a long, unique master password. This protects your vault and is never sent to us.", color = subtle)
        OutlinedTextField(master, { master = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Master password · 12+ characters") }, singleLine = true,
            visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
            shape = RoundedCornerShape(16.dp))
        OutlinedTextField(confirm, { confirm = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Confirm master password") }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
            shape = RoundedCornerShape(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(show, { show = it }); Text("Show master password", color = ink)
        }
        Surface(shape = RoundedCornerShape(16.dp), color = soft) {
            Text("Next, we’ll give you a recovery key to store somewhere safe. Without it or your master password, your data cannot be recovered.",
                Modifier.padding(17.dp), color = subtle, style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(8.dp))
        Button(enabled = master.length >= 12 && master == confirm, onClick = {
            onCreate(master); master = ""; confirm = ""
        }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Create my private vault", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun SenviyaRecovery(token: String, questionKit: Boolean = false, onDone: () -> Unit) {
    var acknowledged by remember { mutableStateOf(false) }
    var verifying by remember(token) { mutableStateOf(false) }
    val groups = remember(token) { token.split('-') }
    var checkPartA by remember(token) { mutableStateOf("") }
    var checkPartB by remember(token) { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(26.dp), verticalArrangement = Arrangement.spacedBy(19.dp)) {
        Spacer(Modifier.height(35.dp))
        Icon(Icons.Outlined.Key, null, Modifier.size(49.dp), tint = teal)
        Text(if (questionKit) "Your question rescue code" else "Your recovery key", fontSize = 27.sp, color = ink, fontWeight = FontWeight.Bold)
        Text(if (questionKit) "Write this separate rescue code on paper. You need it AND your answer to reset your password. It is consumed after recovery." else "Keep this secret offline, ideally on paper. You can also set up a separate question and rescue code in Settings.", color = subtle)
        if (!verifying) {
            Surface(shape = RoundedCornerShape(17.dp), color = Color(0xFFE7F2F9)) {
                Text(token, Modifier.fillMaxWidth().padding(19.dp), color = ink, fontWeight = FontWeight.SemiBold)
            }
        } else Text("Your recovery key is now hidden. Check the paper copy you saved.", color = subtle)
        Text(if (questionKit) "Keep the code separate from your answer. Do not email or screenshot it." else "Do not email or screenshot this key. Anyone with it and your vault files can reset the password.", color = MaterialTheme.colorScheme.error)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(acknowledged, { acknowledged = it }); Text("I have safely written down my key", color = ink)
        }
        if (!verifying) {
            Button(enabled = acknowledged, onClick = { verifying = true },
                modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(15.dp)) {
                Text("I've saved it · verify my key")
            }
        } else {
            Text("Enter groups 2 and 6 using only your saved paper copy.", color = ink)
            OutlinedTextField(checkPartA, { checkPartA = it.take(8) }, label = { Text("Group 2") }, singleLine = true)
            OutlinedTextField(checkPartB, { checkPartB = it.take(8) }, label = { Text("Group 6") }, singleLine = true)
            Button(enabled = groups.size == 8 &&
                checkPartA.equals(groups[1], ignoreCase = true) && checkPartB.equals(groups[5], ignoreCase = true),
                onClick = onDone, modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(15.dp)) { Text("Open my vault") }
            TextButton(onClick = { verifying = false; checkPartA = ""; checkPartB = "" }) {
                Text("Show recovery key again")
            }
        }
    }
}

@Composable
fun SenviyaUnlock(privacyEvent: Int, quickEnabled: Boolean, onMaster: (String) -> Unit,
                  onRecovery: (String, String) -> Unit, onDevice: () -> Unit,
                  busy: Boolean = false, questionId: String? = null,
                  onQuestionRecovery: (String, String, String) -> Unit) {
    var password by remember { mutableStateOf("") }
    var recoverMode by remember { mutableStateOf(false) }
    var questionMode by remember { mutableStateOf(false) }
    var answer by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var recovery by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    LaunchedEffect(privacyEvent) {
        if (privacyEvent > 0) { password = ""; recovery = ""; newPassword = ""; answer = ""; confirmPassword = "" }
    }
    Column(Modifier.fillMaxSize().background(Color.White).verticalScroll(androidx.compose.foundation.rememberScrollState())
        .padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(40.dp))
        Surface(shape = RoundedCornerShape(32.dp), color = Color(0xFFE9F3FC), modifier = Modifier.size(110.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Shield, null, Modifier.size(67.dp), tint = ocean)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(if (recoverMode) "Recover your access" else "Welcome back", fontSize = 29.sp, color = ink,
            fontWeight = FontWeight.Bold)
        Text(if (recoverMode) "Reset with your saved recovery key, or your question rescue kit." else "Unlock your private digital vault.", color = subtle)
        Spacer(Modifier.height(25.dp))
        if (!recoverMode) {
            OutlinedTextField(password, { password = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Master password") }, singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                shape = RoundedCornerShape(15.dp))
            Button(onClick = { onMaster(password); password = "" }, enabled = password.isNotEmpty() && !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text("Unlock securely") }
            if (quickEnabled) {
                OutlinedButton(onClick = onDevice, enabled = !busy, modifier = Modifier.fillMaxWidth().height(51.dp),
                    shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Outlined.Fingerprint, null); Spacer(Modifier.width(9.dp))
                    Text("Fingerprint, face or screen lock")
                }
            }
            TextButton(enabled = !busy, onClick = { recoverMode = true; password = "" }) { Text("Forgot your master password?") }
        } else {
            if (questionId != null) {
                Row {
                    TextButton(enabled = !busy, onClick = { questionMode = false; recovery = ""; answer = "" }) { Text("Recovery key") }
                    TextButton(enabled = !busy, onClick = { questionMode = true; recovery = ""; answer = "" }) { Text("Question + code") }
                }
            }
            if (questionMode && questionId != null) {
                Text(QuestionRecovery.questions[questionId] ?: "Recovery question", color = ink)
                OutlinedTextField(answer, { answer = it.take(200) }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Your answer") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                Text("Your answer alone cannot reset this vault. Enter the separate rescue code you saved.", color = subtle)
            }
            OutlinedTextField(recovery, { recovery = it }, modifier = Modifier.fillMaxWidth(),
                visualTransformation = PasswordVisualTransformation(),
                label = { Text(if (questionMode) "Question rescue code" else "Offline recovery key") }, shape = RoundedCornerShape(15.dp))
            OutlinedTextField(newPassword, { newPassword = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("New master password · 12+ characters") },
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                shape = RoundedCornerShape(15.dp))
            OutlinedTextField(confirmPassword, { confirmPassword = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Confirm new master password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation())
            Button(enabled = !busy && recovery.isNotBlank() && newPassword.length >= 12 &&
                newPassword == confirmPassword && (!questionMode || answer.trim().length >= 2),
                onClick = {
                    if (questionMode) onQuestionRecovery(answer, recovery, newPassword)
                    else onRecovery(recovery, newPassword)
                    recovery = ""; newPassword = ""; confirmPassword = ""; answer = ""
                },
                modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) { Text("Restore access") }
            TextButton(enabled = !busy, onClick = { recoverMode = false; questionMode = false; answer = ""; recovery = ""; newPassword = ""; confirmPassword = "" }) { Text("Back to unlock") }
        }
        Spacer(Modifier.height(15.dp))
        Text("Encrypted locally · No account required", fontSize = 12.sp, color = subtle)
    }
}
