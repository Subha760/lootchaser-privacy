package app.kavorynx.vault

import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ClipDescription
import android.os.Handler
import android.os.Looper
import android.graphics.Color as AndroidColor
import android.view.WindowManager
import android.view.autofill.AutofillManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.io.File
import java.security.MessageDigest
import java.time.LocalDate

private val navy = soft
private val purple = ocean
private val aqua = teal

@Composable fun SenviyaAppTheme(content: @Composable () -> Unit) = SenviyaTheme(content)

class MainActivity : FragmentActivity() {
    var privacyEvent by mutableIntStateOf(0); private set
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = AndroidColor.rgb(244, 247, 251)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        window.navigationBarColor = AndroidColor.rgb(255, 255, 255)
        // After abrupt process death, remove orphaned temporary encrypted exports.
        // Delay cleanup so an in-progress system file picker isn't disrupted.
        noBackupFilesDir.listFiles()?.filter {
            it.name.startsWith("encrypted-export-") && it.name.endsWith(".zip") &&
                (System.currentTimeMillis() - it.lastModified()) > 24L * 60L * 60L * 1000L
        }?.forEach { it.delete() }
        val repo = VaultRepository(this)
        val quick = DeviceUnlock(repo)
        setContent { SenviyaAppTheme { SenviyaApp(this, repo, quick) } }
    }
    override fun onStop() {
        super.onStop()
        // Application owns the 30-second session grace period. Clear transient UI secrets now.
        privacyEvent++
    }
}

@Composable private fun SenviyaApp(activity: MainActivity, repo: VaultRepository, quick: DeviceUnlock) {
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var recoveryDisplay by remember { mutableStateOf("") }
    var questionKitDisplay by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("Home") }
    val introductionPrefs = remember { activity.getSharedPreferences("senviya_intro", Context.MODE_PRIVATE) }
    var introductionSeen by remember { mutableStateOf(introductionPrefs.getBoolean("seen_v2", false)) }
    var selectedDocumentCategory by remember { mutableStateOf("Other") }
    var pendingCsvUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var csvImportApproved by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<VaultItem?>(null) }
    var newType by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var importPassword by remember { mutableStateOf("") }
    var stagedEncryptedBackup by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(activity.privacyEvent) {
        if (activity.privacyEvent > 0) {
            recoveryDisplay = "" // No recovery key visible after background.
            edit = null; newType = null; importPassword = ""
            // Only an *already encrypted* ZIP remains staged while Android's picker is open.
        }
    }
    var pendingBackupUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var pendingDocumentImport by remember { mutableStateOf<android.net.Uri?>(null) }
    var pendingDocumentExport by remember { mutableStateOf<android.net.Uri?>(null) }
    var documentExportId by remember { mutableStateOf<String?>(null) }

    val backupWriter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val staged = stagedEncryptedBackup
        stagedEncryptedBackup = null
        if (uri == null || staged == null) {
            staged?.delete()
            message = "Backup cancelled"
        } else {
            scope.launch {
                busy = true
                try {
                    val verified = withContext(Dispatchers.IO) {
                        // The picker can stop MainActivity: the vault remains locked,
                        // and ONLY the password-encrypted backup ZIP is written.
                        activity.contentResolver.openOutputStream(uri, "w")!!.use { out ->
                            staged.inputStream().use { it.copyTo(out, 8192) }
                            out.flush()
                        }
                        val expected = MessageDigest.getInstance("SHA-256")
                            .digest(staged.readBytes())
                        val actual = runCatching {
                            activity.contentResolver.openInputStream(uri)!!.use { input ->
                                val md = MessageDigest.getInstance("SHA-256")
                                val buf = ByteArray(8192)
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    md.update(buf, 0, n)
                                }
                                md.digest()
                            }
                        }.getOrNull()
                        actual?.contentEquals(expected)
                    }
                    message = when (verified) {
                        true -> "Encrypted backup saved and verified"
                        false -> "Backup read-back mismatch; do not use this copy"
                        null -> "Backup saved; destination blocked read-back verification"
                    }
                } catch (_: Exception) { message = "Backup failed: destination unavailable" }
                finally { staged.delete(); busy = false }
            }
        }
    }
    val backupReader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingBackupUri = uri
            importPassword = ""
            message = "Unlock the vault, then enter backup passphrase to complete restore"
        }
    }
    val csvPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pendingCsvUri = uri; csvImportApproved = false
    }
    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pendingDocumentImport = uri
    }
    val documentWriter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        pendingDocumentExport = uri
        // If the picker sent us to the background, we locked. Finish only after the next unlock.
    }
    LaunchedEffect(VaultSession.unlocked, pendingDocumentImport, pendingDocumentExport, pendingCsvUri, csvImportApproved) {
        if (VaultSession.unlocked) {
            if (csvImportApproved) pendingCsvUri?.let { uri ->
                try {
                    val source = withContext(Dispatchers.IO) {
                        activity.contentResolver.openInputStream(uri)!!.use { input ->
                            val buffer = java.io.ByteArrayOutputStream()
                            val chunk = ByteArray(8192)
                            while (true) {
                                val n = input.read(chunk); if (n < 0) break
                                require(buffer.size() + n <= 5_000_000) { "CSV too large" }
                                buffer.write(chunk, 0, n)
                            }
                            buffer.toString(Charsets.UTF_8.name())
                        }
                    }
                    val maps = CsvImporter.parse(source)
                    val items = maps.mapNotNull { fields ->
                        val site = fields["url"]?.trim() ?: ""
                        if (DomainPolicy.canonicalHost(site) == null || fields["password"].isNullOrEmpty()) null
                        else VaultItem(type = TYPE_PASSWORD, title = fields["name"]?.ifBlank { site } ?: site,
                            site = site, username = fields["username"] ?: "", secret = fields["password"] ?: "",
                            notes = fields["note"] ?: "")
                    }
                    VaultSession.import(repo, items)
                    message = "Imported ${items.size} encrypted logins. Securely delete the original CSV from storage."
                } catch (_: Exception) { message = "CSV import failed. Check its format or size." }
                finally { pendingCsvUri = null; csvImportApproved = false }
            }
            pendingDocumentImport?.let { uri ->
                try {
                    val bytes = withContext(Dispatchers.IO) {
                        activity.contentResolver.openInputStream(uri)!!.use { input ->
                            val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192)
                            while (true) {
                                val n = input.read(buffer); if (n < 0) break
                                require(out.size() + n <= 8 * 1024 * 1024) { "File is too large" }
                                out.write(buffer, 0, n)
                            }; out.toByteArray()
                        }
                    }
                    try {
                        val name = androidx.documentfile.provider.DocumentFile.fromSingleUri(activity, uri)?.name ?: "Document"
                        val doc = withContext(Dispatchers.Default) {
                            VaultItem(type = TYPE_DOCUMENT, title = name, fileName = name,
                                mime = activity.contentResolver.getType(uri) ?: "application/octet-stream",
                                fileData = Crypto.b64(bytes), category = selectedDocumentCategory)
                        }
                        withContext(Dispatchers.IO) { VaultSession.save(doc, repo) }
                        message = "Document encrypted and saved"
                    } finally { bytes.fill(0) }
                } catch (_: Exception) { message = "Import failed (8 MB maximum)" }
                finally { pendingDocumentImport = null }
            }
            pendingDocumentExport?.let { uri ->
                try {
                    val selected = VaultSession.items.firstOrNull { it.id == documentExportId && it.type == TYPE_DOCUMENT }
                        ?: error("Missing selected document")
                    withContext(Dispatchers.IO) {
                        val bytes = Crypto.unb64(selected.fileData)
                        try { activity.contentResolver.openOutputStream(uri, "w")!!.use { it.write(bytes) } }
                        finally { bytes.fill(0) }
                    }
                    message = "Decrypted copy exported; destination is outside the vault"
                } catch (_: Exception) { message = "Document export failed" }
                finally { pendingDocumentExport = null; documentExportId = null }
            }
        }
    }

    BackHandler(enabled = VaultSession.unlocked && (edit != null || newType != null || page != "Home")) {
        when {
            edit != null -> edit = null
            newType != null -> newType = null
            else -> page = "Home"
        }
    }
    Box(Modifier.fillMaxSize().background(soft).safeDrawingPadding()) {
        when {
            !introductionSeen -> SenviyaIntro {
                introductionPrefs.edit().putBoolean("seen_v2", true).apply()
                introductionSeen = true
            }
            !repo.exists() -> SenviyaSetup { password ->
                if (!busy) {
                    busy = true
                    val capturedEvent = activity.privacyEvent
                    val chars = password.toCharArray()
                    scope.launch {
                        try {
                            val (key, recovery) = withContext(Dispatchers.Default) { repo.create(chars) }
                            if (capturedEvent == activity.privacyEvent) {
                                VaultSession.start(key, repo)
                                recoveryDisplay = recovery; questionKitDisplay = false
                            } else key.fill(0)
                        } catch (_: Exception) { message = "Vault setup failed" }
                        finally { chars.fill('\u0000'); busy = false }
                    }
                }
            }
            recoveryDisplay.isNotEmpty() -> SenviyaRecovery(recoveryDisplay, questionKitDisplay) { recoveryDisplay = "" }
            !VaultSession.unlocked -> SenviyaUnlock(
                privacyEvent = activity.privacyEvent,
                busy = busy,
                questionId = repo.recoveryQuestion(),
                quickEnabled = repo.hasDeviceUnlock(),
                onMaster = { pw ->
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        val chars = pw.toCharArray()
                        scope.launch {
                            try {
                                val key = withContext(Dispatchers.Default) { repo.unlock(chars) }
                                if (capturedEvent == activity.privacyEvent) {
                                    VaultSession.start(key, repo); message = ""
                                } else key.fill(0)
                            } catch (_: Exception) { message = "Incorrect password or damaged vault" }
                            finally { chars.fill('\u0000'); busy = false }
                        }
                    }
                },
                onRecovery = { token, newPassword ->
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        val chars = newPassword.toCharArray()
                        scope.launch {
                            try {
                                val key = withContext(Dispatchers.Default) { repo.resetPassword(token, chars) }
                                if (capturedEvent == activity.privacyEvent) {
                                    VaultSession.start(key, repo)
                                    message = "Password reset. Device unlock and question rescue kit disabled. Main recovery key remains valid."
                                } else key.fill(0)
                            } catch (_: Exception) { message = "Invalid recovery key or damaged vault" }
                            finally { chars.fill('\u0000'); busy = false }
                        }
                    }
                },
                onQuestionRecovery = { answer, code, pw ->
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        val chars = pw.toCharArray(); val answerChars = answer.toCharArray()
                        scope.launch {
                            try {
                                val key = withContext(Dispatchers.Default) { repo.resetWithQuestion(answerChars, code, chars) }
                                if (capturedEvent == activity.privacyEvent) {
                                    VaultSession.start(key, repo)
                                    message = "Password reset. Rescue kit consumed; device unlock disabled."
                                } else key.fill(0)
                            } catch (_: Exception) { message = "Incorrect answer or rescue code, or damaged vault" }
                            finally { chars.fill('\u0000'); answerChars.fill('\u0000'); busy = false }
                        }
                    }
                },
                onDevice = {
                    if (!busy) {
                        busy = true
                        quick.unlock(activity) { _, info -> message = info; busy = false }
                    }
                }
            )
            else -> {
                Column(Modifier.fillMaxSize()) {
                    SenviyaTopBar(onLock = { VaultSession.lock() }, count = VaultSession.items.size)
                    Box(Modifier.weight(1f)) {
                        when (page) {
                            "Home" -> SenviyaHome(VaultSession.items.toList(),
                                onGo = { page = it }, onAdd = { newType = it },
                                onPickDocument = { selectedDocumentCategory = "Other"; documentPicker.launch(arrayOf("*/*")) })
                            "Passwords" -> SenviyaPasswords(VaultSession.items.toList(),
                                onSelect = { edit = it }, onAdd = { newType = TYPE_PASSWORD },
                                onGenerator = { page = "Generator" })
                            "Documents" -> SenviyaDocuments(VaultSession.items.toList(),
                                onSelect = { edit = it },
                                onPick = { selectedDocumentCategory = it; documentPicker.launch(arrayOf("*/*")) })
                            "Wallet" -> SenviyaWallet(VaultSession.items.toList(),
                                onSelect = { edit = it }, onAdd = { newType = it })
                            "Generator" -> GeneratorPage(activity)
                            "Settings" -> SettingsPage(
                                activity, quick, repo, onNotice = { message = it },
                                onExport = { password ->
                                    if (!busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        val chars = password.toCharArray()
                                        scope.launch {
                                            try {
                                                val staged = withContext(Dispatchers.IO) {
                                                    val bytes = VaultSession.export(repo, chars)
                                                    try {
                                                        // Verify encrypted archive before asking user where to save it.
                                                        repo.readEncryptedZip(bytes, chars)
                                                        val file = File.createTempFile("encrypted-export-", ".zip", activity.noBackupFilesDir)
                                                        try { file.outputStream().use { it.write(bytes) } }
                                                        catch (e: Exception) { file.delete(); throw e }
                                                        file
                                                    } finally { bytes.fill(0) }
                                                }
                                                if (capturedEvent == activity.privacyEvent) {
                                                    stagedEncryptedBackup?.delete()
                                                    stagedEncryptedBackup = staged
                                                    backupWriter.launch("Docryvia-encrypted-backup.zip")
                                                } else staged.delete()
                                            } catch (_: Exception) { message = "Backup password needs 12+ characters" }
                                            finally { chars.fill('\u0000'); busy = false }
                                        }
                                    }
                                },
                                importPassword = importPassword,
                                onImportPassword = { importPassword = it },
                                selectedBackup = pendingBackupUri != null,
                                onImport = { backupReader.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                                onRestore = {
                                    val uri = pendingBackupUri
                                    if (uri != null && !busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        val pass = importPassword.toCharArray(); importPassword = ""
                                        scope.launch {
                                            try {
                                                val imported = withContext(Dispatchers.IO) {
                                                    val bytes = activity.contentResolver.openInputStream(uri)!!.use { input ->
                                                        val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(8192)
                                                        while (true) {
                                                            val n = input.read(buffer); if (n < 0) break
                                                            require(out.size() + n <= 100 * 1024 * 1024)
                                                            out.write(buffer, 0, n)
                                                        }; out.toByteArray()
                                                    }
                                                    repo.readEncryptedZip(bytes, pass)
                                                }
                                                if (capturedEvent == activity.privacyEvent && VaultSession.unlocked) {
                                                    withContext(Dispatchers.IO) { VaultSession.import(repo, imported) }
                                                    pendingBackupUri = null; message = "Backup merged into your vault"
                                                }
                                            } catch (_: Exception) { message = "Wrong passphrase or corrupt backup" }
                                            finally { pass.fill('\u0000'); busy = false }
                                        }
                                    }
                                },
                                onCsvImport = { csvPicker.launch(arrayOf("text/*", "application/vnd.ms-excel", "*/*")) },
                                busy = busy,
                                onQuestionSetup = { question, answer ->
                                    if (!busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        val chars = answer.toCharArray()
                                        scope.launch {
                                            try {
                                                val code = withContext(Dispatchers.Default) { VaultSession.setupQuestionRecovery(repo, question, chars) }
                                                if (capturedEvent == activity.privacyEvent) {
                                                    questionKitDisplay = true; recoveryDisplay = code
                                                }
                                            } catch (_: Exception) { message = "Could not set up question recovery" }
                                            finally { chars.fill('\u0000'); busy = false }
                                        }
                                    }
                                },
                                onQuestionDisable = {
                                    if (!busy) {
                                        busy = true
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.IO) { VaultSession.removeQuestionRecovery(repo) }
                                                message = "Question recovery disabled"
                                            } catch (_: Exception) { message = "Could not disable question recovery" }
                                            finally { busy = false }
                                        }
                                    }
                                },
                                onRotateRecovery = {
                                    if (!busy) {
                                        busy = true
                                        val capturedEvent = activity.privacyEvent
                                        scope.launch {
                                            try {
                                                val code = withContext(Dispatchers.IO) { VaultSession.rotateRecovery(repo) }
                                                if (capturedEvent == activity.privacyEvent) {
                                                    questionKitDisplay = false; recoveryDisplay = code
                                                }
                                            } catch (_: Exception) { message = "Recovery key rotation failed" }
                                            finally { busy = false }
                                        }
                                    }
                                },
                                onChangePassword = { pw ->
                                    if (!busy) {
                                        busy = true
                                        val chars = pw.toCharArray()
                                        val capturedEvent = activity.privacyEvent
                                        scope.launch {
                                            try {
                                                withContext(Dispatchers.Default) { VaultSession.changePassword(repo, chars) }
                                                if (capturedEvent == activity.privacyEvent) message = "Master password changed; device unlock disabled. Enable it again in Settings."
                                            } catch (_: Exception) { message = "Unable to change password (minimum 12 characters)" }
                                            finally { chars.fill('\u0000'); busy = false }
                                        }
                                    }
                                }
                            )
                        }
                    }
                    SenviyaBottomBar(page, onPage = { page = it })
                }
            }
        }
        // Present the editor *after* navigation, so every Add and Edit action has a real screen.
        if (VaultSession.unlocked && (edit != null || newType != null)) {
            val editing = edit
            val current = editing ?: VaultItem(type = newType ?: TYPE_NOTE)
            ItemEditor(item = current, onDismiss = { edit = null; newType = null },
                onSave = { updated ->
                    if (updated.type == TYPE_PASSWORD && (DomainPolicy.canonicalHost(updated.site) == null || updated.secret.isBlank())) {
                        message = "Enter a valid HTTPS website and a password"
                    } else if (!ExpiryPolicy.validate(updated.expiryDate)) {
                        message = "Use a real date in YYYY-MM-DD format"
                    } else if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { VaultSession.save(updated, repo) }
                                if (capturedEvent == activity.privacyEvent) {
                                    edit = null; newType = null
                                    message = "Saved securely on this device"
                                }
                            } catch (_: Exception) { message = "Could not save encrypted item" }
                            finally { busy = false }
                        }
                    }
                },
                onDelete = if (editing == null) null else ({
                    if (!busy) {
                        busy = true
                        val capturedEvent = activity.privacyEvent
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { VaultSession.remove(editing.id, repo) }
                                if (capturedEvent == activity.privacyEvent) {
                                    edit = null; newType = null; message = "Item deleted"
                                }
                            } catch (_: Exception) { message = "Could not delete item" }
                            finally { busy = false }
                        }
                    }
                }),
                onExportDocument = if (editing?.type != TYPE_DOCUMENT) null else ({ item ->
                    documentExportId = item.id
                    edit = null
                    documentWriter.launch(item.fileName.ifBlank { "document.bin" })
                }),
                onShareAddress = if (editing?.type != TYPE_ADDRESS) null else ({ item ->
                    // Only share an explicitly selected record, never the full vault.
                    val summary = listOf(item.username, item.notes, item.site)
                        .filter { it.isNotBlank() }.joinToString("\n")
                    if (summary.isNotBlank()) {
                        activity.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, summary)
                        }, "Share selected address outside Docryvia"))
                    }
                }))
        }
        if (pendingCsvUri != null && !csvImportApproved && VaultSession.unlocked) {
            AlertDialog(onDismissRequest = { pendingCsvUri = null },
                title = { Text("Import passwords from CSV?") },
                text = { Text("The selected CSV is unencrypted. Docryvia will read it locally and encrypt supported HTTPS logins. Delete the original CSV afterward, including any copies or downloads.") },
                confirmButton = { Button(onClick = { csvImportApproved = true }) { Text("Import locally") } },
                dismissButton = { TextButton(onClick = { pendingCsvUri = null }) { Text("Cancel") } }
            )
        }
        if (busy) {
            Surface(color = Color.White, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 98.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("Encrypting securely…")
                }
            }
        }
        AnimatedVisibility(message.isNotBlank(), modifier = Modifier.align(Alignment.TopCenter).padding(top = 80.dp)) {
            Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 7.dp) {
                Row(Modifier.padding(13.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(message, modifier = Modifier.weight(1f, fill = false))
                    Text("×", modifier = Modifier.clickable { message = "" })
                }
            }
        }
    }
}

@Composable private fun ItemEditor(item: VaultItem, onDismiss: () -> Unit, onSave: (VaultItem) -> Unit,
    onDelete: (() -> Unit)? = null, onExportDocument: ((VaultItem) -> Unit)? = null,
    onShareAddress: ((VaultItem) -> Unit)? = null) {
    var title by remember(item.id) { mutableStateOf(item.title) }
    var website by remember(item.id) { mutableStateOf(item.site) }
    var username by remember(item.id) { mutableStateOf(item.username) }
    var secret by remember(item.id) { mutableStateOf(item.secret) }
    var notes by remember(item.id) { mutableStateOf(item.notes) }
    var category by remember(item.id) { mutableStateOf(item.category) }
    var favorite by remember(item.id) { mutableStateOf(item.favorite) }
    var expiryDate by remember(item.id) { mutableStateOf(item.expiryDate) }
    var visible by remember { mutableStateOf(false) }
    var confirmAddressShare by remember(item.id) { mutableStateOf(false) }
    if (confirmAddressShare && onShareAddress != null) {
        AlertDialog(onDismissRequest = { confirmAddressShare = false },
            title = { Text("Share address outside Docryvia?") },
            text = { Text("This will send the selected address to another app. Once shared, Docryvia cannot revoke the recipient's copy.") },
            confirmButton = { Button(onClick = { confirmAddressShare = false; onShareAddress(item) }) { Text("Continue to Android Share") } },
            dismissButton = { TextButton(onClick = { confirmAddressShare = false }) { Text("Cancel") } })
    }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(if (item.title.isBlank()) "Add ${item.type}" else "Edit ${item.type}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                if (item.type == TYPE_PASSWORD) {
                    OutlinedTextField(website, { website = it }, label = { Text("Website URL (https://...)") }, singleLine = true)
                    OutlinedTextField(username, { username = it }, label = { Text("Username / email") }, singleLine = true)
                    OutlinedTextField(secret, { secret = it }, label = { Text("Password") },
                        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = { IconButton(onClick = { visible = !visible }) { Icon(Icons.Default.Visibility, "Show or hide") } })
                    TextButton(onClick = { secret = Crypto.generatePassword() }) { Text("Generate strong password") }
                } else if (item.type != TYPE_NOTE && item.type != TYPE_DOCUMENT) {
                    OutlinedTextField(username, { username = it }, label = { Text(if (item.type == TYPE_ADDRESS) "Recipient name / phone" else if (item.type == TYPE_IDENTITY) "Full name" else "Owner / passenger / member") })
                    OutlinedTextField(website, { website = it }, label = { Text(if (item.type == TYPE_ADDRESS) "Postal code / city" else if (item.type == TYPE_IDENTITY) "ID type / issuing authority" else "Provider / location / issuing office") })
                    OutlinedTextField(secret, { secret = it }, label = { Text(if (item.type == TYPE_ADDRESS) "Phone / optional details" else "Reference / number / private detail") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = favorite, onCheckedChange = { favorite = it })
                    Text("Keep in favorites", style = MaterialTheme.typography.bodyMedium)
                }
                if (item.type in setOf(TYPE_DOCUMENT, TYPE_IDENTITY, TYPE_TICKET, TYPE_TRAVEL,
                        TYPE_VEHICLE, TYPE_FINANCE, TYPE_MEMBERSHIP)) {
                    OutlinedTextField(expiryDate, { expiryDate = it.take(10) },
                        label = { Text("Expiry date (YYYY-MM-DD), optional") }, singleLine = true)
                }
                if (item.type == TYPE_DOCUMENT) {
                    Text("Document category", style = MaterialTheme.typography.labelMedium)
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        items(documentCategories.filter { it != "All" }) { candidate ->
                            FilterChip(selected = category == candidate, onClick = { category = candidate },
                                label = { Text(candidate) })
                        }
                    }
                }
                if (item.type != TYPE_DOCUMENT) {
                    OutlinedTextField(notes, { notes = it }, label = { Text(if (item.type == TYPE_ADDRESS) "Full address / landmark" else "Private notes") },
                        minLines = 2)
                } else {
                    Text("Document encrypted inside your vault. Export only when needed.")
                    if (onExportDocument != null) OutlinedButton(onClick = { onExportDocument(item) }) { Text("Export decrypted copy") }
                }
                if (onShareAddress != null && item.type == TYPE_ADDRESS && item.title.isNotBlank()) {
                    OutlinedButton(onClick = { confirmAddressShare = true }) { Text("Share selected address details") }
                }
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete this item", color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(item.copy(title = title.trim(), site = website.trim(),
                username = username.trim(), secret = secret, notes = notes, category = category,
                favorite = favorite, expiryDate = expiryDate.trim())) }, enabled = title.isNotBlank()) { Text("Save") }
        }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable private fun GeneratorPage(context: Context) {
    var password by remember { mutableStateOf(Crypto.generatePassword()) }
    var length by remember { mutableFloatStateOf(24f) }
    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text("Password studio", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Cryptographically random passwords, generated locally.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Surface(color = Color(0xFFEAF1F8), shape = RoundedCornerShape(18.dp)) {
            Text(password, Modifier.fillMaxWidth().padding(20.dp), color = aqua, style = MaterialTheme.typography.titleMedium)
        }
        Text("Password length: ${length.toInt()}")
        Slider(value = length, onValueChange = { length = it }, valueRange = 12f..64f, steps = 51)
        Button(onClick = { password = Crypto.generatePassword(length.toInt()) }, modifier = Modifier.fillMaxWidth()) { Text("Generate") }
        OutlinedButton(onClick = {
            SensitiveClipboard.copy(context, password)
        }) { Text("Copy password (clear after 30 seconds)") }
        Text("For password autofill, store the generated password in your vault instead of the clipboard.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun SettingsPage(activity: MainActivity, quick: DeviceUnlock, repo: VaultRepository,
    onNotice: (String) -> Unit, onExport: (String) -> Unit, importPassword: String,
    onImportPassword: (String) -> Unit, selectedBackup: Boolean,
    onImport: () -> Unit, onRestore: () -> Unit, onCsvImport: () -> Unit, onRotateRecovery: () -> Unit,
    onChangePassword: (String) -> Unit, busy: Boolean,
    onQuestionSetup: (String, String) -> Unit, onQuestionDisable: () -> Unit) {
    var changePass by remember { mutableStateOf("") }
    var confirmChangePass by remember { mutableStateOf("") }
    var exportPass by remember { mutableStateOf("") }
    var legalText by remember { mutableStateOf<String?>(null) }
    val secrets = VaultSession.items.filter { it.type == TYPE_PASSWORD }
    val health = PasswordHealth.analyze(secrets.map {
        PasswordHealthInput(it.id, it.site, it.username, it.secret)
    })
    val weakCount = health.weak
    val reusedCount = health.reused
    val legalContext = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("Security & privacy", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Surface(color = Color(0xFFEAF2FB), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Local password health", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${health.total} accounts · $weakCount weak · $reusedCount reused · ${health.duplicateAccounts} duplicate entries",
                    color = if (weakCount + reusedCount > 0) Color(0xFFFFD19C) else aqua,
                    style = MaterialTheme.typography.bodySmall)
            }
        }
        SecurityTile("Device unlock", "Strong fingerprint / face; device PIN/pattern/password on Android 11+",
            if (repo.hasDeviceUnlock()) "Disable" else "Enable") {
            if (repo.hasDeviceUnlock()) {
                try { quick.disable(); onNotice("Device unlock disabled") }
                catch (_: Exception) { onNotice("Could not disable device unlock") }
            } else quick.enable(activity) { _, info -> onNotice(info) }
        }
        SecurityTile("Android autofill", "Select Docryvia in Android autofill settings", "Open settings") {
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    activity.startActivity(Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE).apply {
                        data = android.net.Uri.parse("package:${activity.packageName}")
                    })
                }
            } catch (_: Exception) {
                activity.startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        Text("Backup & restore", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(exportPass, { exportPass = it }, label = { Text("Backup encryption passphrase (12+)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button(onClick = { onExport(exportPass); exportPass = "" }, enabled = exportPass.length >= 12,
            modifier = Modifier.fillMaxWidth()) { Text("Export encrypted ZIP") }
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("Choose encrypted ZIP to restore") }
        if (selectedBackup) {
            OutlinedTextField(importPassword, onImportPassword, label = { Text("Passphrase for selected ZIP") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button(onClick = onRestore, enabled = importPassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("Verify & merge selected backup")
            }
        }
        Text("Import from another manager", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(onClick = onCsvImport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Import Google Password Manager CSV")
        }
        Text("CSV files are plaintext. The file is read locally and never uploaded. Delete the exported CSV after importing.",
            style = MaterialTheme.typography.bodySmall, color = subtle)
        Text("Access", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(changePass, { changePass = it }, label = { Text("New master password (12+)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(confirmChangePass, { confirmChangePass = it }, label = { Text("Confirm new master password") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { onChangePassword(changePass); changePass = ""; confirmChangePass = "" },
            enabled = !busy && changePass.length >= 12 && changePass == confirmChangePass) {
            Text("Change master password")
        }
        QuestionRecoverySettings(repo.recoveryQuestion() != null, busy, onQuestionSetup, onQuestionDisable)
        OutlinedButton(onClick = onRotateRecovery, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Generate new recovery key (invalidates old one)")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                legalText = legalContext.resources.openRawResource(R.raw.privacy_policy).bufferedReader().use { it.readText() }
            }) { Text("Privacy policy") }
            OutlinedButton(onClick = {
                legalText = legalContext.resources.openRawResource(R.raw.terms_of_use).bufferedReader().use { it.readText() }
            }) { Text("Terms") }
        }
        Text("Publisher: choicematrix\nSupport: lootchaser2026@gmail.com", style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = {
            try {
                activity.startActivity(Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://subha760.github.io/lootchaser-privacy/docryvia-privacy.html")))
            } catch (_: Exception) { onNotice("No browser available; read the local privacy policy above") }
        }) { Text("Open public privacy policy") }
        Text("Privacy: no INTERNET permission, no analytics, no cloud backup, no SMS/contacts/location access.\n\n" +
            "Brief app switches keep your unlocked session for at most 30 seconds. Screen-off and manual lock clear it immediately. Biometric/device quick unlock is optional. Use your master password, main recovery key, or optional question plus separate rescue code. Password resets disable device unlock; set it up again afterward.\n\n" +
            "Strong biometric capability depends on device hardware. Some face unlock implementations are not eligible.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
    if (legalText != null) AlertDialog(
        onDismissRequest = { legalText = null }, title = { Text("Legal information") },
        text = { Column(Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) { Text(legalText ?: "") } },
        confirmButton = { TextButton(onClick = { legalText = null }) { Text("Close") } }
    )

}

@Composable private fun SecurityTile(title: String, desc: String, action: String, onClick: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onClick) { Text(action) }
        }
    }
}
