package app.kavorynx.vault

import java.text.Normalizer
import java.util.Locale

/** Answers never unlock alone: the independent 256-bit rescue code is also required. */
object QuestionRecovery {
    val questions = linkedMapOf(
        "food" to "What is your favourite food?",
        "school" to "What was your first school?",
        "nickname" to "What was your childhood nickname?"
    )
    private fun normalized(answer: CharArray): CharArray {
        require(answer.size <= 200) { "Answer too long" }
        val value = Normalizer.normalize(String(answer), Normalizer.Form.NFKC)
            .trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
        require(value.length >= 2) { "Use at least two characters" }
        return value.toCharArray()
    }
    private fun domain(question: String): String {
        require(question in questions) { "Unknown recovery question" }
        return "docryvia:question-recovery:v1:$question"
    }
    fun seal(question: String, answer: CharArray, rescueCode: String, dek: ByteArray): String {
        val aad = domain(question)
        val token = Crypto.parseRecoveryToken(rescueCode)
        val salt = Crypto.randomBytes(16)
        val chars = normalized(answer)
        var key: ByteArray? = null
        try {
            // A stolen answer and salt still cannot derive this key without the rescue code.
            key = Crypto.pbkdf2(chars, salt + token)
            return Crypto.b64(salt + Crypto.seal(key, dek, aad))
        } finally { chars.fill('\u0000'); token.fill(0); key?.fill(0) }
    }
    fun open(question: String, answer: CharArray, rescueCode: String, envelope: String): ByteArray {
        val aad = domain(question)
        val packed = Crypto.unb64(envelope)
        require(packed.size == 16 + 12 + 32 + 16) { "Invalid recovery envelope" }
        val token = Crypto.parseRecoveryToken(rescueCode)
        val chars = normalized(answer)
        var key: ByteArray? = null
        try {
            key = Crypto.pbkdf2(chars, packed.copyOfRange(0, 16) + token)
            return Crypto.open(key, packed.copyOfRange(16, packed.size), aad)
        } finally { chars.fill('\u0000'); token.fill(0); key?.fill(0) }
    }
}
