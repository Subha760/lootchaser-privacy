package app.kavorynx.vault

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainPolicyUnitTest {
    @Test fun requiresExactSecureHost() {
        assertEquals("example.com", DomainPolicy.canonicalHost("https://EXAMPLE.com/path"))
        assertTrue(DomainPolicy.matches("https://example.com/login", "https://example.com/account"))
        assertFalse(DomainPolicy.matches("https://example.com", "https://login.example.com"))
        assertFalse(DomainPolicy.matches("https://example.com", "https://example.com.evil.test"))
    }
    @Test fun rejectsInsecureOrUserInfoOrigins() {
        assertNull(DomainPolicy.canonicalHost("http://example.com"))
        assertNull(DomainPolicy.canonicalHost("https://user@example.com"))
        assertNull(DomainPolicy.canonicalHost("https://example.com:444"))
    }
}
