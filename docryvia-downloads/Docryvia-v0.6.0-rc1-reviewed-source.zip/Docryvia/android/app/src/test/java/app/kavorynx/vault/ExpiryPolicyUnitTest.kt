package app.kavorynx.vault

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ExpiryPolicyUnitTest {
    private val today = LocalDate.of(2026, 10, 9)
    @Test fun upcomingBoundaryAndExpiredRecords() {
        assertEquals(ExpiryState.NONE, ExpiryPolicy.status("", today))
        assertEquals(ExpiryState.EXPIRED, ExpiryPolicy.status("2026-10-08", today))
        assertEquals(ExpiryState.UPCOMING, ExpiryPolicy.status("2026-10-09", today))
        assertEquals(ExpiryState.UPCOMING, ExpiryPolicy.status("2026-11-08", today))
        assertEquals(ExpiryState.VALID, ExpiryPolicy.status("2026-11-09", today))
    }
    @Test fun invalidDatesFailClosed() {
        assertFalse(ExpiryPolicy.validate("2027-02-29"))
        assertTrue(ExpiryPolicy.validate("2028-02-29"))
        assertEquals(ExpiryState.NONE, ExpiryPolicy.status("bad-input", today))
    }
}
