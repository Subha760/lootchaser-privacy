package app.kavorynx.vault

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordHealthUnitTest {
    @Test fun weakAndReusedPasswords() {
        val rows = listOf(
            PasswordHealthInput("1", "https://example.com", "u", "password123"),
            PasswordHealthInput("2", "https://other.test", "u", "password123"),
            PasswordHealthInput("3", "https://example.com", "u", "vFqsOpLwUmykJtzHAnRq"))
        val report = PasswordHealth.analyze(rows)
        assertEquals(3, report.total)
        assertEquals(2, report.weak)
        assertEquals(2, report.reused)
        assertEquals(2, report.duplicateAccounts)
    }
    @Test fun longLetterOnlyIsNotAutomaticallyWeak() {
        assertFalse(PasswordHealth.isPotentiallyWeak("qVajQwBtMzNsLpHkRtFyDg"))
        assertTrue(PasswordHealth.isPotentiallyWeak("12345678"))
    }
}
