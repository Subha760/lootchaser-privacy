package app.kavorynx.vault

import org.junit.Assert.*
import org.junit.Test

class SessionTimeoutUnitTest {
    @Test fun briefSwitchDoesNotRequireAnotherLogin() {
        val timeout = SessionTimeout()
        timeout.background(1000)
        assertFalse(timeout.foreground(30_999))
        assertFalse(timeout.expired(99_999))
    }
    @Test fun deadlineAndLongSuspensionRequireLogin() {
        val timeout = SessionTimeout()
        timeout.background(1000)
        assertTrue(timeout.expired(31_000))
        assertTrue(timeout.foreground(999_999))
    }
    @Test fun duplicateBackgroundEventsDoNotExtendSession() {
        val timeout = SessionTimeout()
        timeout.background(1000); timeout.background(20_000)
        assertTrue(timeout.expired(31_000))
    }
}
