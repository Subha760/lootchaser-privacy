package app.kavorynx.vault

import android.app.Activity
import android.content.Intent
import android.os.Looper
import java.time.Duration
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = DocryviaApp::class)
@LooperMode(LooperMode.Mode.PAUSED)
class AppSessionUnitTest {
    private fun unlock() {
        VaultSession.lock()
        val app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("kavorynx_config", 0).edit().clear().commit()
        app.filesDir.listFiles()?.forEach { it.delete() }
        val repo = VaultRepository(app)
        val (key, _) = repo.create("test master password".toCharArray())
        VaultSession.start(key, repo)
    }
    @Test fun briefReturnPreservesSessionAndCancelsPendingLock() {
        val controller = Robolectric.buildActivity(Activity::class.java).create().start().resume()
        unlock()
        controller.pause().stop()
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(10))
        assertTrue(VaultSession.unlocked)
        controller.start().resume()
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(40))
        assertTrue(VaultSession.unlocked)
        VaultSession.lock(); controller.pause().stop().destroy()
    }
    @Test fun backgroundTimeoutLocksSession() {
        val controller = Robolectric.buildActivity(Activity::class.java).create().start().resume()
        unlock(); controller.pause().stop()
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(30))
        assertFalse(VaultSession.unlocked); assertTrue(VaultSession.items.isEmpty())
        controller.destroy()
    }
    @Test fun screenOffImmediatelyLocksEvenWithinGrace() {
        val controller = Robolectric.buildActivity(Activity::class.java).create().start().resume()
        unlock()
        RuntimeEnvironment.getApplication().sendBroadcast(Intent(Intent.ACTION_SCREEN_OFF))
        shadowOf(Looper.getMainLooper()).idle()
        assertFalse(VaultSession.unlocked)
        controller.pause().stop().destroy()
    }
}
