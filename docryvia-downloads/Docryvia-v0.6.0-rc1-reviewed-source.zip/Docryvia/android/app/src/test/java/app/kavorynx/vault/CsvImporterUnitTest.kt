package app.kavorynx.vault

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CsvImporterUnitTest {
    @Test fun quotedCommaAndWindowsNewline() {
        val rows = CsvImporter.parse("name,url,username,password,note\r\nBank,https://example.com,u,p,\"hello, world\"\r\n")
        assertEquals(1, rows.size)
        assertEquals("hello, world", rows.first()["note"])
        assertEquals("https://example.com", rows.first()["url"])
    }
    @Test fun rejectsBrokenCsv() {
        assertThrows(IllegalArgumentException::class.java) {
            CsvImporter.parse("url,username,password\nhttps://example.com,me,\"unterminated")
        }
        assertThrows(IllegalArgumentException::class.java) {
            CsvImporter.parse("url,username,password\nhttps://example.com,me,p,extra")
        }
    }
}
