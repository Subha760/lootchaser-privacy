import app.kavorynx.vault.ExpiryPolicy
import app.kavorynx.vault.ExpiryState
import java.time.LocalDate

fun main() {
    val today = LocalDate.of(2026, 10, 9)
    check(ExpiryPolicy.status("", today) == ExpiryState.NONE)
    check(ExpiryPolicy.status("not-a-date", today) == ExpiryState.NONE)
    check(ExpiryPolicy.status("2026-10-08", today) == ExpiryState.EXPIRED)
    check(ExpiryPolicy.status("2026-10-09", today) == ExpiryState.UPCOMING)
    check(ExpiryPolicy.status("2026-11-08", today) == ExpiryState.UPCOMING)
    check(ExpiryPolicy.status("2026-11-09", today) == ExpiryState.VALID)
    check(ExpiryPolicy.validate("2028-02-29"))
    check(!ExpiryPolicy.validate("2027-02-29"))
    println("PASS: expiry dates, leap years, due-soon boundaries and invalid input")
}
