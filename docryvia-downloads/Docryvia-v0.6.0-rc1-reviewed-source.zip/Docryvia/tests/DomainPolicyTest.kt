import app.kavorynx.vault.DomainPolicy

fun main() {
    check(DomainPolicy.canonicalHost("https://ExAmPlE.COM/login") == "example.com")
    check(DomainPolicy.canonicalHost("https://example.com:443") == "example.com")
    check(DomainPolicy.canonicalHost("http://example.com") == null)
    check(DomainPolicy.canonicalHost("https://evil.com@example.com") == null)
    check(DomainPolicy.canonicalHost("https://example.com:8443") == null)
    check(DomainPolicy.canonicalHost("https://foo..com") == null)
    check(!DomainPolicy.matches("https://example.com", "https://fakeexample.com"))
    check(!DomainPolicy.matches("https://example.com", "https://sub.example.com"))
    check(DomainPolicy.matches("https://example.com/signin", "https://example.com/account"))
    println("PASS: strict HTTPS host canonicalization and exact matching")
}
