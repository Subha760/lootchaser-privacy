"""Static design boards only; not screenshots from an installed Android app."""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
from math import sin
base=Path(__file__).resolve().parents[1]
W,H=1080,2340
paper=(246,249,252); navy=(20,41,64); blue=(23,102,197); teal=(11,136,125); muted=(104,123,141)
fontpath='/usr/share/fonts/opentype/inter/InterDisplay-Regular.otf'
semipath='/usr/share/fonts/opentype/inter/InterDisplay-SemiBold.otf'
boldpath='/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf'
def f(n,heavy=False):return ImageFont.truetype(boldpath if heavy else fontpath,n)
def card(d,xy,r=32,fill='white',stroke=(226,234,243),width=2):
 d.rounded_rectangle(xy,radius=r,fill=fill,outline=stroke,width=width)
def t(d,xy,s,size=36,fill=navy,heavy=False):d.text(xy,s,font=f(size,heavy),fill=fill)
def icon(d,x,y,kind,c,size=85):
    d.rounded_rectangle((x,y,x+size,y+size),radius=24,fill=tuple(round(cc*.1+245*.9) for cc in c))
    midx,midy=x+size/2,y+size/2
    if kind=='doc':
        d.rounded_rectangle((x+27,y+18,x+59,y+65),radius=5,outline=c,width=4)
        for p in range(3):d.line((x+33,y+39+p*8,x+54,y+39+p*8),fill=c,width=3)
    elif kind=='pin':
        d.ellipse((x+26,y+20,x+60,y+54),outline=c,width=5);d.ellipse((x+39,y+34,x+47,y+42),fill=c);d.polygon([(x+31,y+53),(x+43,y+70),(x+55,y+53)],fill=c)
    elif kind=='pass':
        d.ellipse((x+24,y+26,x+48,y+50),outline=c,width=6);d.line((x+47,y+42,x+69,y+42),fill=c,width=6);d.line((x+60,y+42,x+60,y+53),fill=c,width=6)
    elif kind=='plane':
        d.line((x+17,y+59,x+68,y+26),fill=c,width=7);d.line((x+31,y+35,x+58,y+41),fill=c,width=6);d.line((x+46,y+69,x+50,y+43),fill=c,width=6)
    else:
        d.rounded_rectangle((x+21,y+20,x+65,y+65),radius=10,outline=c,width=5)

def page_header(d):
    t(d,(72,47),'9:41',36,navy,True)
    # Draw status glyphs with vector primitives instead of unavailable font glyphs.
    d.ellipse((862,65,883,86),fill=navy)
    for j,bar in enumerate([16,24,31,39]):
        xx=917+j*22
        d.rounded_rectangle((xx,88-bar,xx+12,88),radius=2,fill=navy)
    d.polygon([(1024,59),(1032,66),(1027,83),(1016,83)],fill=navy)
    d.rounded_rectangle((60,145,162,247),radius=29,fill=blue)
    t(d,(88,163),'D',62,'white',True)
    t(d,(193,151),'Docryvia',54,navy,True)
    t(d,(193,215),'Private documents & passwords',28,muted)
    card(d,(809,160,950,216),28,(228,247,237),(228,247,237))
    t(d,(825,174),'OFFLINE',21,teal,True)
    d.ellipse((976,162,1039,225),outline=navy,width=4)
    d.arc((990,176,1026,205),0,360,fill=navy,width=3)

def bottom(d,selected):
    d.rectangle((0,H-180,W,H),fill='white')
    d.line((0,H-180,W,H-180),fill=(227,234,241),width=2)
    for i,name in enumerate(['Home','Passwords','Documents','Wallet','Settings']):
        x=95+i*214
        c=blue if name==selected else muted
        if name==selected:d.rounded_rectangle((x-42,H-156,x+58,H-86),radius=34,fill=(227,241,252))
        yy=H-137
        if name=='Home':
            d.line((x-15,yy+9,x+9,yy-11,x+33,yy+9),fill=c,width=5,joint='curve')
            d.rectangle((x-7,yy+8,x+25,yy+29),outline=c,width=4)
        elif name=='Passwords':
            d.ellipse((x-15,yy-9,x+12,yy+18),outline=c,width=5)
            d.line((x+10,yy+5,x+32,yy+5),fill=c,width=5)
            d.line((x+23,yy+5,x+23,yy+17),fill=c,width=5)
        elif name=='Documents':
            d.rounded_rectangle((x-7,yy-12,x+24,yy+29),radius=4,outline=c,width=4)
            for dy in (1,9,17):d.line((x,yy+dy,x+17,yy+dy),fill=c,width=3)
        elif name=='Wallet':
            d.rounded_rectangle((x-11,yy-2,x+30,yy+27),radius=7,outline=c,width=4)
            d.rectangle((x+14,yy+7,x+31,yy+18),fill=c)
        else:
            d.ellipse((x-8,yy-6,x+26,yy+28),outline=c,width=5)
            d.ellipse((x+3,yy+5,x+15,yy+17),fill=c)
        t(d,(x-55,H-70),name,22,blue if name==selected else muted, name==selected)

im=Image.new('RGB',(W,H),paper);d=ImageDraw.Draw(im)
page_header(d)
t(d,(66,318),'Good to have everything together.',31,muted)
t(d,(66,378),'Your digital essentials',64,navy,True)
card(d,(56,500,1025,872),52,navy,navy)
d.ellipse((100,554,121,575),outline=(152,220,216),width=4)
t(d,(134,548),'Protected on this device',32,(152,220,216),True)
t(d,(100,630),'One private place.',50,'white',True)
t(d,(100,690),'A little less to worry about.',46,'white',True)
d.line((100,780,975,780),fill=(75,102,127),width=2)
t(d,(100,810),'3 logins       6 documents',30,(231,238,246))
t(d,(61,955),'Explore your vault',50,navy,True)
t(d,(61,1027),'Find the right place for every detail',29,muted)
cell=[('Passwords','Logins & accounts','pass',blue),('Documents','Files & IDs','doc',teal),('Addresses','Delivery & home','pin',(151,93,65)),('Travel','Tickets & trips','plane',(108,82,187)),('Identity','Personal details','id',(175,90,65)),('Private notes','Things to remember','note',(25,126,151))]
for idx,(title,sub,kind,color) in enumerate(cell):
 row,col=divmod(idx,2);x=58+col*498;y=1115+row*278
 card(d,(x,y,x+467,y+258),34,'white')
 icon(d,x+31,y+28,kind,color)
 t(d,(x+31,y+135),title,35,navy,True)
 t(d,(x+31,y+195),sub,26,muted)
t(d,(64,2020),'Quick actions',44,navy,True)
card(d,(62,2102,499,2193),27,blue,blue)
t(d,(149,2124),'+ Add login',32,'white',True)
card(d,(524,2102,1018,2193),27,'white',(206,219,233))
t(d,(632,2124),'+ Add file',32,blue,True)
bottom(d,'Home')
im.resize((540,1170),Image.Resampling.LANCZOS).save('/mnt/data/Docryvia-Dashboard-Preview.png')

im=Image.new('RGB',(W,H),paper);d=ImageDraw.Draw(im);page_header(d)
t(d,(65,327),'Document wallet',65,navy,True)
t(d,(65,419),'Your important files, neatly organised',31,muted)
card(d,(62,515,1015,641),28,'white')
d.ellipse((110,552,141,583),outline=muted,width=5)
d.line((138,580,152,595),fill=muted,width=5)
t(d,(175,556),'Search securely',34,muted)
card(d,(62,692,1015,795),24,blue,blue)
t(d,(250,722),'+  Encrypt & add document',35,'white',True)
t(d,(62,862),'CATEGORIES',26,muted,True)
chip=[('All',True),('Identity',False),('Education',False),('Health',False)]
x=60
for name,active in chip:
 width=len(name)*19+80;card(d,(x,916,x+width,983),30,(227,240,252) if active else 'white',(220,229,239));t(d,(x+36,932),name,29,blue if active else navy,active);x+=width+14
t(d,(65,1060),'6 documents',31,muted)
records=[('PAN Card','Identity','ID'),('Class XII marksheet','Education','ED'),('Medical report','Health','MD'),('Vehicle insurance','Insurance','IN'),('Train booking','Travel','TR'),('Property record','Property','PR')]
for i,(name,cat,abbr) in enumerate(records):
 y=1135+i*158;card(d,(63,y,1012,y+140),28,'white')
 d.rounded_rectangle((91,y+20,195,y+119),radius=23,fill=(230,243,251))
 t(d,(116,y+49),abbr,28,blue,True)
 t(d,(223,y+25),name,36,navy,True);t(d,(223,y+82),cat,27,muted)
 t(d,(951,y+50),'›',55,muted)
bottom(d,'Documents')
im.resize((540,1170),Image.Resampling.LANCZOS).save('/mnt/data/Docryvia-Documents-Preview.png')
print('Static design previews exported; not app screenshots')
