import app.kavorynx.vault.CsvImporter
fun main() {
    val csv = "name,url,username,password,note\r\nSample,https://example.com,me@example.com,p4ss,\"commas, work\"\r\n"
    val rows = CsvImporter.parse(csv)
    check(rows.size == 1 && rows[0]["note"] == "commas, work")
    check(rows[0]["url"] == "https://example.com")
    try { CsvImporter.parse("url,username,password\nhttps://x,me,\"unfinished") ; error("Unclosed quote accepted") }
    catch (e: IllegalArgumentException) { }
    try { CsvImporter.parse("url,username,password\nfoo,b,c,d") ; error("Bad column count accepted") }
    catch (e: IllegalArgumentException) { }
    println("CSV parser tests PASS: quoted commas, CRLF, column validation, unclosed quote")
}
