import app.kavorynx.vault.PasswordHealth
import app.kavorynx.vault.PasswordHealthInput

fun main() {
    check(PasswordHealth.isPotentiallyWeak("password123"))
    check(PasswordHealth.isPotentiallyWeak("123456789000"))
    check(!PasswordHealth.isPotentiallyWeak("yR9!bT5#nX2@qP"))
    check(!PasswordHealth.isPotentiallyWeak("gprtnsxylkecbdhwmvzqjafu")) // long all-letter string
    check(PasswordHealth.isPotentiallyWeak("myPassword12345"))
    val result = PasswordHealth.analyze(listOf(
        PasswordHealthInput("1", "https://example.com", "one@site.com", "yR9!bT5#nX2@qP"),
        PasswordHealthInput("2", "https://sample.com", "other@site.com", "yR9!bT5#nX2@qP"),
        PasswordHealthInput("3", "https://www.example.com/login", "one@site.com", "short"),
        PasswordHealthInput("4", "https://elsewhere.com", "different@site.com", "")
    ))
    check(result.total == 4)
    check(result.weak == 1)
    check(result.reused == 2)
    check(result.duplicateAccounts == 2)
    println("PASS: local password health heuristics, reuse and duplicates")
}
